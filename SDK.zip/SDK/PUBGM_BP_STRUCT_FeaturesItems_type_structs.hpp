#pragma once

// PUBGm BETA - 64bit (4.6.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// UserDefinedStruct BP_STRUCT_FeaturesItems_type.BP_STRUCT_FeaturesItems_type
// 0x002C
struct FBP_STRUCT_FeaturesItems_type
{
	int ID_4_70B6D9000F7C4138010820A90EFCE7B4; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0004(0x0004) MISSED OFFSET
	struct FString Features_6_6384C58014BE35983FAD42C605772F63; // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString SFeatures_7_4235FA4078CACDE3584EEB4C0445A9E3; // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int NeedTlog_8_776EDA4045D035A97259BD5F05455B77; // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

