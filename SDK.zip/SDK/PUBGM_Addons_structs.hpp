#pragma once

// PUBGm BETA - 64bit (4.6.0) SDK by BangJO [Z] DM @isar_hackJO To Buy Tool SDK

namespace SDK
{
//---------------------By BangJO---------------------------
//Enums
//---------------------By BangJO---------------------------

// Enum Addons.EFoxStance
enum class EFoxStance : uint8_t
{
	EFoxStance__FourLegged = 0,
	EFoxStance__TwoLegged = 1,
	EFoxStance__Sleeping = 2,
	EFoxStance__EFoxStance_MAX = 3
};


// Enum Addons.ENTFoxGait
enum class ENTFoxGait : uint8_t
{
	ENTFoxGait__ENTFoxGait_Walk = 0,
	ENTFoxGait__ENTFoxGait_Run = 1,
	ENTFoxGait__ENTFoxGait_MAX = 2
};


// Enum Addons.EEndSpecialMoveReason
enum class EEndSpecialMoveReason : uint8_t
{
	EEndSpecialMoveReason__None = 0,
	EEndSpecialMoveReason__EndSMReason_UserOp = 1,
	EEndSpecialMoveReason__EndSMReason_Interrupted = 2,
	EEndSpecialMoveReason__EndSMReason_InvalidFloor = 3,
	EEndSpecialMoveReason__EndSMReason_InvalidMoveMode = 4,
	EEndSpecialMoveReason__EndSMReason_NoDriver = 5,
	EEndSpecialMoveReason__EndSMReason_NoFuel = 6,
	EEndSpecialMoveReason__EndSMReason_NoHealth = 7,
	EEndSpecialMoveReason__EndSMReason_ClientLoseConnection = 8,
	EEndSpecialMoveReason__EndSMReason_ServerCorrection = 9,
	EEndSpecialMoveReason__EndSMReason_ForceEnd = 10,
	EEndSpecialMoveReason__EndSMReason_InWater = 11,
	EEndSpecialMoveReason__EndSMReason_SkillEnd = 12,
	EEndSpecialMoveReason__MAX = 13
};


// Enum Addons.EMechaWeaponState
enum class EMechaWeaponState : uint8_t
{
	EMWS_None = 0,
	EMWS_Magnet = 1,
	EMWS_Missile = 2,
	EMWS_Speed = 3,
	EMWS_Boxing = 4,
	EMWS_Missile2 = 5,
	EMWS_MagnetToMissile = 6,
	EMWS_MagnetToSpeed = 7,
	EMWS_MagnetToBoxing = 8,
	EMWS_MissileToMagnet = 9,
	EMWS_MissileToBoxing = 10,
	EMWS_MissileToMissile2 = 11,
	EMWS_SpeedToMagnet = 12,
	EMWS_BoxingToMagnet = 13,
	EMWS_BoxingToMissile = 14,
	EMWS_BoxingToMissile2 = 15,
	EMWS_Missile2ToBoxing = 16,
	EMWS_Missile2ToMissile = 17,
	EMWS_MAX = 18
};


// Enum Addons.EMechaState
enum class EMechaState : uint8_t
{
	EMechaState__Normal = 0,
	EMechaState__Jump = 1,
	EMechaState__Fire = 2,
	EMechaState__Stumble = 3,
	EMechaState__Aim = 4,
	EMechaState__Dance = 5,
	EMechaState__Landing = 6,
	EMechaState__AirGliding = 7,
	EMechaState__Combine = 8,
	EMechaState__Uncombine = 9,
	EMechaState__Catch = 10,
	EMechaState__BeCatched = 11,
	EMechaState__Melee = 12,
	EMechaState__LaunchState = 13,
	EMechaState__Exploded = 14,
	EMechaState____MAX = 15,
	EMechaState__EMechaState_MAX = 16
};


// Enum Addons.ETransformerState
enum class ETransformerState : uint8_t
{
	ETransformerState__Normal = 0,
	ETransformerState__Jump = 1,
	ETransformerState__Dance = 2,
	ETransformerState__Landing = 3,
	ETransformerState__Melee = 4,
	ETransformerState__Exploded = 5,
	ETransformerState__HitStun = 6,
	ETransformerState__PostCast = 7,
	ETransformerState__Execute = 8,
	ETransformerState__BeExecuted = 9,
	ETransformerState__Born = 10,
	ETransformerState____MAX = 11,
	ETransformerState__ETransformerState_MAX = 12
};


// Enum Addons.ESnowMoveType
enum class ESnowMoveType : uint8_t
{
	ESnowMoveType__None = 0,
	ESnowMoveType__Idel = 1,
	ESnowMoveType__Move = 2,
	ESnowMoveType__Jump = 3,
	ESnowMoveType__ESnowMoveType_MAX = 4
};


// Enum Addons.EMeshPositionSourceMode
enum class EMeshPositionSourceMode : uint8_t
{
	EMeshPositionSourceMode__ArrangementOnly = 0,
	EMeshPositionSourceMode__AnchorTargetOnly = 1,
	EMeshPositionSourceMode__AnchorTargetWithArrangement = 2,
	EMeshPositionSourceMode__EMeshPositionSourceMode_MAX = 3
};


// Enum Addons.ERewindState
enum class ERewindState : uint8_t
{
	ERewindState__RewindNone = 0,
	ERewindState__RecordData = 1,
	ERewindState__RewindMove = 2,
	ERewindState__RewindEnd = 3,
	ERewindState__ERewindState_MAX = 4
};


// Enum Addons.EBioVehicleState
enum class EBioVehicleState : uint8_t
{
	EBioVehicleState__Move = 0,
	EBioVehicleState__Sprint = 1,
	EBioVehicleState__Stand = 2,
	EBioVehicleState__Crouch = 3,
	EBioVehicleState__Prone = 4,
	EBioVehicleState__Jump = 5,
	EBioVehicleState__Dead = 6,
	EBioVehicleState__Variation = 7,
	EBioVehicleState__Born = 8,
	EBioVehicleState__Stun = 9,
	EBioVehicleState__StunAnim = 10,
	EBioVehicleState__Shackle = 11,
	EBioVehicleState____MAX = 12,
	EBioVehicleState__EBioVehicleState_MAX = 13
};


// Enum Addons.EFlowerWingMoveState
enum class EFlowerWingMoveState : uint8_t
{
	EFlowerWingMoveState__None = 0,
	EFlowerWingMoveState__Sprint = 1,
	EFlowerWingMoveState__Float = 2,
	EFlowerWingMoveState__FlutterSprint = 3,
	EFlowerWingMoveState__FlutterSprintEnd = 4,
	EFlowerWingMoveState__Flash = 5,
	EFlowerWingMoveState__Diving = 6,
	EFlowerWingMoveState__EFlowerWingMoveState_MAX = 7
};


// Enum Addons.EWallSurfaceState
enum class EWallSurfaceState : uint8_t
{
	EWallSurfaceState__None = 0,
	EWallSurfaceState__OnVerticalWall = 1,
	EWallSurfaceState__OnCeiling = 2,
	EWallSurfaceState__TransitionCorner = 3,
	EWallSurfaceState__WallToCeiling = 4,
	EWallSurfaceState__CeilingToWall = 5,
	EWallSurfaceState__ExitWallToRoof = 6,
	EWallSurfaceState__ExitWallToFloor = 7,
	EWallSurfaceState__ExitWallDismount = 8,
	EWallSurfaceState__EWallSurfaceState_MAX = 9
};


// Enum Addons.EGhostBalloonMoveState
enum class EGhostBalloonMoveState : uint8_t
{
	EGhostBalloonMoveState__None = 0,
	EGhostBalloonMoveState__Rise = 1,
	EGhostBalloonMoveState__Float = 2,
	EGhostBalloonMoveState__Burst = 3,
	EGhostBalloonMoveState__EGhostBalloonMoveState_MAX = 4
};


// Enum Addons.EJumpPackMoveState
enum class EJumpPackMoveState : uint8_t
{
	EJumpPackMoveState__None = 0,
	EJumpPackMoveState__Boost = 1,
	EJumpPackMoveState__Descending = 2,
	EJumpPackMoveState__Landing = 3,
	EJumpPackMoveState__EJumpPackMoveState_MAX = 4
};


// Enum Addons.ELeaveNinjaTeamReason
enum class ELeaveNinjaTeamReason : uint8_t
{
	ELeaveNinjaTeamReason__ELNTR_Request = 0,
	ELeaveNinjaTeamReason__ELNTR_OutOfDistance = 1,
	ELeaveNinjaTeamReason__ELNTR_MAX = 2
};


// Enum Addons.EODMGearMoveState
enum class EODMGearMoveState : uint8_t
{
	EODMGearMoveState__None = 0,
	EODMGearMoveState__Sprint = 1,
	EODMGearMoveState__Rise = 2,
	EODMGearMoveState__Spin = 3,
	EODMGearMoveState__SpinEnd = 4,
	EODMGearMoveState__EODMGearMoveState_MAX = 5
};


// Enum Addons.ESpiderSwingMoveState
enum class ESpiderSwingMoveState : uint8_t
{
	ESpiderSwingMoveState__None = 0,
	ESpiderSwingMoveState__Launching = 1,
	ESpiderSwingMoveState__Swinging = 2,
	ESpiderSwingMoveState__Releasing = 3,
	ESpiderSwingMoveState__Falling = 4,
	ESpiderSwingMoveState__Landing = 5,
	ESpiderSwingMoveState__ESpiderSwingMoveState_MAX = 6
};


// Enum Addons.EPterosaurSwoopStage
enum class EPterosaurSwoopStage : uint8_t
{
	EPterosaurSwoopStage__ESwoopStage_None = 0,
	EPterosaurSwoopStage__ESwoopStage_Ready = 1,
	EPterosaurSwoopStage__ESwoopStage_DirectionCorrect = 2,
	EPterosaurSwoopStage__ESwoopStage_SwoopMove = 3,
	EPterosaurSwoopStage__ESwoopStage_PreCatch = 4,
	EPterosaurSwoopStage__ESwoopStage_Catch = 5,
	EPterosaurSwoopStage__ESwoopStage_Finish = 6,
	EPterosaurSwoopStage__ESwoopStage_FinishNoCatch = 7,
	EPterosaurSwoopStage__ESwoopStage_FinishNoCatchWithHit = 8,
	EPterosaurSwoopStage__ESwoopStage_MAX = 9
};


// Enum Addons.EBallVehicleMotionState
enum class EBallVehicleMotionState : uint8_t
{
	EBallVehicleMotionState__ENormalState = 0,
	EBallVehicleMotionState__EReadyForKick = 1,
	EBallVehicleMotionState__EInJumpState = 2,
	EBallVehicleMotionState__EInSecondJumpState = 3,
	EBallVehicleMotionState__EBallVehicleMotionState_MAX = 4
};


// Enum Addons.EStealthMoveState
enum class EStealthMoveState : uint8_t
{
	EStealthMoveState__None = 0,
	EStealthMoveState__GoUnderground = 1,
	EStealthMoveState__Moving = 2,
	EStealthMoveState__MovingBlocked = 3,
	EStealthMoveState__Exposure = 4,
	EStealthMoveState__Falling = 5,
	EStealthMoveState__Landing = 6,
	EStealthMoveState__GoOut = 7,
	EStealthMoveState__EStealthMoveState_MAX = 8
};


// Enum Addons.EMountFromDirection
enum class EMountFromDirection : uint8_t
{
	EMFD_Default = 0,
	EMFD_Forward = 1,
	EMFD_Back = 2,
	EMFD_Left = 3,
	EMFD_Right = 4,
	EMFD_Origin = 5,
	EMFD_MAX = 6
};


// Enum Addons.EHorseTransformType
enum class EHorseTransformType : uint8_t
{
	EHorseTransformType__HTT_None = 0,
	EHorseTransformType__HTT_Appear = 1,
	EHorseTransformType__HTT_Disappear = 2,
	EHorseTransformType__HTT_Death = 3,
	EHorseTransformType__HTT_MAX = 4
};


// Enum Addons.EBlanketDanceState
enum class EBlanketDanceState : uint8_t
{
	EBDS_Locomotion = 0,
	EBDS_ReadyToDance = 1,
	EBDS_Dancing = 2,
	EBDS_Idle = 3,
	EBDS_MAX = 4
};


// Enum Addons.EBlankVehicleSwitchFailedReason
enum class EBlankVehicleSwitchFailedReason : uint8_t
{
	EBlankVehicleSwitchFailedReason__ESwitchTraceInvalid = 0,
	EBlankVehicleSwitchFailedReason__ESwitchInterrupted = 1,
	EBlankVehicleSwitchFailedReason__EBlankVehicleSwitchFailedReason_MAX = 2
};


// Enum Addons.EBroomChargeState
enum class EBroomChargeState : uint8_t
{
	EBroomChargeState__BroomChargeState_None = 0,
	EBroomChargeState__BroomChargeState_Charging = 1,
	EBroomChargeState__BroomChargeState_Dashing = 2,
	EBroomChargeState__BroomChargeState_Atk = 3,
	EBroomChargeState__BroomChargeState_CoolDown = 4,
	EBroomChargeState__BroomChargeState_MAX = 5
};


// Enum Addons.EFlyBioVehicleBaseMoveMode
enum class EFlyBioVehicleBaseMoveMode : uint8_t
{
	EFlyBioVehicleBaseMoveMode__EMove_TakingOff = 0,
	EFlyBioVehicleBaseMoveMode__EMove_RegularFlying = 1,
	EFlyBioVehicleBaseMoveMode__EMove_Landing = 2,
	EFlyBioVehicleBaseMoveMode__EMove_MAX = 3
};


// Enum Addons.EEndDashErrorCode
enum class EEndDashErrorCode : uint8_t
{
	EEndDashErrorCode__EndDash_None = 0,
	EEndDashErrorCode__EndDash_TimeOver = 1,
	EEndDashErrorCode__EndDash_MoveBlocked = 2,
	EEndDashErrorCode__EndDash_ForceEnd = 3,
	EEndDashErrorCode__EndDash_ServerAdjust = 4,
	EEndDashErrorCode__EndDash_MAX = 5
};


// Enum Addons.ECatapultMachineStateType
enum class ECatapultMachineStateType : uint8_t
{
	ECatapultMachineStateType__CMState_Initial = 0,
	ECatapultMachineStateType__CMState_ChargeReady = 1,
	ECatapultMachineStateType__CMState_Charge = 2,
	ECatapultMachineStateType__CMState_Launch = 3,
	ECatapultMachineStateType__CMState_Cooldown = 4,
	ECatapultMachineStateType__CMState_Supplement = 5,
	ECatapultMachineStateType__CMState_MAX = 6
};


// Enum Addons.ENitrogenAccelState
enum class ENitrogenAccelState : uint8_t
{
	ENitrogenAccelState__None = 0,
	ENitrogenAccelState__Ready = 1,
	ENitrogenAccelState__Bounce = 2,
	ENitrogenAccelState__SideAccel = 3,
	ENitrogenAccelState__Accel = 4,
	ENitrogenAccelState__CoolDown = 5,
	ENitrogenAccelState__ENitrogenAccelState_MAX = 6
};


// Enum Addons.EHitDir
enum class EHitDir : uint8_t
{
	EHitDir__None = 0,
	EHitDir__forward = 1,
	EHitDir__right = 2,
	EHitDir__back = 3,
	EHitDir__left = 4,
	EHitDir__EHitDir_MAX = 5
};


// Enum Addons.ESnowBallBrokenReason
enum class ESnowBallBrokenReason : uint8_t
{
	ESnowBallBrokenReason__BrokenReason_Unknown = 0,
	ESnowBallBrokenReason__BrokenReason_ImpactObstacle = 1,
	ESnowBallBrokenReason__BrokenReason_ImpactVehicle = 2,
	ESnowBallBrokenReason__BrokenReason_ImpactCharacter = 3,
	ESnowBallBrokenReason__BrokenReason_ImpactNpc = 4,
	ESnowBallBrokenReason__BrokenReason_GroundSlope = 5,
	ESnowBallBrokenReason__BrokenReason_Falling = 6,
	ESnowBallBrokenReason__BrokenReason_Swimming = 7,
	ESnowBallBrokenReason__BrokenReason_NoDriver = 8,
	ESnowBallBrokenReason__BrokenReason_PlayerBreak = 9,
	ESnowBallBrokenReason__BrokenReason_Damaged = 10,
	ESnowBallBrokenReason__BrokenReason_FreeEnoughTime = 11,
	ESnowBallBrokenReason__BrokenReason_MAX = 12
};


// Enum Addons.EStopDriftCheck
enum class EStopDriftCheck : uint8_t
{
	EStopDriftCheck__Drift_SpeedCheck = 0,
	EStopDriftCheck__Drift_RotationCheck = 1,
	EStopDriftCheck__Drift_Interrupt = 2,
	EStopDriftCheck__Drift_None = 3,
	EStopDriftCheck__Drift_MAX = 4
};


// Enum Addons.EAmphibiousBoatInflationState
enum class EAmphibiousBoatInflationState : uint8_t
{
	EAmphibiousBoatInflationState__Deflated = 0,
	EAmphibiousBoatInflationState__Deflating = 1,
	EAmphibiousBoatInflationState__Inflated = 2,
	EAmphibiousBoatInflationState__Inflating = 3,
	EAmphibiousBoatInflationState__EAmphibiousBoatInflationState_MAX = 4
};


// Enum Addons.EAnimalMoveDir
enum class EAnimalMoveDir : uint8_t
{
	EMove_Forward = 0,
	EMove_Left = 1,
	EMove_Right = 2,
	EMove_Backward = 3,
	EMove_MAX = 4
};


// Enum Addons.EBlendCrossFadeOption
enum class EBlendCrossFadeOption : uint8_t
{
	EBlendCrossFadeOption__EBSBlend_None = 0,
	EBlendCrossFadeOption__EBCFO_BlendSpace = 1,
	EBlendCrossFadeOption__EBlendCrossFadeOption_MAX = 2
};


// Enum Addons.EOffsetRootBoneMode
enum class EOffsetRootBoneMode : uint8_t
{
	EOffsetRootBoneMode__Accumulate = 0,
	EOffsetRootBoneMode__Interpolate = 1,
	EOffsetRootBoneMode__Simulate = 2,
	EOffsetRootBoneMode__Release = 3,
	EOffsetRootBoneMode__None = 4,
	EOffsetRootBoneMode__EOffsetRootBoneMode_MAX = 5
};


// Enum Addons.EAttachedOwnerResolveMode
enum class EAttachedOwnerResolveMode : uint8_t
{
	EAttachedOwnerResolveMode__Self = 0,
	EAttachedOwnerResolveMode__Owner = 1,
	EAttachedOwnerResolveMode__AttachParent = 2,
	EAttachedOwnerResolveMode__EAttachedOwnerResolveMode_MAX = 3
};


// Enum Addons.EAxisLockType
enum class EAxisLockType : uint8_t
{
	EAxisLockType__None = 0,
	EAxisLockType__X = 1,
	EAxisLockType__Y = 2,
	EAxisLockType__Z = 3,
	EAxisLockType__XY = 4,
	EAxisLockType__XZ = 5,
	EAxisLockType__YZ = 6,
	EAxisLockType__EAxisLockType_MAX = 7
};


// Enum Addons.EFlyBioVehicleMoveMode
enum class EFlyBioVehicleMoveMode : uint8_t
{
	EFlyBioVehicleMoveMode__EMove_TakingOff = 0,
	EFlyBioVehicleMoveMode__EMove_RegularFlying = 1,
	EFlyBioVehicleMoveMode__EMove_MAX = 2
};


// Enum Addons.EBioFlyMoveState
enum class EBioFlyMoveState : uint8_t
{
	EBioFlyMoveState__None = 0,
	EBioFlyMoveState__TakingOff = 1,
	EBioFlyMoveState__RegularFlying = 2,
	EBioFlyMoveState__Landing = 3,
	EBioFlyMoveState__EBioFlyMoveState_MAX = 4
};


// Enum Addons.EFlyVerticalCalcMode
enum class EFlyVerticalCalcMode : uint8_t
{
	EFlyVerticalCalcMode__InputClamped = 0,
	EFlyVerticalCalcMode__CurveDriven = 1,
	EFlyVerticalCalcMode__EFlyVerticalCalcMode_MAX = 2
};


// Enum Addons.EFlyVelocityCalcMode
enum class EFlyVelocityCalcMode : uint8_t
{
	EFlyVelocityCalcMode__SteeredBraking = 0,
	EFlyVelocityCalcMode__CurveControlled = 1,
	EFlyVelocityCalcMode__EFlyVelocityCalcMode_MAX = 2
};


// Enum Addons.EBirdCageStatus
enum class EBirdCageStatus : uint8_t
{
	EBirdCageStatus__None = 0,
	EBirdCageStatus__Alive = 1,
	EBirdCageStatus__Destoryed = 2,
	EBirdCageStatus__EBirdCageStatus_MAX = 3
};


// Enum Addons.EBlankVehicleBaseMoveMode
enum class EBlankVehicleBaseMoveMode : uint8_t
{
	EBlankVehicleBaseMoveMode__EMove_LowFlying = 0,
	EBlankVehicleBaseMoveMode__EMove_HighFlying = 1,
	EBlankVehicleBaseMoveMode__EMove_RiseToHigh = 2,
	EBlankVehicleBaseMoveMode__EMove_DropToLow = 3,
	EBlankVehicleBaseMoveMode__EMove_Diving = 4,
	EBlankVehicleBaseMoveMode__EMove_MAX = 5
};


// Enum Addons.EBlanketFlyingState
enum class EBlanketFlyingState : uint8_t
{
	EBFS_LOW = 0,
	EBFS_LOW_TO_HIGH = 1,
	EBFS_HIGH = 2,
	EBFS_HIGH_TO_LOW = 3,
	EBFS_DIVING = 4,
	EBFS_MAX = 5
};


// Enum Addons.ECharBoardMoveLeisureStyle
enum class ECharBoardMoveLeisureStyle : uint8_t
{
	ECharBoardMoveLeisureStyle__ERandom = 0,
	ECharBoardMoveLeisureStyle__ENarrow = 1,
	ECharBoardMoveLeisureStyle__Default = 2,
	ECharBoardMoveLeisureStyle__ECharBoardMoveLeisureStyle_MAX = 3
};


// Enum Addons.EPendingSpawnLayoutMode
enum class EPendingSpawnLayoutMode : uint8_t
{
	EPendingSpawnLayoutMode__Arrangement = 0,
	EPendingSpawnLayoutMode__AnchorTargetOnly = 1,
	EPendingSpawnLayoutMode__EPendingSpawnLayoutMode_MAX = 2
};


// Enum Addons.ECamelPostureState
enum class ECamelPostureState : uint8_t
{
	ECS_Idle = 0,
	ECS_Rest = 1,
	ECS_Dance = 2,
	ECS_Moving = 3,
	ECS_MAX = 4
};


// Enum Addons.EVOFlag
enum class EVOFlag : uint8_t
{
	EVOFlag__EVOFlag_None = 0,
	EVOFlag__EVOFlag_VelocityUpdate = 1,
	EVOFlag__EVOFlag_Stop = 2,
	EVOFlag__EVOFlag_JumpOver = 3,
	EVOFlag__EVOFlag_FlyOver = 4,
	EVOFlag__EVOFlag_MAX = 5
};


// Enum Addons.ECollectedEventDataEventId
enum class ECollectedEventDataEventId : uint8_t
{
	ECollectedEventDataEventId__GameStatus = 0,
	ECollectedEventDataEventId__StartMatching = 1,
	ECollectedEventDataEventId__PlaneCarrying = 2,
	ECollectedEventDataEventId__PuttingDownCakeFireWorks = 3,
	ECollectedEventDataEventId__RankingScore = 4,
	ECollectedEventDataEventId__TakeDropItem = 5,
	ECollectedEventDataEventId__UsingItem = 6,
	ECollectedEventDataEventId__Falling = 7,
	ECollectedEventDataEventId__Climbing = 8,
	ECollectedEventDataEventId__InFieldOfView = 9,
	ECollectedEventDataEventId__UnderEnermyAttack = 10,
	ECollectedEventDataEventId__TakingDamage = 11,
	ECollectedEventDataEventId__ReducingSignalValue = 12,
	ECollectedEventDataEventId__CircleReducing = 13,
	ECollectedEventDataEventId__CircleChange = 14,
	ECollectedEventDataEventId__Rescue = 15,
	ECollectedEventDataEventId__DrivingVehicle = 16,
	ECollectedEventDataEventId__ReloadingBullet = 17,
	ECollectedEventDataEventId__AirDrop = 18,
	ECollectedEventDataEventId__PlayerPos = 19,
	ECollectedEventDataEventId__WeaponUsage = 20,
	ECollectedEventDataEventId__ItemPackageCreate = 21,
	ECollectedEventDataEventId__ItemAttach = 22,
	ECollectedEventDataEventId__ItemDetach = 23,
	ECollectedEventDataEventId__PlayerInfo = 24,
	ECollectedEventDataEventId__MiniMapShowInfo = 25,
	ECollectedEventDataEventId__Following = 26,
	ECollectedEventDataEventId__MiniMapPinning = 27,
	ECollectedEventDataEventId__Blocking = 28,
	ECollectedEventDataEventId__Dancing = 29,
	ECollectedEventDataEventId__PickingupTombBox = 30,
	ECollectedEventDataEventId__AirAttacking = 31,
	ECollectedEventDataEventId__CurrentWeapon = 32,
	ECollectedEventDataEventId__SceneInfo = 33,
	ECollectedEventDataEventId__TeamInfo = 34,
	ECollectedEventDataEventId__EnteringLeavingTeam = 35,
	ECollectedEventDataEventId__OnOffline = 36,
	ECollectedEventDataEventId__RankList = 37,
	ECollectedEventDataEventId__TextMessage = 38,
	ECollectedEventDataEventId__PawnState = 39,
	ECollectedEventDataEventId__OpenCloseDoor = 40,
	ECollectedEventDataEventId__MicSpeakerState = 41,
	ECollectedEventDataEventId__VehicleState = 42,
	ECollectedEventDataEventId__EnumMax = 43,
	ECollectedEventDataEventId__ECollectedEventDataEventId_MAX = 44
};


// Enum Addons.EDancingState
enum class EDancingState : uint8_t
{
	DancingState_Default = 0,
	DancingState_PrepareMove = 1,
	DancingState_DanceMoving = 2,
	DancingState_EndMove = 3,
	DancingState_Dancing = 4,
	DancingState_Battle = 5,
	DancingState_MAX = 6
};


// Enum Addons.EEventDataCollectionValues_MicSpeakerState_Speaker
enum class EEventDataCollectionValues_MicSpeakerState_Speaker : uint8_t
{
	EEventDataCollectionValues_MicSpeakerState_Speaker__None = 0,
	EEventDataCollectionValues_MicSpeakerState_Speaker__Lbs = 1,
	EEventDataCollectionValues_MicSpeakerState_Speaker__Team = 2,
	EEventDataCollectionValues_MicSpeakerState_Speaker__EEventDataCollectionValues_MicSpeakerState_MAX = 3
};


// Enum Addons.EEventDataCollectionValues_MicSpeakerState_Mic
enum class EEventDataCollectionValues_MicSpeakerState_Mic : uint8_t
{
	EEventDataCollectionValues_MicSpeakerState_Mic__None = 0,
	EEventDataCollectionValues_MicSpeakerState_Mic__Lbs = 1,
	EEventDataCollectionValues_MicSpeakerState_Mic__Team = 2,
	EEventDataCollectionValues_MicSpeakerState_Mic__KeyLbs = 3,
	EEventDataCollectionValues_MicSpeakerState_Mic__KeyTeam = 4,
	EEventDataCollectionValues_MicSpeakerState_Mic__EEventDataCollectionValues_MicSpeakerState_MAX = 5
};


// Enum Addons.EEventDataCollectionValues_RankList_Type
enum class EEventDataCollectionValues_RankList_Type : uint8_t
{
	EEventDataCollectionValues_RankList_Type__None = 0,
	EEventDataCollectionValues_RankList_Type__Hot = 1,
	EEventDataCollectionValues_RankList_Type__Lucky = 2,
	EEventDataCollectionValues_RankList_Type__EEventDataCollectionValues_RankList_MAX = 3
};


// Enum Addons.EFAMActiveState
enum class EFAMActiveState : uint8_t
{
	EFAMActiveState__None = 0,
	EFAMActiveState__Magnet = 1,
	EFAMActiveState__EFAMActiveState_MAX = 2
};


// Enum Addons.EFAMFlyModeType
enum class EFAMFlyModeType : uint8_t
{
	EFAMFlyModeType__None = 0,
	EFAMFlyModeType__Normal = 1,
	EFAMFlyModeType__HighSpeed = 2,
	EFAMFlyModeType__EFAMFlyModeType_MAX = 3
};


// Enum Addons.EFlyCloudState
enum class EFlyCloudState : uint8_t
{
	CLOUD_FLY_NONE = 0,
	CLOUD_FLY_START = 1,
	CLOUD_FLY_FLOAT = 2,
	CLOUD_FLY_MAX = 3
};


// Enum Addons.EFlySprintDirMode
enum class EFlySprintDirMode : uint8_t
{
	EFlySprintDirMode__FixedDirection = 0,
	EFlySprintDirMode__ActorForward = 1,
	EFlySprintDirMode__ToDestLocation = 2,
	EFlySprintDirMode__EFlySprintDirMode_MAX = 3
};


// Enum Addons.EFrostDragonMoveMode
enum class EFrostDragonMoveMode : uint8_t
{
	EFrostDragonMoveMode__EMove_Idle = 0,
	EFrostDragonMoveMode__EMove_TakingOff = 1,
	EFrostDragonMoveMode__EMove_RegularFlying = 2,
	EFrostDragonMoveMode__EMove_Landing = 3,
	EFrostDragonMoveMode__EMove_LandingWalking = 4,
	EFrostDragonMoveMode__EMove_MAX = 5
};


// Enum Addons.EHoverSimulateState
enum class EHoverSimulateState : uint8_t
{
	EHoverSimulateState__Idle = 0,
	EHoverSimulateState__Simple = 1,
	EHoverSimulateState__Complex = 2,
	EHoverSimulateState__EHoverSimulateState_MAX = 3
};


// Enum Addons.EPoleVectorModeEnum
enum class EPoleVectorModeEnum : uint8_t
{
	PV_None = 0,
	PV_Position = 1,
	PV_Bone = 2,
	PV_AngleOffset = 3,
	PV_MAX = 4
};


// Enum Addons.EEffectorSpaceEnum
enum class EEffectorSpaceEnum : uint8_t
{
	ES_Additive = 0,
	ES_World = 1,
	ES_Component = 2,
	ES_MAX = 3
};


// Enum Addons.ELadderMoveType
enum class ELadderMoveType : uint8_t
{
	ELadderMove_None = 0,
	ELadderMove_Idle = 1,
	ELadderMove_Up = 2,
	ELadderMove_Down = 3,
	ELadderMove_JumpToTop = 4,
	ELadderMove_ExitFromBottom = 5,
	ELadderMove_EnterFromTop = 6,
	ELadderMove_EnterFromBottom = 7,
	ELadderMove_MAX = 8
};


// Enum Addons.EMoveDirection
enum class EMoveDirection : uint8_t
{
	EMD_F = 0,
	EMD_FL = 1,
	EMD_FR = 2,
	EMD_B = 3,
	EMD_BL = 4,
	EMD_BR = 5,
	EMD_L = 6,
	EMD_R = 7,
	EMD_MAX = 8
};


// Enum Addons.EBioLocomotionType
enum class EBioLocomotionType : uint8_t
{
	EBioLocomotionType__EBLT_Walk_F = 0,
	EBioLocomotionType__EBLT_Walk_B = 1,
	EBioLocomotionType__EBLT_Walk_L = 2,
	EBioLocomotionType__EBLT_Walk_R = 3,
	EBioLocomotionType__EBLT_Run_F = 4,
	EBioLocomotionType__EBLT_Run_B = 5,
	EBioLocomotionType__EBLT_RunLF = 6,
	EBioLocomotionType__EBLT_Run_R = 7,
	EBioLocomotionType__EBLT_MAX = 8
};


// Enum Addons.EMechaMoveCustomMode
enum class EMechaMoveCustomMode : uint8_t
{
	EMechaMoveCustomMode__EMove_None = 0,
	EMechaMoveCustomMode__EMove_Glide = 1,
	EMechaMoveCustomMode__EMove_Landing = 2,
	EMechaMoveCustomMode__EMove_MAX = 3
};


// Enum Addons.ECombineState
enum class ECombineState : uint8_t
{
	ECS_COMBINE = 0,
	ECS_UNCOMBINE = 1,
	ECS_None = 2
};


// Enum Addons.EMirrorFindReplaceMethod
enum class EMirrorFindReplaceMethod : uint8_t
{
	Prefix = 0,
	Suffix = 1,
	RegularExpression = 2,
	EMirrorFindReplaceMethod_MAX = 3
};


// Enum Addons.ECreateSkillItemType
enum class ECreateSkillItemType : uint8_t
{
	ECreateSkillItemType__WaterCheckOnly = 0,
	ECreateSkillItemType__SlopeCheck = 1,
	ECreateSkillItemType__BuildSystemCheck = 2,
	ECreateSkillItemType__AssociateActorDistance = 3,
	ECreateSkillItemType__HeightDifferenceCheck = 4,
	ECreateSkillItemType__ECreateSkillItemType_MAX = 5
};


// Enum Addons.ENinjaTeamShape
enum class ENinjaTeamShape : uint8_t
{
	ENinjaTeamShape__ENTT_Triangle = 0,
	ENinjaTeamShape__ENTT_LineX = 1,
	ENinjaTeamShape__ENTT_MAX = 2
};


// Enum Addons.ENinjaMoveType
enum class ENinjaMoveType : uint8_t
{
	ENMT_Leader = 0,
	ENMT_Follower = 1,
	ENMT_MAX = 2
};


// Enum Addons.ENTFoxScanDir
enum class ENTFoxScanDir : uint8_t
{
	ENTFoxScanDir__Forward = 0,
	ENTFoxScanDir__Backward = 1,
	ENTFoxScanDir__Right = 2,
	ENTFoxScanDir__Left = 3,
	ENTFoxScanDir__Around = 4,
	ENTFoxScanDir__ENTFoxScanDir_MAX = 5
};


// Enum Addons.ENTFoxPrecisePredictionMode
enum class ENTFoxPrecisePredictionMode : uint8_t
{
	ENTFoxPrecisePredictionMode__Disabled = 0,
	ENTFoxPrecisePredictionMode__StopAtTarget = 1,
	ENTFoxPrecisePredictionMode__FixedScale = 2,
	ENTFoxPrecisePredictionMode__ENTFoxPrecisePredictionMode_MAX = 3
};


// Enum Addons.EUploadAPIResponse
enum class EUploadAPIResponse : uint8_t
{
	EUploadAPIResponse__EUploadAPIResponse_Success = 0,
	EUploadAPIResponse__EUploadAPIResponse_NotSuccessful = 1,
	EUploadAPIResponse__EUploadAPIResponse_ResponseInvalid = 2,
	EUploadAPIResponse__EUploadAPIResponse_NotOK = 3,
	EUploadAPIResponse__EUploadAPIResponse_MAX = 4
};


// Enum Addons.EOceanVehicleBaseMoveMode
enum class EOceanVehicleBaseMoveMode : uint8_t
{
	EOceanVehicleBaseMoveMode__EMove_LowFlying = 0,
	EOceanVehicleBaseMoveMode__EMove_Diving = 1,
	EOceanVehicleBaseMoveMode__EMove_MAX = 2
};


// Enum Addons.EPandaIdleMode
enum class EPandaIdleMode : uint8_t
{
	EPandaIdleMode__ENPC = 0,
	EPandaIdleMode__EDaze = 1,
	EPandaIdleMode__EBeVehicle = 2,
	EPandaIdleMode__EMax = 3,
	EPandaIdleMode__EPandaIdleMode_MAX = 4
};


// Enum Addons.EPandaFootIKStyle
enum class EPandaFootIKStyle : uint8_t
{
	EPandaFootIKStyle__EDefault = 0,
	EPandaFootIKStyle__EAdIK = 1,
	EPandaFootIKStyle__EPandaFootIKStyle_MAX = 2
};


// Enum Addons.EMonsterLeisureStyle
enum class EMonsterLeisureStyle : uint8_t
{
	EMonsterLeisureStyle__ESmall = 0,
	EMonsterLeisureStyle__EBig = 1,
	EMonsterLeisureStyle__EMonsterLeisureStyle_MAX = 2
};


// Enum Addons.EVehicleEmoteInteractType
enum class EVehicleEmoteInteractType : uint8_t
{
	EVehicleEmoteInteractType__ENPC_Interact = 0,
	EVehicleEmoteInteractType__EBeControl = 1,
	EVehicleEmoteInteractType__EMax = 2,
	EVehicleEmoteInteractType__EVehicleEmoteInteractType_MAX = 3
};


// Enum Addons.EFlyGroundType
enum class EFlyGroundType : uint8_t
{
	EFGT_Default = 0,
	EFGT_Water = 1,
	EFGT_Snow = 2,
	EFGT_MAX = 3
};


// Enum Addons.EFlyHeightType
enum class EFlyHeightType : uint8_t
{
	EFHT_Ground = 0,
	EFHT_LowAir = 1,
	EFHT_HighAir = 2,
	EFHT_MAX = 3
};


// Enum Addons.ESnowBallState
enum class ESnowBallState : uint8_t
{
	ESnowBallState__SnowBall_Unknown = 0,
	ESnowBallState__SnowBall_Attached = 1,
	ESnowBallState__SnowBall_Free = 2,
	ESnowBallState__SnowBall_Broken = 3,
	ESnowBallState__SnowBall_MAX = 4
};


// Enum Addons.ETraceMissedFallback
enum class ETraceMissedFallback : uint8_t
{
	ETraceMissedFallback__None = 0,
	ETraceMissedFallback__GroundTrace = 1,
	ETraceMissedFallback__EndPoint = 2,
	ETraceMissedFallback__ETraceMissedFallback_MAX = 3
};


// Enum Addons.EPickTargetMode
enum class EPickTargetMode : uint8_t
{
	EPickTargetMode__LineTrace = 0,
	EPickTargetMode__Sweep = 1,
	EPickTargetMode__Screen = 2,
	EPickTargetMode__FanSweep = 3,
	EPickTargetMode__EPickTargetMode_MAX = 4
};


// Enum Addons.EPterosaurMoveMode
enum class EPterosaurMoveMode : uint8_t
{
	EPterosaurMoveMode__EMove_Idle = 0,
	EPterosaurMoveMode__EMove_TakingOff = 1,
	EPterosaurMoveMode__EMove_RegularFlying = 2,
	EPterosaurMoveMode__EMove_Diving = 3,
	EPterosaurMoveMode__EMove_Landing = 4,
	EPterosaurMoveMode__EMove_SwoopDown = 5,
	EPterosaurMoveMode__EMove_MAX = 6
};


// Enum Addons.ESwingVerticalPhase
enum class ESwingVerticalPhase : uint8_t
{
	ESwingVerticalPhase__None = 0,
	ESwingVerticalPhase__SwingUp = 1,
	ESwingVerticalPhase__SwingDown = 2,
	ESwingVerticalPhase__SwingPeak = 3,
	ESwingVerticalPhase__ESwingVerticalPhase_MAX = 4
};


// Enum Addons.ESpiderSwingHandSide
enum class ESpiderSwingHandSide : uint8_t
{
	ESpiderSwingHandSide__None = 0,
	ESpiderSwingHandSide__Left = 1,
	ESpiderSwingHandSide__Right = 2,
	ESpiderSwingHandSide__Mid = 3,
	ESpiderSwingHandSide__ESpiderSwingHandSide_MAX = 4
};


// Enum Addons.EAttachRelativeLocation
enum class EAttachRelativeLocation : uint8_t
{
	EAttachRelativeLocation__None = 0,
	EAttachRelativeLocation__Bottom = 1,
	EAttachRelativeLocation__Middle = 2,
	EAttachRelativeLocation__Top = 3,
	EAttachRelativeLocation__EAttachRelativeLocation_MAX = 4
};


// Enum Addons.EHitFilterType
enum class EHitFilterType : uint8_t
{
	EHitFilterType__EFilterByGun = 0,
	EHitFilterType__EFilterByBullet = 1,
	EHitFilterType__EHitFilterType_MAX = 2
};


// Enum Addons.EBuffForceFinishVelocityMode
enum class EBuffForceFinishVelocityMode : uint8_t
{
	EBuffForceFinishVelocityMode__MaintainLastVelocity = 0,
	EBuffForceFinishVelocityMode__SetZero = 1,
	EBuffForceFinishVelocityMode__ClampVelocity = 2,
	EBuffForceFinishVelocityMode__EBuffForceFinishVelocityMode_MAX = 3
};


// Enum Addons.EBuffForceDirection
enum class EBuffForceDirection : uint8_t
{
	EBuffForceDirection__CauserToOwner = 0,
	EBuffForceDirection__OwnerToCauser = 1,
	EBuffForceDirection__WorldDirection = 2,
	EBuffForceDirection__CauserForward = 3,
	EBuffForceDirection__DynamicBlackboard = 4,
	EBuffForceDirection__EBuffForceDirection_MAX = 5
};


// Enum Addons.EBuffContinuousForceMode
enum class EBuffContinuousForceMode : uint8_t
{
	EBuffContinuousForceMode__AddImpulse = 0,
	EBuffContinuousForceMode__AddForce = 1,
	EBuffContinuousForceMode__Launch = 2,
	EBuffContinuousForceMode__RequestDirectMove = 3,
	EBuffContinuousForceMode__RootMotionConstantForce = 4,
	EBuffContinuousForceMode__EBuffContinuousForceMode_MAX = 5
};


// Enum Addons.EBuffRequestDirectMoveType
enum class EBuffRequestDirectMoveType : uint8_t
{
	BRDMT_Dynamic = 0,
	BRDMT_Fix = 1,
	BRDMT_Causer = 2,
	BRDMT_MAX = 3
};


// Enum Addons.EBuffDotValueType
enum class EBuffDotValueType : uint8_t
{
	EBuffDotValueType__BurningDamage = 0,
	EBuffDotValueType__ShootWeaponDamage = 1,
	EBuffDotValueType__AddHealth = 2,
	EBuffDotValueType__AddBulletNum = 3,
	EBuffDotValueType__AddArmor = 4,
	EBuffDotValueType__AddHelmet = 5,
	EBuffDotValueType__PoisonFogDamage = 6,
	EBuffDotValueType__AddEnergy = 7,
	EBuffDotValueType__AddWeaponDurability = 8,
	EBuffDotValueType__DotDamage = 9,
	EBuffDotValueType__SkillBlackboardInt = 10,
	EBuffDotValueType__SkillBlackboardFloat = 11,
	EBuffDotValueType__Drowning = 12,
	EBuffDotValueType__AddAttr = 13,
	EBuffDotValueType__EBuffDotValueType_MAX = 14
};


// Enum Addons.EBuffSenseTargetState
enum class EBuffSenseTargetState : uint8_t
{
	EBuffSenseTargetState__Sensing = 0,
	EBuffSenseTargetState__HasEnemy = 1,
	EBuffSenseTargetState__WaitSense = 2,
	EBuffSenseTargetState__EBuffSenseTargetState_MAX = 3
};


// Enum Addons.ELaunchDirectionType
enum class ELaunchDirectionType : uint8_t
{
	ELaunchDirectionType__UseLaunchCenter = 0,
	ELaunchDirectionType__UseSelfRotation = 1,
	ELaunchDirectionType__UseCauserRotation = 2,
	ELaunchDirectionType__FarAwayFromCauser = 3,
	ELaunchDirectionType__UseWorldDirection = 4,
	ELaunchDirectionType__ELaunchDirectionType_MAX = 5
};


// Enum Addons.EBuffMofifyDurationType
enum class EBuffMofifyDurationType : uint8_t
{
	EBuffMofifyDurationType__RefCauserDistance = 0,
	EBuffMofifyDurationType__RefMonsterType = 1,
	EBuffMofifyDurationType__RefOneAndTwo = 2,
	EBuffMofifyDurationType__EBuffMofifyDurationType_MAX = 3
};


// Enum Addons.EBuffModifyPropertyType
enum class EBuffModifyPropertyType : uint8_t
{
	EBMPT_Bool = 0,
	EBMPT_Int = 1,
	EBMPT_Float = 2,
	EBMPT_String = 3,
	EBMPT_MAX = 4
};


// Enum Addons.ERotateCharacterType
enum class ERotateCharacterType : uint8_t
{
	ERotateCharacterType__RotateToCauser = 0,
	ERotateCharacterType__RotateAsCauser = 1,
	ERotateCharacterType__ERotateCharacterType_MAX = 2
};


// Enum Addons.EUSTCheckCastingSkillType
enum class EUSTCheckCastingSkillType : uint8_t
{
	EUSTCheckCastingSkillType__EUSTCheckCastingSkillType_Any = 0,
	EUSTCheckCastingSkillType__EUSTCheckCastingSkillType_AnyNot = 1,
	EUSTCheckCastingSkillType__EUSTCheckCastingSkillType_All = 2,
	EUSTCheckCastingSkillType__EUSTCheckCastingSkillType_AllNot = 3,
	EUSTCheckCastingSkillType__EUSTCheckCastingSkillType_MAX = 4
};


// Enum Addons.EUSTCheckCastingBuffType
enum class EUSTCheckCastingBuffType : uint8_t
{
	EUSTCheckCastingBuffType__EUSTCheckCastingBuffType_Any = 0,
	EUSTCheckCastingBuffType__EUSTCheckCastingBuffType_AnyNot = 1,
	EUSTCheckCastingBuffType__EUSTCheckCastingBuffType_All = 2,
	EUSTCheckCastingBuffType__EUSTCheckCastingBuffType_AllNot = 3,
	EUSTCheckCastingBuffType__EUSTCheckCastingBuffType_MAX = 4
};


// Enum Addons.EBuffHitFaceType
enum class EBuffHitFaceType : uint8_t
{
	EBuffHitFaceType__All = 0,
	EBuffHitFaceType__Forward = 1,
	EBuffHitFaceType__Back = 2,
	EBuffHitFaceType__EBuffHitFaceType_MAX = 3
};


// Enum Addons.EBuffBeHitSpaceType
enum class EBuffBeHitSpaceType : uint8_t
{
	EBuffBeHitSpaceType__All = 0,
	EBuffBeHitSpaceType__Stand = 1,
	EBuffBeHitSpaceType__Air = 2,
	EBuffBeHitSpaceType__EBuffBeHitSpaceType_MAX = 3
};


// Enum Addons.EBuffKeepInStateType
enum class EBuffKeepInStateType : uint8_t
{
	EBuffKeepInStateType__MinUnion = 0,
	EBuffKeepInStateType__ContainOne = 1,
	EBuffKeepInStateType__EBuffKeepInStateType_MAX = 2
};


// Enum Addons.EBuffConditionRescueType
enum class EBuffConditionRescueType : uint8_t
{
	EBuffConditionRescueType__EBCRT_RescueOther = 0,
	EBuffConditionRescueType__EBCRT_BeRescued = 1,
	EBuffConditionRescueType__EBCRT_RescueSelf = 2,
	EBuffConditionRescueType__EBCRT_MAX = 3
};


// Enum Addons.ETargetClassType
enum class ETargetClassType : uint8_t
{
	ETargetClassType__None = 0,
	ETargetClassType__Player = 1,
	ETargetClassType__Monster = 2,
	ETargetClassType__ETargetClassType_MAX = 3
};


// Enum Addons.EBuffEventRescueType
enum class EBuffEventRescueType : uint8_t
{
	EBuffEventRescueType__BERT_RescueOther = 0,
	EBuffEventRescueType__BERT_BeRescued = 1,
	EBuffEventRescueType__BERT_RescueSelf = 2,
	EBuffEventRescueType__BERT_MAX = 3
};


// Enum Addons.EWalkType
enum class EWalkType : uint8_t
{
	EWalkType__None = 0,
	EWalkType__Walk = 1,
	EWalkType__Canter = 2,
	EWalkType__Run = 3,
	EWalkType__EWalkType_MAX = 4
};


// Enum Addons.EWalkSTATE
enum class EWalkSTATE : uint8_t
{
	EWalkSTATE__None = 0,
	EWalkSTATE__Normal = 1,
	EWalkSTATE__BreakOut = 2,
	EWalkSTATE__EWalkSTATE_MAX = 3
};


// Enum Addons.ESTMryiapodState
enum class ESTMryiapodState : uint8_t
{
	ESTMryiapodState__Stand = 0,
	ESTMryiapodState__FallDown = 1,
	ESTMryiapodState__Dead = 2,
	ESTMryiapodState__ESTMryiapodState_MAX = 3
};


// Enum Addons.EHorseBehaviorType
enum class EHorseBehaviorType : uint8_t
{
	EHorseBehaviorType__HorseStateType_Idle = 0,
	EHorseBehaviorType__HorseStateType_Grass = 1,
	EHorseBehaviorType__HorseStateType_ByRiding = 2,
	EHorseBehaviorType__HorseStateType_MAX = 3
};


// Enum Addons.ETitanLocomotionType
enum class ETitanLocomotionType : uint8_t
{
	ETitanLocomotionType__ETLT_Walk_F = 0,
	ETitanLocomotionType__ETLT_Walk_B = 1,
	ETitanLocomotionType__ETLT_Walk_L = 2,
	ETitanLocomotionType__ETLT_Walk_R = 3,
	ETitanLocomotionType__ETLT_Run_F = 4,
	ETitanLocomotionType__ETLT_Run_B = 5,
	ETitanLocomotionType__ETLT_RunLF = 6,
	ETitanLocomotionType__ETLT_Run_R = 7,
	ETitanLocomotionType__ETLT_MAX = 8
};


// Enum Addons.ETurnType
enum class ETurnType : uint8_t
{
	ETT_WaitDelta = 0,
	ETT_WaitTouchEnd = 1,
	ETT_NoTurn = 2,
	ETT_MAX = 3
};


// Enum Addons.ETransformerCurveMoveType
enum class ETransformerCurveMoveType : uint8_t
{
	ETransformerCurveMoveType__Curve_Unknown = 0,
	ETransformerCurveMoveType__Curve_Velocity_Initial = 1,
	ETransformerCurveMoveType__Curve_Velocity_LocalFrame = 2,
	ETransformerCurveMoveType__Curve_MAX = 3
};


// Enum Addons.EAccType
enum class EAccType : uint8_t
{
	EAt_Acc = 0,
	EAt_Dec = 1,
	EAt_None = 2,
	EAT_MAX = 3
};


// Enum Addons.ETweenAnimLoop
enum class ETweenAnimLoop : uint8_t
{
	ETweenAnimLoop__None = 0,
	ETweenAnimLoop__Restart = 1,
	ETweenAnimLoop__PingPong = 2,
	ETweenAnimLoop__ETweenAnimLoop_MAX = 3
};


// Enum Addons.ETweenAnimEase
enum class ETweenAnimEase : uint8_t
{
	ETweenAnimEase__Linear = 0,
	ETweenAnimEase__EaseInQuad = 1,
	ETweenAnimEase__EaseOutQuad = 2,
	ETweenAnimEase__EaseInOutQuad = 3,
	ETweenAnimEase__EaseInCubic = 4,
	ETweenAnimEase__EaseOutCubic = 5,
	ETweenAnimEase__EaseInOutCubic = 6,
	ETweenAnimEase__EaseInOutSine = 7,
	ETweenAnimEase__ETweenAnimEase_MAX = 8
};


// Enum Addons.EBioVehicleSkillStopReason
enum class EBioVehicleSkillStopReason : uint8_t
{
	StopReason_FINISH = 0,
	StopReason_INTERRUPT = 1,
	StopReason_MAX = 2
};


// Enum Addons.ETyranState
enum class ETyranState : uint8_t
{
	ETyranState__None = 0,
	ETyranState__Normal = 1,
	ETyranState__BreakOut = 2,
	ETyranState__ETyranState_MAX = 3
};


// Enum Addons.EVehicleWeaponBoardDataType
enum class EVehicleWeaponBoardDataType : uint8_t
{
	EVehicleWeaponBoardDataType__EVehicleWeaponBoardDataType_None = 0,
	EVehicleWeaponBoardDataType__EVehicleWeaponBoardDataType_MuzzlePos = 1,
	EVehicleWeaponBoardDataType__EVehicleWeaponBoardDataType_MAX = 2
};


// Enum Addons.EDelegateBindType
enum class EDelegateBindType : uint8_t
{
	EDelegateBindType__BINDTYPE_NONE = 0,
	EDelegateBindType__BINDTYPE_DYNAMIC = 1,
	EDelegateBindType__BINDTYPE_DYNAMIC_MULTICAST = 2,
	EDelegateBindType__BINDTYPE_LUAEVENT = 3,
	EDelegateBindType__BINDTYPE_MAX = 4
};


// Enum Addons.ECarryBackDirection
enum class ECarryBackDirection : uint8_t
{
	ECarryBackDirection__ECarryBackDirection_NONE = 0,
	ECarryBackDirection__ECarryBackDirection_Front = 1,
	ECarryBackDirection__ECarryBackDirection_Back = 2,
	ECarryBackDirection__ECarryBackDirection_Left = 3,
	ECarryBackDirection__ECarryBackDirection_Right = 4,
	ECarryBackDirection__ECarryBackDirection_MAX = 5
};


// Enum Addons.ECarryBackSkillActionType
enum class ECarryBackSkillActionType : uint8_t
{
	ECarryBackSkillActionType__ECBSAT_START = 0,
	ECarryBackSkillActionType__ECBSAT_CARRYBACK = 1,
	ECarryBackSkillActionType__ECBSAT_END = 2,
	ECarryBackSkillActionType__ECBSAT_FAILED = 3,
	ECarryBackSkillActionType__ECBSAT_NONE = 4,
	ECarryBackSkillActionType__ECBSAT_MAX = 5
};


// Enum Addons.ECarryToVehicleActionState
enum class ECarryToVehicleActionState : uint8_t
{
	ECarryToVehicleActionState__ECTV_PREPARE = 0,
	ECarryToVehicleActionState__ECTV_UPDATE = 1,
	ECarryToVehicleActionState__ECTV_FINISH = 2,
	ECarryToVehicleActionState__ECTV_FAILED = 3,
	ECarryToVehicleActionState__ECTV_NONE = 4,
	ECarryToVehicleActionState__ECTV_MAX = 5
};


// Enum Addons.ECircleMoveDirection
enum class ECircleMoveDirection : uint8_t
{
	ECircleMoveDirection__Clockwise = 0,
	ECircleMoveDirection__CounterClockwise = 1,
	ECircleMoveDirection__ECircleMoveDirection_MAX = 2
};


// Enum Addons.EContinuousForceDirection
enum class EContinuousForceDirection : uint8_t
{
	EContinuousForceDirection__OwnerToTarget = 0,
	EContinuousForceDirection__WorldDirection = 1,
	EContinuousForceDirection__OwnerForward = 2,
	EContinuousForceDirection__OriginToTarget = 3,
	EContinuousForceDirection__EContinuousForceDirection_MAX = 4
};


// Enum Addons.EContinuousForceMode
enum class EContinuousForceMode : uint8_t
{
	EContinuousForceMode__AddImpulse = 0,
	EContinuousForceMode__AddForce = 1,
	EContinuousForceMode__Launch = 2,
	EContinuousForceMode__RequestDirectMove = 3,
	EContinuousForceMode__EContinuousForceMode_MAX = 4
};


// Enum Addons.EBSSkillActionType
enum class EBSSkillActionType : uint8_t
{
	EBSSAT_START = 0,
	EBSSAT_PLACE = 1,
	EBSSAT_END = 2,
	EBSSAT_CHECK = 3,
	EBSSAT_PLACE_RELATIVE = 4,
	EBSSAT_CACHE = 5,
	EBSSAT_STOP_PREBUILD = 6,
	EBSSAT_NONE = 7,
	EBSSAT_MAX = 8
};


// Enum Addons.EFindTargetStrategy
enum class EFindTargetStrategy : uint8_t
{
	EFindTargetStrategy__Default = 0,
	EFindTargetStrategy__ByAngleLeftToRight = 1,
	EFindTargetStrategy__ByAngleRightToLeft = 2,
	EFindTargetStrategy__EFindTargetStrategy_MAX = 3
};


// Enum Addons.EJumpStage
enum class EJumpStage : uint8_t
{
	EJumpStage__EJumpStage_Rising = 0,
	EJumpStage__EJumpStage_Hovering = 1,
	EJumpStage__EJumpStage_Diving = 2,
	EJumpStage__EJumpStage_MAX = 3
};


// Enum Addons.EPVEProjectileInitLocationType
enum class EPVEProjectileInitLocationType : uint8_t
{
	EPVEProjectileInitLocationType__UseOwnerLocation = 0,
	EPVEProjectileInitLocationType__UseTargetLocation = 1,
	EPVEProjectileInitLocationType__UseSocketLocation = 2,
	EPVEProjectileInitLocationType__UseBlackBoard = 3,
	EPVEProjectileInitLocationType__UseVehicleLoc = 4,
	EPVEProjectileInitLocationType__EPVEProjectileInitLocationType_MAX = 5
};


// Enum Addons.ELockPPType
enum class ELockPPType : uint8_t
{
	ELPPT_FPP = 0,
	ELPPT_TPP = 1,
	ELPPT_MAX = 2
};


// Enum Addons.ESkillModifyPropertyType
enum class ESkillModifyPropertyType : uint8_t
{
	ESMPT_Bool = 0,
	ESMPT_Int = 1,
	ESMPT_Float = 2,
	ESMPT_String = 3,
	ESMPT_MAX = 4
};


// Enum Addons.AnimMontageTypeAndPosture
enum class EAnimMontageTypeAndPosture : uint8_t
{
	AnimMontageTypeAndPosture__FPS_Stand = 0,
	AnimMontageTypeAndPosture__FPS_Crouch = 1,
	AnimMontageTypeAndPosture__FPS_Prone = 2,
	AnimMontageTypeAndPosture__FPS_Vehicle = 3,
	AnimMontageTypeAndPosture__FPS_Max = 4,
	AnimMontageTypeAndPosture__TPS_Stand = 5,
	AnimMontageTypeAndPosture__TPS_Crouch = 6,
	AnimMontageTypeAndPosture__TPS_Prone = 7,
	AnimMontageTypeAndPosture__TPS_Vehicle = 8,
	AnimMontageTypeAndPosture__TPS_Max = 9,
	AnimMontageTypeAndPosture__AnimMontageTypeAndPosture_MAX = 10
};


// Enum Addons.EPutDownDirection
enum class EPutDownDirection : uint8_t
{
	EPutDownDirection__EPutDownDirection_NONE = 0,
	EPutDownDirection__EPutDownDirection_Front = 1,
	EPutDownDirection__EPutDownDirection_Back = 2,
	EPutDownDirection__EPutDownDirection_MAX = 3
};


// Enum Addons.EPutDownSkillActionType
enum class EPutDownSkillActionType : uint8_t
{
	EPutDownSkillActionType__EPDSAT_START = 0,
	EPutDownSkillActionType__EPDSAT_PUTDOWN = 1,
	EPutDownSkillActionType__EPDSAT_END = 2,
	EPutDownSkillActionType__EPDSAT_FAILED = 3,
	EPutDownSkillActionType__EPDSAT_NONE = 4,
	EPutDownSkillActionType__EPDSAT_MAX = 5
};


// Enum Addons.ESkillTouchEvent
enum class ESkillTouchEvent : uint8_t
{
	ESkillTouchEvent__ESkillTouchEvent_KEY_DOWN = 0,
	ESkillTouchEvent__ESkillTouchEvent_KEY_UP = 1,
	ESkillTouchEvent__ESkillTouchEvent_KEY_MAX = 2
};


// Enum Addons.ESubAnimInsParamType
enum class ESubAnimInsParamType : uint8_t
{
	ESubAnimInsParamType__Bool = 0,
	ESubAnimInsParamType__Int = 1,
	ESubAnimInsParamType__Float = 2,
	ESubAnimInsParamType__Name = 3,
	ESubAnimInsParamType__Object = 4,
	ESubAnimInsParamType__ESubAnimInsParamType_MAX = 5
};


// Enum Addons.EBeamEffectDataFromType
enum class EBeamEffectDataFromType : uint8_t
{
	EBeamEffectDataFromType__FixedPoint = 0,
	EBeamEffectDataFromType__BlackBoard = 1,
	EBeamEffectDataFromType__AttachPoint = 2,
	EBeamEffectDataFromType__EBeamEffectDataFromType_MAX = 3
};


// Enum Addons.EUAESkillCheckItemType
enum class EUAESkillCheckItemType : uint8_t
{
	EUAESkillCheckItemType__EUAESkillCheckItemType_Or = 0,
	EUAESkillCheckItemType__EUAESkillCheckItemType_And = 1,
	EUAESkillCheckItemType__EUAESkillCheckItemType_MAX = 2
};


// Enum Addons.ESkillConditionIsInHouseCheckType
enum class ESkillConditionIsInHouseCheckType : uint8_t
{
	ESkillConditionIsInHouseCheckType__In = 0,
	ESkillConditionIsInHouseCheckType__NotIn = 1,
	ESkillConditionIsInHouseCheckType__ESkillConditionIsInHouseCheckType_MAX = 2
};


// Enum Addons.ESkillConditionIsInHouseCheckTarget
enum class ESkillConditionIsInHouseCheckTarget : uint8_t
{
	ESkillConditionIsInHouseCheckTarget__Self = 0,
	ESkillConditionIsInHouseCheckTarget__SelfForward = 1,
	ESkillConditionIsInHouseCheckTarget__ESkillConditionIsInHouseCheckTarget_MAX = 2
};


// Enum Addons.EAxisType
enum class EAxisType : uint8_t
{
	EAxis_X = 0,
	EAxis_Y = 1,
	EAxis_Z = 2,
	EAxis_MAX = 3
};


// Enum Addons.ESCRotatorAngleType
enum class ESCRotatorAngleType : uint8_t
{
	ESCRotatorAngleType__ESCRotatorAngleType_Character = 0,
	ESCRotatorAngleType__ESCRotatorAngleType_Controller = 1,
	ESCRotatorAngleType__ESCRotatorAngleType_Camera = 2,
	ESCRotatorAngleType__ESCRotatorAngleType_FreeCamera = 3,
	ESCRotatorAngleType__ESCRotatorAngleType_Max = 4
};


// Enum Addons.ESettingConfigType
enum class ESettingConfigType : uint8_t
{
	SCT_Int = 0,
	SCT_UInt = 1,
	SCT_Float = 2,
	SCT_Bool = 3,
	SCT_String = 4,
	SCT_MAX = 5
};


// Enum Addons.EVineRushState
enum class EVineRushState : uint8_t
{
	EVineRushState__VRS_Normal = 0,
	EVineRushState__VRS_Search = 1,
	EVineRushState__VRS_Wait = 2,
	EVineRushState__VRS_Teleport = 3,
	EVineRushState__VRS_MAX = 4
};


// Enum Addons.EAnimHurtingTarget
enum class EAnimHurtingTarget : uint8_t
{
	EAnimHurtingTarget__PlayerCharacter = 0,
	EAnimHurtingTarget__SimpleCharacter = 1,
	EAnimHurtingTarget__AllCharacter = 2,
	EAnimHurtingTarget__EAnimHurtingTarget_MAX = 3
};


// Enum Addons.EHurtApperanceRotateType
enum class EHurtApperanceRotateType : uint8_t
{
	EHurtApperanceRotateType__ERotateToCaster = 0,
	EHurtApperanceRotateType__EHurtApperanceRotateType_MAX = 1
};


// Enum Addons.UTSkill_SoundCue_ListenType
enum class EUTSkill_SoundCue_ListenType : uint8_t
{
	UTSkill_SoundCue_ListenType__Listen_SelfOnly = 0,
	UTSkill_SoundCue_ListenType__Listen_Teammate = 1,
	UTSkill_SoundCue_ListenType__Listen_Target = 2,
	UTSkill_SoundCue_ListenType__Listen_AllTarget = 3,
	UTSkill_SoundCue_ListenType__Listen_All = 4,
	UTSkill_SoundCue_ListenType__Listen_MAX = 5
};



//---------------------By BangJO---------------------------
//Script Structs
//---------------------By BangJO---------------------------

// ScriptStruct Addons.TurnData
// 0x0048
struct FTurnData
{
	class ASTExtraSimpleCharacter* OwnerActor; // 0x0000(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	class UCurveVector* TurnCurve; // 0x0008(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char UnknownData00[0x38]; // 0x0010(0x0038) MISSED OFFSET
};

// ScriptStruct Addons.BioVehicleAnimInstanceProxy
// 0x0070 (0x0640 - 0x05D0)
struct FBioVehicleAnimInstanceProxy : public FAnimInstanceProxy
{
	class UAnimInstance* SourceAnimInstance; // 0x05C8(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TArray<struct FName> SourceInstancePropertyNames; // 0x05D0(0x0010) (ZeroConstructor, Transient)
	TArray<class UProperty*> SourceInstanceProperty; // 0x05E0(0x0010) (ZeroConstructor, Transient)
	TMap<class UAnimInstance*, struct FCopyPropertyData> DestInstancePropertyMap; // 0x05F0(0x0050) (ZeroConstructor, Transient)
};

// ScriptStruct Addons.BioVehicleBlowUpData
// 0x0034
struct FBioVehicleBlowUpData
{
	float TimeStamp; // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int InternalBlowUpID; // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	bool bIsBeingBlew; // 0x0008(0x0001) (ZeroConstructor, IsPlainOldData)
	bool bBTPaused; // 0x0009(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x2]; // 0x000A(0x0002) MISSED OFFSET
	struct FVector SelfLocationWhenLaunchHappened; // 0x000C(0x000C) (IsPlainOldData)
	struct FVector LaunchVelocity; // 0x0018(0x000C) (IsPlainOldData)
	TWeakObjectPtr<class AActor> HitActor; // 0x0024(0x0008) (ZeroConstructor, IsPlainOldData)
	TWeakObjectPtr<class UPrimitiveComponent> HitComponent; // 0x002C(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// ScriptStruct Addons.MountMontagePair
// 0x0038
struct FMountMontagePair
{
	class UAnimMontage* CreatureMontage; // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UAnimMontage* RiderMontage; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UCurveVector* LocationCurve; // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UCurveVector* RotationCurve; // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float PlayRate; // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float Duration; // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float StartTime; // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float CameraLerpStartTime; // 0x002C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float CameraLerpDuration; // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0034(0x0004) MISSED OFFSET
};

// ScriptStruct Addons.AmphibiousBoatThrusterRollSetup
// 0x0010
struct FAmphibiousBoatThrusterRollSetup
{
	class UCurveVector* CurveOmega; // 0x0000(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float OmegaAccel; // 0x0008(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float RPMScale; // 0x000C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.RecordBoneData
// 0x0070
struct FRecordBoneData
{
	struct FTransform LastTransform; // 0x0000(0x0030) (BlueprintVisible, IsPlainOldData)
	struct FTransform CurrentTransform; // 0x0030(0x0030) (BlueprintVisible, IsPlainOldData)
	struct FVector Velocity; // 0x0060(0x000C) (BlueprintVisible, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x006C(0x0004) MISSED OFFSET
};

// ScriptStruct Addons.AvatarMergerAsyncTempData
// 0x0120
struct FAvatarMergerAsyncTempData
{
	TArray<class USkeletalMeshComponent*> MeshComponentToMerge; // 0x0000(0x0010) (ExportObject, ZeroConstructor, Transient)
	TMap<class UMaterialInterface*, struct FAvatarMaterialGameThreadInfo> MatInterfaceToGameThreadInfoMap; // 0x0010(0x0050) (ZeroConstructor, Transient)
	TMap<int, struct FWaitSetParamTexture> WaitForUpdateAndSetParamTextureMap; // 0x0060(0x0050) (ZeroConstructor, Transient)
	TArray<class UTexture2D*> CreateForAsyncThreadTextureArray; // 0x00B0(0x0010) (ZeroConstructor, Transient)
	TMap<class UMaterial*, class UMaterialInstanceDynamic*> CreateForAsyncThreadMaterialMap; // 0x00C0(0x0050) (ZeroConstructor, Transient)
	class UMaterialInstanceDynamic* CreateForAsyncThreadBasicMaterial; // 0x0110(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char UnknownData00[0x8]; // 0x0118(0x0008) MISSED OFFSET
};

// ScriptStruct Addons.RotationAxisInheritance
// 0x0004
struct FRotationAxisInheritance
{
	unsigned char bInheritPitch : 1; // 0x0000(0x0001) (Edit, BlueprintVisible)
	unsigned char bInheritYaw : 1; // 0x0000(0x0001) (Edit, BlueprintVisible)
	unsigned char bInheritRoll : 1; // 0x0000(0x0001) (Edit, BlueprintVisible)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
};

// ScriptStruct Addons.FlySprintParams
// 0x0050
struct FFlySprintParams
{
	EFlySprintDirMode DirMode; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
	struct FVector Direction; // 0x0004(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector DestLocation; // 0x0010(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	float Speed; // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCurveFloat* SpeedCurve; // 0x0020(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float InitSpeed; // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float Acceleration; // 0x002C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float Friction; // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float VerticalSpeed; // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCurveFloat* VerticalSpeedCurve; // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float Duration; // 0x0040(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bApplyGravity; // 0x0044(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bApplyHeightLimit; // 0x0045(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x2]; // 0x0046(0x0002) MISSED OFFSET
	float EndVelocityInheritRatio; // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float StopOnImpactAngle; // 0x004C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.FlyFollowParams
// 0x0018
struct FFlyFollowParams
{
	float MaxFollowDistance; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxLostDistance; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bBreakFollowOnInput; // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0009(0x0003) MISSED OFFSET
	float FollowRotationSpeed; // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float FollowRotationTolerance; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bAuthorityOnlyPassiveStop; // 0x0014(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x0015(0x0003) MISSED OFFSET
};

// ScriptStruct Addons.BioVehicleMovementPostPhysicsTickFunction
// 0x0008 (0x00B8 - 0x00B0)
struct FBioVehicleMovementPostPhysicsTickFunction : public FTickFunction
{
	class UBioVehicleMovementComponent* Target; // 0x00B0(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// ScriptStruct Addons.CharacterNetworkSerializationPackedBits
// 0x0518
struct FCharacterNetworkSerializationPackedBits
{
	unsigned char UnknownData00[0x518]; // 0x0000(0x0518) MISSED OFFSET
};

// ScriptStruct Addons.CharacterServerMovePackedBits
// 0x0000 (0x0518 - 0x0518)
struct FCharacterServerMovePackedBits : public FCharacterNetworkSerializationPackedBits
{

};

// ScriptStruct Addons.FlyBioVehicleFlyingConfig
// 0x0030
struct FFlyBioVehicleFlyingConfig
{
	float MaxUpSpeed; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxDownSpeed; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxFlySpeed; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxFlyBackSpeed; // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxFlyLeftRightSpeed; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxFlyingHeight; // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MinFlyingHeight; // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float FlyingHeightThres; // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxFlyAcceleration; // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float FlySteeringRotationSpeed; // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCurveFloat* FlySteeringRotationSpeedCurve; // 0x0028(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.BioVehicleAbilityAnimInstanceProxy
// 0x0080 (0x06B0 - 0x0630)
struct FBioVehicleAbilityAnimInstanceProxy : public FAnimAbilityAnimInstanceProxy
{
	class UAnimInstance* SourceAnimInstance; // 0x0630(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TArray<struct FName> SourceInstancePropertyNames; // 0x0638(0x0010) (ZeroConstructor, Transient)
	TArray<class UProperty*> SourceInstanceProperty; // 0x0648(0x0010) (ZeroConstructor, Transient)
	TMap<class UAnimInstance*, struct FCopyPropertyData> DestInstancePropertyMap; // 0x0658(0x0050) (ZeroConstructor, Transient)
	unsigned char UnknownData00[0x8]; // 0x06A8(0x0008) MISSED OFFSET
};

// ScriptStruct Addons.BioVHAgentMove
// 0x0020
struct FBioVHAgentMove
{
	bool IsFollowingTarget; // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
	TWeakObjectPtr<class AActor> FollowTarget; // 0x0004(0x0008) (ZeroConstructor, IsPlainOldData)
	bool IsHostingMove; // 0x000C(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x000D(0x0003) MISSED OFFSET
	struct FVector HostingVelocity; // 0x0010(0x000C) (IsPlainOldData)
	unsigned char UnknownData02[0x4]; // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct Addons.CustomVOHelper
// 0x0068
struct FCustomVOHelper
{
	bool IsObstacleDetected; // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	bool IsPrecipiceDetected; // 0x0001(0x0001) (ZeroConstructor, IsPlainOldData)
	bool IsMoveBlocked; // 0x0002(0x0001) (ZeroConstructor, IsPlainOldData)
	EVOFlag VOFlag; // 0x0003(0x0001) (ZeroConstructor, IsPlainOldData)
	EVOFlag LastVOFlag; // 0x0004(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0005(0x0003) MISSED OFFSET
	int VO_LeftOrRight; // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FVector VO_Velocity; // 0x000C(0x000C) (IsPlainOldData)
	TArray<struct FHitResult> VO_Obstacles; // 0x0018(0x0010) (ZeroConstructor)
	float VO_Duration; // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FVector VO_CacheVelocity; // 0x002C(0x000C) (IsPlainOldData)
	struct FVector VO_ObstacleCenter; // 0x0038(0x000C) (IsPlainOldData)
	struct FVector VO_OriginLoc; // 0x0044(0x000C) (IsPlainOldData)
	int VO_Step; // 0x0050(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FVector Jump_Velocity; // 0x0054(0x000C) (IsPlainOldData)
	float CD; // 0x0060(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x0064(0x0004) MISSED OFFSET
};

// ScriptStruct Addons.JumpObstacleData
// 0x005C
struct FJumpObstacleData
{
	struct FVector ObstacleCenter; // 0x0000(0x000C) (IsPlainOldData)
	struct FVector ObstacleNearest; // 0x000C(0x000C) (IsPlainOldData)
	struct FVector ObstacleHighest; // 0x0018(0x000C) (IsPlainOldData)
	struct FVector JumpV; // 0x0024(0x000C) (IsPlainOldData)
	struct FVector LandSpot; // 0x0030(0x000C) (IsPlainOldData)
	bool bValidJump; // 0x003C(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x003D(0x0003) MISSED OFFSET
	float TimeStamp; // 0x0040(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FVector OwnerLocation; // 0x0044(0x000C) (IsPlainOldData)
	struct FRotator OwnerRotation; // 0x0050(0x000C) (IsPlainOldData)
};

// ScriptStruct Addons.SuddenStopData
// 0x0010
struct FSuddenStopData
{
	int SuddenStopID; // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FVector Location; // 0x0004(0x000C) (IsPlainOldData)
};

// ScriptStruct Addons.RepPrecipiceInfo
// 0x0018
struct FRepPrecipiceInfo
{
	struct FVector Location; // 0x0000(0x000C) (IsPlainOldData)
	struct FVector Direction; // 0x000C(0x000C) (IsPlainOldData)
};

// ScriptStruct Addons.RepBirdCage
// 0x001C
struct FRepBirdCage
{
	bool bIsDestroy; // 0x0000(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bIsAlert; // 0x0001(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x2]; // 0x0002(0x0002) MISSED OFFSET
	int AlertIndex; // 0x0004(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int PlayerKey; // 0x0008(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int Count; // 0x000C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector OriPawnLocation; // 0x0010(0x000C) (BlueprintVisible, IsPlainOldData)
};

// ScriptStruct Addons.BlanketDanceData
// 0x0010
struct FBlanketDanceData
{
	TEnumAsByte<enum EBlanketDanceState> BlanketDanceState; // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0001(0x0007) MISSED OFFSET
	class ASTExtraBaseCharacter* LookAtCharacter; // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.FootIKSlope
// 0x0098
struct FFootIKSlope
{
	struct FVector StrideDirection; // 0x0000(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	float MaxGroundAngle; // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxNormalAngularSpeed; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool OrientToGround; // 0x0014(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0015(0x0003) MISSED OFFSET
	float OrientToPitch; // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float OrientToRoll; // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool ScaleStride; // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x0021(0x0003) MISSED OFFSET
	float UphillStrideScale; // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float DownhillStrideScale; // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float SidehillStrideScale; // 0x002C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float SidehillPushOuterFeet; // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool Lean; // 0x0034(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x3]; // 0x0035(0x0003) MISSED OFFSET
	float UphillLean; // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float DownhillLean; // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float SidehillLean; // 0x0040(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool CounterLean; // 0x0044(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData03[0x3]; // 0x0045(0x0003) MISSED OFFSET
	struct FName CounterLeanBoneName; // 0x0048(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData04[0x4]; // 0x0050(0x0004) MISSED OFFSET
	float UphillCounterLean; // 0x0054(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float DownhillCounterLean; // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float SidehillCounterLean; // 0x005C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool MoveRoot; // 0x0060(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData05[0x3]; // 0x0061(0x0003) MISSED OFFSET
	float UphillVertOffset; // 0x0064(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float UphillHorizOffset; // 0x0068(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float DownhillVertOffset; // 0x006C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float DownhillHorizOffset; // 0x0070(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float SidehillHorizOffset; // 0x0074(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float SidehillVertOffset; // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool RotateFootToGround; // 0x007C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData06[0x3]; // 0x007D(0x0003) MISSED OFFSET
	float PitchFootAmount; // 0x0080(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float RollFootAmount; // 0x0084(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float FootAngleDeltaSmoothSpeed; // 0x0088(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool OffsetFeetPositions; // 0x008C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData07[0x3]; // 0x008D(0x0003) MISSED OFFSET
	float StaticFootOffset; // 0x0090(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData08[0x4]; // 0x0094(0x0004) MISSED OFFSET
};

// ScriptStruct Addons.BuffNodeBlackboardSetting
// 0x0128
struct FBuffNodeBlackboardSetting
{
	TEnumAsByte<enum EUAEBlackboardType> Type; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0001(0x0007) MISSED OFFSET
	unsigned char UnknownData01[0x28]; // 0x0001(0x0028) UNKNOWN PROPERTY: SoftObjectProperty Addons.BuffNodeBlackboardSetting.Execute_Object
	unsigned char UnknownData02[0x28]; // 0x0030(0x0028) UNKNOWN PROPERTY: SoftClassProperty Addons.BuffNodeBlackboardSetting.Execute_Class
	unsigned char Execute_Enum; // 0x0058(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData03[0x3]; // 0x0059(0x0003) MISSED OFFSET
	int Execute_Int; // 0x005C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float Execute_Float; // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool Execute_Bool; // 0x0064(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData04[0x3]; // 0x0065(0x0003) MISSED OFFSET
	struct FString Execute_String; // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FName Execute_Name; // 0x0078(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector Execute_Vector; // 0x0080(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRotator Execute_Rotator; // 0x008C(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	unsigned char UnknownData05[0x28]; // 0x0098(0x0028) UNKNOWN PROPERTY: SoftObjectProperty Addons.BuffNodeBlackboardSetting.End_Object
	unsigned char UnknownData06[0x28]; // 0x00C0(0x0028) UNKNOWN PROPERTY: SoftClassProperty Addons.BuffNodeBlackboardSetting.End_Class
	unsigned char End_Enum; // 0x00E8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData07[0x3]; // 0x00E9(0x0003) MISSED OFFSET
	int End_Int; // 0x00EC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float End_Float; // 0x00F0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool End_Bool; // 0x00F4(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData08[0x3]; // 0x00F5(0x0003) MISSED OFFSET
	struct FString End_String; // 0x00F8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FName End_Name; // 0x0108(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector End_Vector; // 0x0110(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRotator End_Rotator; // 0x011C(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct Addons.NearbyCharacter
// 0x0010
struct FNearbyCharacter
{
	class ASTExtraCharacter* Character; // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	float Attractive; // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x000C(0x0004) MISSED OFFSET
};

// ScriptStruct Addons.MercenaryAnimInstanceProxy
// 0x0070 (0x0640 - 0x05D0)
struct FMercenaryAnimInstanceProxy : public FAnimInstanceProxy
{
	class UAnimInstance* SourceAnimInstance; // 0x05C8(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TArray<struct FName> SourceInstancePropertyNames; // 0x05D0(0x0010) (ZeroConstructor, Transient)
	TArray<class UProperty*> SourceInstanceProperty; // 0x05E0(0x0010) (ZeroConstructor, Transient)
	TMap<class UAnimInstance*, struct FCopyPropertyData> DestInstancePropertyMap; // 0x05F0(0x0050) (ZeroConstructor, Transient)
};

// ScriptStruct Addons.HorseTransformData
// 0x0018
struct FHorseTransformData
{
	EHorseTransformType TransformingState; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
	struct FVector StartTransformPoint; // 0x0004(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	float TransformEndTime; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int SkinID; // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.TransformMatConfig
// 0x0020
struct FTransformMatConfig
{
	unsigned char SlotIdx; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0001(0x0007) MISSED OFFSET
	struct FName ParamName; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float LerpSpeed; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float TargetValue; // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float CurrentValue; // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct Addons.DynamicSplineInfo
// 0x0058
struct FDynamicSplineInfo
{
	bool bHasNewWay; // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	bool bBuildEnded; // 0x0001(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x2]; // 0x0002(0x0002) MISSED OFFSET
	int EndIndex; // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	TArray<class USimpleSyncSplineMeshComponent*> MeshComponents; // 0x0008(0x0010) (ExportObject, ZeroConstructor)
	TArray<class USimpleSyncInstancedSplineMeshComponent*> MeshInstancedComponents; // 0x0018(0x0010) (ExportObject, ZeroConstructor)
	TArray<int> SplineMeshTypeIndex; // 0x0028(0x0010) (ZeroConstructor)
	TArray<int> HideMeshIndex; // 0x0038(0x0010) (ZeroConstructor)
	TArray<struct FVector> SplinePoints; // 0x0048(0x0010) (ZeroConstructor)
};

// ScriptStruct Addons.FlowerWingMoveParam
// 0x001C
struct FFlowerWingMoveParam
{
	float FlyMaxSpeed; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float FlyRightMaxSpeed; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float FlyBackMaxSpeed; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float ForwardAccel; // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float RightAccel; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxBrakingDeceleration; // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float FlyFriction; // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.NetWallClimbData
// 0x0038
struct FNetWallClimbData
{
	bool bIsRunning; // 0x0000(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bValidNormal; // 0x0001(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x2]; // 0x0002(0x0002) MISSED OFFSET
	struct FVector WallNormal; // 0x0004(0x000C) (BlueprintVisible, IsPlainOldData)
	struct FVector ExpectedLoc; // 0x0010(0x000C) (BlueprintVisible, IsPlainOldData)
	EWallSurfaceState SurfaceState; // 0x001C(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x001D(0x0003) MISSED OFFSET
	struct FVector MovementDir; // 0x0020(0x000C) (BlueprintVisible, IsPlainOldData)
	struct FVector Acceleration; // 0x002C(0x000C) (BlueprintVisible, IsPlainOldData)
};

// ScriptStruct Addons.WallBodyCoverage
// 0x0001
struct FWallBodyCoverage
{
	bool bHeadHasWall; // 0x0000(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.WallDetectionResult
// 0x0048
struct FWallDetectionResult
{
	bool bDetectedWall; // 0x0000(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bValidNormal; // 0x0001(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x2]; // 0x0002(0x0002) MISSED OFFSET
	struct FVector WallNormal; // 0x0004(0x000C) (BlueprintVisible, IsPlainOldData)
	struct FVector WallLocation; // 0x0010(0x000C) (BlueprintVisible, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x001C(0x0004) MISSED OFFSET
	class UPrimitiveComponent* WallComponent; // 0x0020(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	struct FWallBodyCoverage BodyCoverage; // 0x0028(0x0001) (BlueprintVisible)
	unsigned char UnknownData02[0x7]; // 0x0029(0x0007) MISSED OFFSET
	TArray<struct FHitResult> RawHits; // 0x0030(0x0010) (BlueprintVisible, ZeroConstructor)
	bool bIsFloorExit; // 0x0040(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bIsRoofExit; // 0x0041(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData03[0x6]; // 0x0042(0x0006) MISSED OFFSET
};

// ScriptStruct Addons.CornerTransitionState
// 0x00A0
struct FCornerTransitionState
{
	bool bTransitioningCorner; // 0x0000(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
	struct FVector OldWallNormal; // 0x0004(0x000C) (BlueprintVisible, IsPlainOldData)
	struct FVector NewWallNormal; // 0x0010(0x000C) (BlueprintVisible, IsPlainOldData)
	struct FVector OldPawnLocation; // 0x001C(0x000C) (BlueprintVisible, IsPlainOldData)
	struct FVector NewPawnLocation; // 0x0028(0x000C) (BlueprintVisible, IsPlainOldData)
	EWallSurfaceState OldWallSurfaceState; // 0x0034(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EWallSurfaceState NewWallSurfaceState; // 0x0035(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x2]; // 0x0036(0x0002) MISSED OFFSET
	struct FVector OldMoveDir; // 0x0038(0x000C) (BlueprintVisible, IsPlainOldData)
	unsigned char RequestID; // 0x0044(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x3]; // 0x0045(0x0003) MISSED OFFSET
	float ClientTimeStamp; // 0x0048(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float LocalTimeAtStart; // 0x004C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	struct FVector ArcCenter; // 0x0050(0x000C) (BlueprintVisible, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	float ArcRadius; // 0x005C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	struct FQuat OldYawRotation; // 0x0060(0x0010) (BlueprintVisible, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	struct FQuat NewYawRotation; // 0x0070(0x0010) (BlueprintVisible, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	struct FRotator OldControlRotation; // 0x0080(0x000C) (BlueprintVisible, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	struct FRotator NewControlRotation; // 0x008C(0x000C) (BlueprintVisible, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	float CachedCornerBlendTime; // 0x0098(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	bool bNeedsCameraTransition; // 0x009C(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	unsigned char UnknownData03[0x3]; // 0x009D(0x0003) MISSED OFFSET
};

// ScriptStruct Addons.GhostBalloonMoveParam
// 0x0020
struct FGhostBalloonMoveParam
{
	float ForwardAccel; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float ForwardBrakingDecel; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float SlideForwardSpeedMax; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float SlideForwardSpeedMin; // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float RightAccel; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float RightBrakingDecel; // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float SlideRightSpeedMax; // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float HorizontalSlideSpeedMax; // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.ExitHorseSockets
// 0x0010
struct FExitHorseSockets
{
	TArray<struct FName> ExitHorseSockets; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct Addons.UncombineHelper
// 0x0040
struct FUncombineHelper
{
	bool bReset; // 0x0000(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0xF]; // 0x0001(0x000F) MISSED OFFSET
	struct FTransform NewTransform; // 0x0010(0x0030) (BlueprintVisible, IsPlainOldData)
};

// ScriptStruct Addons.HoveringBodyData
// 0x001C
struct FHoveringBodyData
{
	float DistanceToGround; // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	float DistanceToGround_Old; // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FVector TraceHitLocation; // 0x0008(0x000C) (IsPlainOldData)
	float BadStatusTime; // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
	bool bInAir; // 0x0018(0x0001) (ZeroConstructor, IsPlainOldData)
	bool bUnderground; // 0x0019(0x0001) (ZeroConstructor, IsPlainOldData)
	bool bPenetration; // 0x001A(0x0001) (ZeroConstructor, IsPlainOldData)
	bool bInWater; // 0x001B(0x0001) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.NitrogenAccelData
// 0x001C
struct FNitrogenAccelData
{
	struct FVector LocationT0; // 0x0000(0x000C) (IsPlainOldData)
	struct FRotator RotationT0; // 0x000C(0x000C) (IsPlainOldData)
	bool IsSideOverlap; // 0x0018(0x0001) (ZeroConstructor, IsPlainOldData)
	bool IsLeftSideOverlap; // 0x0019(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x2]; // 0x001A(0x0002) MISSED OFFSET
};

// ScriptStruct Addons.HoveringSimulateData
// 0x0040
struct FHoveringSimulateData
{
	float HoverDelta; // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	float HoverDelta_Predict; // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	float HoverDelta_Old; // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FVector SimForce; // 0x000C(0x000C) (IsPlainOldData)
	bool bInAir; // 0x0018(0x0001) (ZeroConstructor, IsPlainOldData)
	bool bUnderground; // 0x0019(0x0001) (ZeroConstructor, IsPlainOldData)
	bool bInWater; // 0x001A(0x0001) (ZeroConstructor, IsPlainOldData)
	bool bPenetration; // 0x001B(0x0001) (ZeroConstructor, IsPlainOldData)
	struct FVector TraceHitLocation; // 0x001C(0x000C) (IsPlainOldData)
	struct FVector SpotWorldLocation_Last; // 0x0028(0x000C) (IsPlainOldData)
	struct FVector HoverSpotRelativeLoc; // 0x0034(0x000C) (IsPlainOldData)
};

// ScriptStruct Addons.LadderMoveData
// 0x0018
struct FLadderMoveData
{
	bool bOnLadder; // 0x0000(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0001(0x0007) MISSED OFFSET
	class ALadderActor* Ladder; // 0x0008(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ELadderMoveType> LadderMoveType; // 0x0010(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char LadderStep; // 0x0011(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x6]; // 0x0012(0x0006) MISSED OFFSET
};

// ScriptStruct Addons.FootLockData
// 0x0038
struct FFootLockData
{
	struct FName CurveName; // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName BoneName; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName IkBoneName; // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float LockAlpha; // 0x0018(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector LockedLocation; // 0x001C(0x000C) (BlueprintVisible, IsPlainOldData)
	struct FRotator LockedRotator; // 0x0028(0x000C) (BlueprintVisible, IsPlainOldData)
	float CurveValueLastFrame; // 0x0034(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.MechaCameraModifier
// 0x0050
struct FMechaCameraModifier
{
	float ArmLengthAddSpeed; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float ArmLengthAddTarget; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float ArmLengthAddCurrent; // 0x0008(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float FovAddSpeed; // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float FovAddTarget; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float FovAddCurrent; // 0x0014(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
	float SocketOffsetAddSpeed; // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector SocketOffsetAddTarget; // 0x001C(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector SocketOffsetAddCurrent; // 0x0028(0x000C) (Transient, IsPlainOldData)
	float TargetOffsetAddSpeed; // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector TargetOffsetAddTarget; // 0x0038(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector TargetOffsetAddCurrent; // 0x0044(0x000C) (Transient, IsPlainOldData)
};

// ScriptStruct Addons.HitDymaicParams
// 0x0038
struct FHitDymaicParams
{
	struct FVector RelativeLocation; // 0x0000(0x000C) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FRotator RelativeRotation; // 0x000C(0x000C) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FVector BoxExtent; // 0x0018(0x000C) (Edit, DisableEditOnInstance, IsPlainOldData)
	float Radius; // 0x0024(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float HalfHeight; // 0x0028(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bDetectBioVehicle; // 0x002C(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bDetectPhysVehicle; // 0x002D(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData00[0x2]; // 0x002E(0x0002) MISSED OFFSET
	class AActor* OwnedActor; // 0x0030(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.EnvReponseObstacle
// 0x0040
struct FEnvReponseObstacle
{
	class AActor* Actor; // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FVector ActorLocation; // 0x0008(0x000C) (IsPlainOldData)
	struct FRotator ActorRotator; // 0x0014(0x000C) (IsPlainOldData)
	float RelativeHeight; // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	float Distance; // 0x0024(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FVector HitNormal; // 0x0028(0x000C) (IsPlainOldData)
	struct FVector TopPoint; // 0x0034(0x000C) (IsPlainOldData)
};

// ScriptStruct Addons.CreateSkillItemInfo
// 0x0028
struct FCreateSkillItemInfo
{
	TArray<ECreateSkillItemType> CreateSkillItemTypes; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int BuildingSystemID; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int CheckHight; // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxSlopeAngle; // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxAssociateDistance; // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MinAssociateDistance; // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxHeightDifference; // 0x0024(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.NinjaMoveState
// 0x0018
struct FNinjaMoveState
{
	bool bInNinjaMoveState; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0001(0x0007) MISSED OFFSET
	class ASTExtraBaseCharacter* LeaderPlayer; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UNinjaMoveComponent* LeaderNinjaMoveComponent; // 0x0010(0x0008) (Edit, BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// ScriptStruct Addons.GaitStopSequenceData
// 0x0050
struct FGaitStopSequenceData
{
	TMap<TEnumAsByte<enum EMoveDirection>, struct FStopPoseData> StopData; // 0x0000(0x0050) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.CircleRunSequenceData
// 0x0020
struct FCircleRunSequenceData
{
	class UAnimSequence* CircleRunStartAnimSequence; // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UAnimSequence* CircleRunLoopAnimSequence; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<struct FPoseSearchData> CircleStopRunData; // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.MotionSearchResult
// 0x0010
struct FMotionSearchResult
{
	float StartTime; // 0x0000(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0004(0x0004) MISSED OFFSET
	class UAnimSequence* ResultSequence; // 0x0008(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.HeadItem
// 0x0018
struct FHeadItem
{
	struct FString PlayerName; // 0x0000(0x0010) (BlueprintVisible, ZeroConstructor)
	class UOBModePositionWidget* HeadItemWidget; // 0x0010(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// ScriptStruct Addons.IKFoot
// 0x0060
struct FIKFoot
{
	struct FName BoneName; // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float PullWeight; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool NormalizePulling; // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x000D(0x0003) MISSED OFFSET
	struct FVector PositivePullFactor; // 0x0010(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector NegativePullFactor; // 0x001C(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	unsigned char UnknownData01[0x38]; // 0x0028(0x0038) MISSED OFFSET
};

// ScriptStruct Addons.IKBoneBendDirection
// 0x0018
struct FIKBoneBendDirection
{
	struct FName BoneName; // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FVector BendDirection; // 0x0008(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct Addons.IKBoneLimit
// 0x0030
struct FIKBoneLimit
{
	struct FName BoneName; // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float Stiffness; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData00[0x24]; // 0x000C(0x0024) MISSED OFFSET
};

// ScriptStruct Addons.IKExcludedBone
// 0x0008
struct FIKExcludedBone
{
	struct FName BoneName; // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct Addons.RepPandaEmoteInteract
// 0x0018
struct FRepPandaEmoteInteract
{
	bool bIsEmoteInteraction; // 0x0000(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bIsStopAllEmoteAnim; // 0x0001(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char EmoteAnimID; // 0x0002(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EVehicleEmoteInteractType EmoteType; // 0x0003(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int Count; // 0x0004(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class AActor* Trigger; // 0x0008(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bPlayPassengerAnim; // 0x0010(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct Addons.ViewPoint
// 0x001C
struct FViewPoint
{
	bool bHasSaved; // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
	struct FVector Location; // 0x0004(0x000C) (IsPlainOldData)
	struct FRotator Rotation; // 0x0010(0x000C) (IsPlainOldData)
};

// ScriptStruct Addons.SpeedRangeToAnimPlayRateRange
// 0x0010
struct FSpeedRangeToAnimPlayRateRange
{
	struct FVector2D SpeedRange; // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance, IsPlainOldData)
	struct FVector2D AnimPlayRateRange; // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct Addons.TurnMarginToAnimMargin
// 0x0010
struct FTurnMarginToAnimMargin
{
	struct FVector2D TurnMargin; // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance, IsPlainOldData)
	struct FVector2D AnimMargin; // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct Addons.AccelerationMarginToAnimMargin
// 0x0010
struct FAccelerationMarginToAnimMargin
{
	struct FVector2D AccelerationMargin; // 0x0000(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance, IsPlainOldData)
	struct FVector2D AnimMargin; // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct Addons.DecalState
// 0x0010
struct FDecalState
{
	int State; // 0x0000(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector Pos; // 0x0004(0x000C) (BlueprintVisible, IsPlainOldData)
};

// ScriptStruct Addons.PushSnowBallSize
// 0x0018
struct FPushSnowBallSize
{
	bool bSnowBallActivated; // 0x0000(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0001(0x0007) MISSED OFFSET
	class APenguinSnowBall* SnowBall; // 0x0008(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MovedDistance; // 0x0010(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float Radius; // 0x0014(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.PickTargetParam
// 0x0028
struct FPickTargetParam
{
	bool bStartTraceFromSpringArm; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
	float TraceDistance; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bSingleChannel; // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECollisionChannel> TraceChannel; // 0x0009(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x6]; // 0x000A(0x0006) MISSED OFFSET
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool bCheckActorVisible; // 0x0020(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x7]; // 0x0021(0x0007) MISSED OFFSET
};

// ScriptStruct Addons.PickTargetSweepParam
// 0x0004
struct FPickTargetSweepParam
{
	float SweepRadius; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.PickTargetScreenParam
// 0x0028
struct FPickTargetScreenParam
{
	struct FVector2D ScreenCrosshairBox; // 0x0000(0x0008) (Edit, BlueprintVisible, IsPlainOldData)
	float DetectionRadius; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bCustomFilter; // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECollisionChannel> TraceChannel; // 0x000D(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bCheckActorVisible; // 0x000E(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bCheckComponentVisible; // 0x000F(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bOnlyDetectCharacters; // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0011(0x0007) MISSED OFFSET
	TArray<class UClass*> TargetClasses; // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.PickTargetFanSweepParam
// 0x000C
struct FPickTargetFanSweepParam
{
	int TraceSegments; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float TraceAngle; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bLineTraceFirst; // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0009(0x0003) MISSED OFFSET
};

// ScriptStruct Addons.PickTargetResultFilterParam
// 0x0030
struct FPickTargetResultFilterParam
{
	bool bAutoUseResultFilter; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0001(0x0007) MISSED OFFSET
	struct FName FilterTargetActorTag; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName FilterTargetComponentTag; // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<class UClass*> WrongTargetsClass; // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool bCheckComponentVisible; // 0x0028(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x7]; // 0x0029(0x0007) MISSED OFFSET
};

// ScriptStruct Addons.PickTargetTraceFilterParam
// 0x0030
struct FPickTargetTraceFilterParam
{
	bool bAutoUseTraceFilter; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0001(0x0007) MISSED OFFSET
	struct FName IgnoreActorTag; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName IgnoreComponentTag; // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<class UClass*> IgnoreActorClasses; // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int MaxPenetrationCount; // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct Addons.PickTargetFallbackParam
// 0x0008
struct FPickTargetFallbackParam
{
	ETraceMissedFallback FallbackStrategy; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
	float GroundTraceHeight; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.BuildCheckParam
// 0x0040
struct FBuildCheckParam
{
	bool bAutoUseBuildCheck; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
	float FloatErrorTolerance; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<TEnumAsByte<enum ECollisionChannel>> BlockingChannels; // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<class UClass*> FilterActors; // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FVector BoxExtent; // 0x0028(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	float MaxCheckPlaceHeight; // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bAngleDetect; // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool LocationCheck; // 0x0039(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool OverlapCheck; // 0x003A(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x5]; // 0x003B(0x0005) MISSED OFFSET
};

// ScriptStruct Addons.PickTargetConfig
// 0x0120
struct FPickTargetConfig
{
	EPickTargetMode PickMode; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0001(0x0007) MISSED OFFSET
	struct FPickTargetParam PickParam; // 0x0008(0x0028) (Edit, BlueprintVisible)
	struct FPickTargetSweepParam SweepParam; // 0x0030(0x0004) (Edit, BlueprintVisible)
	unsigned char UnknownData01[0x4]; // 0x0034(0x0004) MISSED OFFSET
	struct FPickTargetScreenParam ScreenParam; // 0x0038(0x0028) (Edit, BlueprintVisible)
	struct FPickTargetFanSweepParam FanSweepParam; // 0x0060(0x000C) (Edit, BlueprintVisible)
	unsigned char UnknownData02[0x4]; // 0x006C(0x0004) MISSED OFFSET
	struct FPickTargetResultFilterParam ResultFilterParam; // 0x0070(0x0030) (Edit, BlueprintVisible)
	struct FPickTargetTraceFilterParam TraceFilterParam; // 0x00A0(0x0030) (Edit, BlueprintVisible)
	struct FPickTargetFallbackParam MissedFallback; // 0x00D0(0x0008) (Edit, BlueprintVisible)
	struct FBuildCheckParam BuildCheckParam; // 0x00D8(0x0040) (Edit, BlueprintVisible)
	bool bDebugDraw; // 0x0118(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData03[0x7]; // 0x0119(0x0007) MISSED OFFSET
};

// ScriptStruct Addons.PickTargetContext
// 0x00D8
struct FPickTargetContext
{
	class ACharacter* OwnerChar; // 0x0000(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName ConfigKey; // 0x0008(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector StartLocation; // 0x0010(0x000C) (BlueprintVisible, IsPlainOldData)
	struct FVector TraceDirection; // 0x001C(0x000C) (BlueprintVisible, IsPlainOldData)
	struct FVector EndLocation; // 0x0028(0x000C) (BlueprintVisible, IsPlainOldData)
	bool bTraceHit; // 0x0034(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0035(0x0003) MISSED OFFSET
	struct FHitResult HitResult; // 0x0038(0x0088) (BlueprintVisible, IsPlainOldData)
	TArray<class AActor*> DetectedActors; // 0x00C0(0x0010) (BlueprintVisible, ZeroConstructor)
	bool bResultValid; // 0x00D0(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bFallbackHit; // 0x00D1(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bFinalResult; // 0x00D2(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x5]; // 0x00D3(0x0005) MISSED OFFSET
};

// ScriptStruct Addons.HeadCapsuleSetup
// 0x0050
struct FHeadCapsuleSetup
{
	struct FName CollisionProfileName; // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FName Tag; // 0x0008(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	float Radius; // 0x0010(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float HalfHeight; // 0x0014(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector RelativeLoc; // 0x0018(0x000C) (Edit, IsPlainOldData)
	struct FRotator RelativeRot; // 0x0024(0x000C) (Edit, IsPlainOldData)
	TArray<TEnumAsByte<enum ECollisionChannel>> TraceChannels; // 0x0030(0x0010) (Edit, ZeroConstructor)
	TArray<TEnumAsByte<enum ECollisionResponse>> TraceResponses; // 0x0040(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct Addons.SpiderSwingDetectResult
// 0x0020
struct FSpiderSwingDetectResult
{
	bool bFound; // 0x0000(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
	struct FVector AttachPoint; // 0x0004(0x000C) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	class AActor* HitActor; // 0x0010(0x0008) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool bFromHit; // 0x0018(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool bIsSkyHook; // 0x0019(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x2]; // 0x001A(0x0002) MISSED OFFSET
	float Score; // 0x001C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.SpiderSwingSyncData
// 0x0024
struct FSpiderSwingSyncData
{
	ESpiderSwingMoveState MoveState; // 0x0000(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
	struct FVector_NetQuantize100 AttachPoint; // 0x0004(0x000C) (BlueprintVisible)
	float RopeLength; // 0x0010(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector_NetQuantize10 Velocity; // 0x0014(0x000C) (BlueprintVisible)
	ESpiderSwingHandSide HandSide; // 0x0020(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x0021(0x0003) MISSED OFFSET
};

// ScriptStruct Addons.SpiderSwingStartRequest
// 0x0010
struct FSpiderSwingStartRequest
{
	struct FVector AttachPoint; // 0x0000(0x000C) (BlueprintVisible, IsPlainOldData)
	ESpiderSwingHandSide ClientHandSide; // 0x000C(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x000D(0x0003) MISSED OFFSET
};

// ScriptStruct Addons.BACustomDamageData
// 0x0030
struct FBACustomDamageData
{
	float ExtraDamageScale; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0004(0x0004) MISSED OFFSET
	struct FString ExtraDamageScaleFormula; // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool bMultiplyOnLayer; // 0x0018(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bEnableAllDamage; // 0x0019(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x6]; // 0x001A(0x0006) MISSED OFFSET
	TArray<TEnumAsByte<enum EWeaponTypeNew>> ValidWeaponTypeMap; // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.BACustomTypeDamageData
// 0x0020 (0x0050 - 0x0030)
struct FBACustomTypeDamageData : public FBACustomDamageData
{
	TArray<int> ResIDArray; // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FName> TagArray; // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.BACustomHpDamageData
// 0x0008 (0x0038 - 0x0030)
struct FBACustomHpDamageData : public FBACustomDamageData
{
	float MinHpPer; // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxHpPer; // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.BACustomDistDamageData
// 0x0008 (0x0038 - 0x0030)
struct FBACustomDistDamageData : public FBACustomDamageData
{
	float minDist; // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxDist; // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.PropSkillExplodeParam
// 0x0024
struct FPropSkillExplodeParam
{
	float GenProbility; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int PropSkillLevel; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float PlayerInnerDamageHealthRatio; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float PlayerOuterDamageHealthRatio; // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float ZombieInnerDamageHealthRatio; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float ZombieOuterDamageHealthRatio; // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float WallWeakenDamageRatio; // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float InnerDamageRadius; // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float OuterDamageRadius; // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.MultipleJumpInfo
// 0x0010
struct FMultipleJumpInfo
{
	TArray<struct FJumpStepInfo> JumpSteps; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.BAWeaponAttrModifyConfig
// 0x0030
struct FBAWeaponAttrModifyConfig
{
	struct FString AttrName; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float ModifyValue; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EAttrModifyRefType AttrRefValueType; // 0x0014(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool MultiplyOnLayer; // 0x0015(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x2]; // 0x0016(0x0002) MISSED OFFSET
	struct FString ModifyValueFormula; // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool ClientSimulate; // 0x0028(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x0029(0x0003) MISSED OFFSET
	uint32_t ModifyID; // 0x002C(0x0004) (ZeroConstructor, Transient, IsPlainOldData)
};

// ScriptStruct Addons.DecorationCircle
// 0x0090
struct FDecorationCircle
{
	unsigned char UnknownData00[0x28]; // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty Addons.DecorationCircle.AssetMesh
	struct FName SocketName; // 0x0028(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FTransform DefaultTransform; // 0x0030(0x0030) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	struct FName MatSlotName; // 0x0060(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TArray<struct FDecorationCircleMatParams> MatParams; // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TWeakObjectPtr<class USkeletalMeshComponent> MeshComponent; // 0x0078(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	TWeakObjectPtr<class UMaterialInstanceDynamic> MatInstance; // 0x0080(0x0008) (BlueprintVisible, ZeroConstructor, Transient, IsPlainOldData)
	unsigned char UnknownData01[0x8]; // 0x0088(0x0008) MISSED OFFSET
};

// ScriptStruct Addons.MyriapodVehicleMovementComponentPostPhysicsTickFunction
// 0x0008 (0x00B8 - 0x00B0)
struct FMyriapodVehicleMovementComponentPostPhysicsTickFunction : public FTickFunction
{
	class USTExtraMyriapodVehMovementCom* Target; // 0x00B0(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// ScriptStruct Addons.TPlanPlayerUndergroundList
// 0x0010
struct FTPlanPlayerUndergroundList
{
	uint64_t PlayerUndergroundIndexLow; // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	uint64_t PlayerUndergroundIndexHigh; // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.TPlanTeamInfo
// 0x0030
struct FTPlanTeamInfo
{
	int TeamID; // 0x0000(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int TeamWorth; // 0x0004(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int TeamKills; // 0x0008(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x000C(0x0004) MISSED OFFSET
	TArray<struct FTPlanPlayerInfo> PlayerInfos; // 0x0010(0x0010) (BlueprintVisible, ZeroConstructor)
	TArray<struct FVector> EscapePosi; // 0x0020(0x0010) (BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.TPlanPlayerInfo
// 0x0010
struct FTPlanPlayerInfo
{
	uint32_t PlayerKey; // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char State; // 0x0004(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0005(0x0003) MISSED OFFSET
	int Kills; // 0x0008(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
	int Worth; // 0x000C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData, RepSkip, RepNotify, Interp, NonTransactional, EditorOnly, NoDestructor, AutoWeak, ContainsInstancedReference, AssetRegistrySearchable, SimpleDisplay, AdvancedDisplay, Protected, BlueprintCallable, BlueprintAuthorityOnly, TextExportTransient, NonPIEDuplicateTransient, ExposeOnSpawn, PersistentInstance, UObjectWrapper, HasGetValueTypeHash, NativeAccessSpecifierPublic, NativeAccessSpecifierProtected, NativeAccessSpecifierPrivate)
};

// ScriptStruct Addons.TitanHide
// 0x001C
struct FTitanHide
{
	bool bHideIngame; // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	bool bStopTick; // 0x0001(0x0001) (ZeroConstructor, IsPlainOldData)
	bool bAutonomousEnter; // 0x0002(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x1]; // 0x0003(0x0001) MISSED OFFSET
	struct FVector Location; // 0x0004(0x000C) (IsPlainOldData)
	struct FRotator Rotation; // 0x0010(0x000C) (IsPlainOldData)
};

// ScriptStruct Addons.AttackPauseFrameData
// 0x0050
struct FAttackPauseFrameData
{
	float PauseDuration; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float NewPlayRateAfterPause; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UParticleSystem* HitParticle; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector ParticleLocationOffset; // 0x0010(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRotator ParticleRotationOffset; // 0x001C(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	class UClass* CameraShaker; // 0x0028(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float CameraShakeScale; // 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0034(0x0004) MISSED OFFSET
	class UAkAudioEvent* HitAudio; // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float CapsuleTraceRadius; // 0x0040(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float CapsuleTraceHalfHeight; // 0x0044(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float CapsuleTraceVerticalOffset; // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float CapsuleTraceForwardOffset; // 0x004C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.TransformerCurveMovingData
// 0x0018
struct FTransformerCurveMovingData
{
	struct FName CurveMovingTag; // 0x0000(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UCurveVector* CurveAsset; // 0x0008(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	ETransformerCurveMoveType CurveType; // 0x0010(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bAdditiveMove; // 0x0011(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bMaintainCurVel; // 0x0012(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bInterruptByInput; // 0x0013(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct Addons.TransformerCurveNetData
// 0x001C
struct FTransformerCurveNetData
{
	int CurveIndex; // 0x0000(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector CurveDirX; // 0x0004(0x000C) (BlueprintVisible, IsPlainOldData)
	struct FVector CurveOrigin; // 0x0010(0x000C) (BlueprintVisible, IsPlainOldData)
};

// ScriptStruct Addons.SkillAction_AttachActorCreateData
// 0x0030
struct FSkillAction_AttachActorCreateData
{
	class UClass* ActorTemplate; // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName AttachSocketName; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector RelativeLocation; // 0x0010(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRotator RelativeRotation; // 0x001C(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	bool DestroyAfterSkill; // 0x0028(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool DestroyAfterPhase; // 0x0029(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool SnapToTargetIncludingScale; // 0x002A(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x1]; // 0x002B(0x0001) MISSED OFFSET
	float DestroyAfterTime; // 0x002C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.AirAttackConfig
// 0x0018
struct FAirAttackConfig
{
	float AttackLastingTime; // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float AttackAreaRadius; // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int TotalBombs; // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float BombsRadius; // 0x000C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	class UClass* BombActorTemplate; // 0x0010(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.SpawnVehicleConfig
// 0x0014
struct FSpawnVehicleConfig
{
	int VehicleSpawnID; // 0x0000(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FVector OffsetLocation; // 0x0004(0x000C) (Edit, BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	bool AutoEnterVehicle; // 0x0010(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0011(0x0003) MISSED OFFSET
};

// ScriptStruct Addons.TargetCommonFilter
// 0x0040
struct FTargetCommonFilter
{
	TArray<EPawnState> ExcludePawnStates; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<int> ExcludeBuffIDs; // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FName> ExcludeActorTags; // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FName> RequiredActorTags; // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.SkillAction_HideMainUIData
// 0x0010
struct FSkillAction_HideMainUIData
{
	struct FString RegistUIName; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.PlayMontageAsyncloadParams
// 0x0038
struct FPlayMontageAsyncloadParams
{
	unsigned char UnknownData00[0x38]; // 0x0000(0x0038) MISSED OFFSET
};

// ScriptStruct Addons.WeaponStateToAnimPair
// 0x01A8
struct FWeaponStateToAnimPair
{
	TEnumAsByte<enum EWeaponTypeNew> WeaponTypeNew; // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0001(0x0007) MISSED OFFSET
	struct FSkillPoseMontageData PoseMontageData; // 0x0008(0x00D0) (Edit)
	struct FSkillPoseMontageData FPPPoseMontageData; // 0x00D8(0x00D0) (Edit)
};

// ScriptStruct Addons.SkillAction_SequenceCreateData
// 0x0068
struct FSkillAction_SequenceCreateData
{
	struct FSoftClassPath SequenceActorTemplate; // 0x0000(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	struct FSoftObjectPath LevelSequence; // 0x0018(0x0018) (Edit, BlueprintVisible, BlueprintReadOnly)
	bool bUseSelfTransformOrigin; // 0x0030(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0031(0x0007) MISSED OFFSET
	class UUTSkillLocationPicker* LocationPicker; // 0x0038(0x0008) (Edit, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	class UUAESkillPicker* TargetTransformPicker; // 0x0040(0x0008) (Edit, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	bool bSetLocationToBB; // 0x0048(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x7]; // 0x0049(0x0007) MISSED OFFSET
	struct FName BBName; // 0x0050(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	bool bDestroyedAtSkillEnd; // 0x0058(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bForceDestroyedAtSkillEnd; // 0x0059(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x6]; // 0x005A(0x0006) MISSED OFFSET
	struct FUAEBlackboardKeySelector CachedSpawnActorKey; // 0x0060(0x0008) (Edit, BlueprintVisible)
};

// ScriptStruct Addons.SkillAction_ShowMainUIData
// 0x0018
struct FSkillAction_ShowMainUIData
{
	struct FString RegistUIName; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool AutoHideOnPhaseEnd; // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct Addons.SkillAction_SpawnActorCreateData
// 0x00E8
struct FSkillAction_SpawnActorCreateData
{
	class UClass* ActorTemplate; // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x28]; // 0x0008(0x0028) UNKNOWN PROPERTY: SoftClassProperty Addons.SkillAction_SpawnActorCreateData.SoftActorTemplate
	struct FVector DefaultLocationOffset; // 0x0030(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	bool bPickFromTarget; // 0x003C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x003D(0x0003) MISSED OFFSET
	class UUAESkillPicker* DamagePicker; // 0x0040(0x0008) (Edit, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	bool bSetLocationToBB; // 0x0048(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bSetLocationToSkillBB; // 0x0049(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x6]; // 0x004A(0x0006) MISSED OFFSET
	struct FName BBName; // 0x0050(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	bool bTraceGround; // 0x0058(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData03[0x3]; // 0x0059(0x0003) MISSED OFFSET
	struct FVector TraceGroundOffset; // 0x005C(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	class UUTSkillLocationPicker* LocationPicker; // 0x0068(0x0008) (Edit, BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	bool bTriggerPickFailedEvent; // 0x0070(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData04[0x7]; // 0x0071(0x0007) MISSED OFFSET
	struct FString TriggerPickFailedEventName; // 0x0078(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool bLocalSpawn; // 0x0088(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bClientSpawn; // 0x0089(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bDestroyedAtSkillEnd; // 0x008A(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bForceDestroyedAtSkillEnd; // 0x008B(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float DelayDestroyedAtSkillEnd; // 0x008C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bUseOffsetWithOutLocationPicker; // 0x0090(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bUseOffsetWithDamagePicker; // 0x0091(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bEnableAttach; // 0x0092(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData05[0x5]; // 0x0093(0x0005) MISSED OFFSET
	struct FName AttachSocket; // 0x0098(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bAlignMainMesh; // 0x00A0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bAlignRotation; // 0x00A1(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bAlignScale3D; // 0x00A2(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData06[0x1]; // 0x00A3(0x0001) MISSED OFFSET
	struct FVector OffsetLocationStand; // 0x00A4(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector OffsetLocationCrouch; // 0x00B0(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector OffsetLocationProne; // 0x00BC(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRotator OffsetRotation; // 0x00C8(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	bool bAllowChangePoseWillUpdating; // 0x00D4(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bEnableRelativeTransform; // 0x00D5(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData07[0x2]; // 0x00D6(0x0002) MISSED OFFSET
	struct FUAEBlackboardKeySelector CachedSpawnActorKey; // 0x00D8(0x0008) (Edit, BlueprintVisible)
	float DelaySecondsDestroy; // 0x00E0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	ESpawnActorCollisionHandlingMethod SpawnMethod; // 0x00E4(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData08[0x3]; // 0x00E5(0x0003) MISSED OFFSET
};

// ScriptStruct Addons.BeamEffectData
// 0x0030
struct FBeamEffectData
{
	EBeamEffectDataFromType DataFromType; // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
	struct FVector Location; // 0x0004(0x000C) (Edit, IsPlainOldData)
	struct FVector LocationOffset; // 0x0010(0x000C) (Edit, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x001C(0x0004) MISSED OFFSET
	struct FName BlackBoardParam; // 0x0020(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FName AttachPointName; // 0x0028(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.SkillAction_SpawnProjectileCreateData
// 0x0020
struct FSkillAction_SpawnProjectileCreateData
{
	class UClass* ProjectileTemplate; // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector OffsetLocation; // 0x0008(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRotator OffsetRotation; // 0x0014(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct Addons.UTSkillAppearance_ParticleSystem_Item
// 0x0108
struct FUTSkillAppearance_ParticleSystem_Item
{
	class UUTSkillPicker* TargetPicker; // 0x0000(0x0008) (Edit, BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	class UParticleSystem* TemplateSelfTeam_Effect; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UParticleSystem* TemplateEnermyTeam_Effect; // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UParticleSystem* TemplateSelfTeamFPP_Effect; // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x28]; // 0x0020(0x0028) UNKNOWN PROPERTY: SoftObjectProperty Addons.UTSkillAppearance_ParticleSystem_Item.TemplateSelfTeam_Effect_Soft
	unsigned char UnknownData01[0x28]; // 0x0048(0x0028) UNKNOWN PROPERTY: SoftObjectProperty Addons.UTSkillAppearance_ParticleSystem_Item.TemplateEnermyTeam_Effect_Soft
	unsigned char UnknownData02[0x28]; // 0x0070(0x0028) UNKNOWN PROPERTY: SoftObjectProperty Addons.UTSkillAppearance_ParticleSystem_Item.TemplateSelfTeamFPP_Effect_Soft
	bool bLoop; // 0x0098(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool StopAfterPhase; // 0x0099(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData03[0x2]; // 0x009A(0x0002) MISSED OFFSET
	float Scale; // 0x009C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName SocketName; // 0x00A0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName RefSocketName; // 0x00A8(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector LocationOffset; // 0x00B0(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRotator RotationOffset; // 0x00BC(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector LocationOffsetTPP; // 0x00C8(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRotator RotationOffsetTPP; // 0x00D4(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	float ScaleTPP; // 0x00E0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData04[0x4]; // 0x00E4(0x0004) MISSED OFFSET
	struct FName HurtRotationSocketName; // 0x00E8(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float AutoDispearTime; // 0x00F0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bAttachToPawn; // 0x00F4(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData05[0x3]; // 0x00F5(0x0003) MISSED OFFSET
	float DetachOnDelayTime; // 0x00F8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bNeedEmitter; // 0x00FC(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool DisableOnLowCPU; // 0x00FD(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData06[0x2]; // 0x00FE(0x0002) MISSED OFFSET
	struct FName DamageableInterfaceTag; // 0x0100(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.UTSkillAppearance_SoundCue_Item
// 0x0068
struct FUTSkillAppearance_SoundCue_Item
{
	EUTSkill_SoundCue_ListenType ListenType; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0001(0x0007) MISSED OFFSET
	class UAkAudioEvent* AkEvent; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x28]; // 0x0010(0x0028) UNKNOWN PROPERTY: SoftObjectProperty Addons.UTSkillAppearance_SoundCue_Item.AkEvent_SoftPtr
	unsigned char UnknownData02[0x28]; // 0x0038(0x0028) UNKNOWN PROPERTY: SoftObjectProperty Addons.UTSkillAppearance_SoundCue_Item.StopAkEvent_SoftPtr
	bool bLoop; // 0x0060(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData03[0x7]; // 0x0061(0x0007) MISSED OFFSET
};

// ScriptStruct Addons.BioHitData
// 0x0028
struct FBioHitData
{
	float Time; // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int Frame; // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	float Damage; // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FVector LaunchVelocity; // 0x000C(0x000C) (IsPlainOldData)
	class AActor* HitActor; // 0x0018(0x0008) (ZeroConstructor, IsPlainOldData)
	class UPrimitiveComponent* HitComponent; // 0x0020(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// ScriptStruct Addons.VehicleHitBioVHTriggerSetup
// 0x0018
struct FVehicleHitBioVHTriggerSetup
{
	struct FName CollisionProfileName; // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FName Tag; // 0x0008(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	float Radius; // 0x0010(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float HalfHeight; // 0x0014(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.DynamicTriggerShape
// 0x000C
struct FDynamicTriggerShape
{
	float Radius; // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	float HalfHeight; // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	float LastUpdateSpeed; // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.NitroBoostState
// 0x000C
struct FNitroBoostState
{
	bool bIsNitroBoosting; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
	float StartTimestamp; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int BoostCount; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct Addons.NitroPowerConfig
// 0x0040
struct FNitroPowerConfig
{
	class UCurveFloat* NitroForceCurve; // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UCurveFloat* NitroForceSpeedRatio; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UCurveVector* DriftOmegaAccelCurve; // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UCurveVector* DriftRecoveryCurve; // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UCurveVector* DriftSpeedCurve; // 0x0020(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UCurveFloat* DriftAccelCurve; // 0x0028(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UCurveFloat* DriftAccelScaleCurve; // 0x0030(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UCurveFloat* DriftDecelCurve; // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct Addons.VDDebugFlag
// 0x0007
struct FVDDebugFlag
{
	bool bEnable; // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	int8_t bDebugBasic; // 0x0001(0x0001) (ZeroConstructor, IsPlainOldData)
	int8_t bDebugBT; // 0x0002(0x0001) (ZeroConstructor, IsPlainOldData)
	int8_t bDebugMove; // 0x0003(0x0001) (ZeroConstructor, IsPlainOldData)
	int8_t bDebugEnemy; // 0x0004(0x0001) (ZeroConstructor, IsPlainOldData)
	int8_t bDebugLOD; // 0x0005(0x0001) (ZeroConstructor, IsPlainOldData)
	int8_t bDebugOutline; // 0x0006(0x0001) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.BTDebugSnapshot
// 0x0028 (0x00D8 - 0x00B0)
struct FBTDebugSnapshot : public FFastArraySerializer
{
	struct FVector AnchorOffset; // 0x00B0(0x000C) (IsPlainOldData)
	struct FColor Color; // 0x00BC(0x0004) (IsPlainOldData)
	float TextScale; // 0x00C0(0x0004) (ZeroConstructor, IsPlainOldData)
	uint32_t FrameSerial; // 0x00C4(0x0004) (ZeroConstructor, IsPlainOldData)
	TArray<struct FBTDebugNodeItem> Items; // 0x00C8(0x0010) (ZeroConstructor)
};

// ScriptStruct Addons.VisualDraw
// 0x002C
struct FVisualDraw
{
	struct FVector BasePosition; // 0x0000(0x000C) (BlueprintVisible, IsPlainOldData)
	TWeakObjectPtr<class AActor> AttachedActor; // 0x000C(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FColor BaseColor; // 0x0014(0x0004) (BlueprintVisible, IsPlainOldData)
	float Duration; // 0x0018(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float Thickness; // 0x001C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int TaskId; // 0x0020(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bContinuous; // 0x0024(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0025(0x0007) MISSED OFFSET
};

// ScriptStruct Addons.DrawShape_Text
// 0x0014 (0x0040 - 0x002C)
struct FDrawShape_Text : public FVisualDraw
{
	unsigned char UnknownData00[0x4]; // 0x002C(0x0004) MISSED OFFSET
	struct FString TextString; // 0x0030(0x0010) (BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.DrawShape_Sphere
// 0x0004 (0x0030 - 0x002C)
struct FDrawShape_Sphere : public FVisualDraw
{
	float Radius; // 0x002C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.DrawShape_Line
// 0x000C (0x0038 - 0x002C)
struct FDrawShape_Line : public FVisualDraw
{
	struct FVector LineEnd; // 0x002C(0x000C) (BlueprintVisible, IsPlainOldData)
};

// ScriptStruct Addons.DrawShape_Cylinder
// 0x0010 (0x003C - 0x002C)
struct FDrawShape_Cylinder : public FVisualDraw
{
	struct FVector End; // 0x002C(0x000C) (BlueprintVisible, IsPlainOldData)
	float Radius; // 0x0038(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.DrawShape_Capsule
// 0x0014 (0x0040 - 0x002C)
struct FDrawShape_Capsule : public FVisualDraw
{
	float Radius; // 0x002C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float HalfHeight; // 0x0030(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FRotator Rotation; // 0x0034(0x000C) (BlueprintVisible, IsPlainOldData)
};

// ScriptStruct Addons.DrawShape_Box
// 0x0018 (0x0044 - 0x002C)
struct FDrawShape_Box : public FVisualDraw
{
	struct FVector BoxExtent; // 0x002C(0x000C) (BlueprintVisible, IsPlainOldData)
	struct FRotator Rotation; // 0x0038(0x000C) (BlueprintVisible, IsPlainOldData)
};

// ScriptStruct Addons.WindowBarrierDataList
// 0x0010
struct FWindowBarrierDataList
{
	TArray<struct FWindowBarrierData> Datas; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.BioSimulateLODThesholds
// 0x000C
struct FBioSimulateLODThesholds
{
	float ScreenSize; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float LODOptimizeCosAngle; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float QueryPhysicsInternal; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.SpiderSwingAttachInfo
// 0x0018
struct FSpiderSwingAttachInfo
{
	struct FVector AttachPoint; // 0x0000(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	float RopeLength; // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TWeakObjectPtr<class AActor> AttachTarget; // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.FootStepEffect
// 0x0030
struct FFootStepEffect
{
	unsigned char UnknownData00[0x28]; // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty Addons.FootStepEffect.ParticleTemplate
	int EnableDeviceLevel; // 0x0028(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct Addons.FlyBioVehicleUpdateDistanceToLandConfig
// 0x000C
struct FFlyBioVehicleUpdateDistanceToLandConfig
{
	float Height; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float Interval; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bUseSweep; // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0009(0x0003) MISSED OFFSET
};

// ScriptStruct Addons.FlyBioVehicleLandingConfig
// 0x0018
struct FFlyBioVehicleLandingConfig
{
	float MaxAllowedFlyingSpeed; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxLandingTime; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float LandingToGroundTime; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bForceToGroundInFixedTime; // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x000D(0x0003) MISSED OFFSET
	class UCurveVector* LandingCurve; // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.AnimNode_AdvanceBlendSpacePlayer
// 0x03A0 (0x03F8 - 0x0058)
struct FAnimNode_AdvanceBlendSpacePlayer : public FAnimNode_AssetPlayerBase
{
	float X; // 0x0058(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float Y; // 0x005C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float Z; // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float PlayRate; // 0x0064(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bLoop; // 0x0068(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bResetPlayTimeWhenBlendSpaceChanges; // 0x0069(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x2]; // 0x006A(0x0002) MISSED OFFSET
	float StartPosition; // 0x006C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UBlendSpaceBase* BlendSpace; // 0x0070(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int LODThreshold; // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0xA4]; // 0x007C(0x00A4) MISSED OFFSET
	class UBlendSpaceBase* PreviousBlendSpace; // 0x0120(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	EBlendCrossFadeOption CFadeStyle; // 0x0128(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x3]; // 0x0129(0x0003) MISSED OFFSET
	float CFadeBlendTime; // 0x012C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EAlphaBlendOption BlendType; // 0x0130(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData03[0x7]; // 0x0131(0x0007) MISSED OFFSET
	class UCurveFloat* CustomBlendCurve; // 0x0138(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	bool bUseBlendInTheSameCache; // 0x0140(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData04[0x7]; // 0x0141(0x0007) MISSED OFFSET
	class UBlendSpaceBase* SourceBlendSpace; // 0x0148(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	class UBlendSpaceBase* TargetBlendSpace; // 0x0150(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char UnknownData05[0x298]; // 0x0158(0x0298) MISSED OFFSET
	class USkeletalMesh* CachedSkeletalMesh; // 0x03F0(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.SpecifiedBones
// 0x0050
struct FSpecifiedBones
{
	unsigned char UnknownData00[0x50]; // 0x0000(0x0050) UNKNOWN PROPERTY: SetProperty Addons.SpecifiedBones.Data
};

// ScriptStruct Addons.AnimNode_AIRuntimeAnimDataToPose
// 0x0150 (0x01C8 - 0x0078)
struct FAnimNode_AIRuntimeAnimDataToPose : public FAnimNode_SkeletalControlBase
{
	unsigned char UnknownData00[0x50]; // 0x0078(0x0050) MISSED OFFSET
	class ACharacter* OwnerCharacter; // 0x00C8(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FAIGCRuntimeBodyAnimFrameData AIRuntimeBodyAnimFrameData; // 0x00D0(0x00A0) (Edit, BlueprintVisible)
	TEnumAsByte<enum EBoneControlSpace> TransformSpace; // 0x0170(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bUseSpecifiedBones; // 0x0171(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x6]; // 0x0172(0x0006) MISSED OFFSET
	struct FSpecifiedBones SpecifiedBones; // 0x0178(0x0050) (Edit)
};

// ScriptStruct Addons.AnimNode_ApplyLimits
// 0x0020 (0x0098 - 0x0078)
struct FAnimNode_ApplyLimits : public FAnimNode_SkeletalControlBase
{
	TArray<struct FAngularRangeLimit> AngularRangeLimits; // 0x0078(0x0010) (Edit, ZeroConstructor)
	TArray<struct FVector> AngularOffsets; // 0x0088(0x0010) (Edit, BlueprintVisible, EditFixedSize, ZeroConstructor)
};

// ScriptStruct Addons.AngularRangeLimit
// 0x0030
struct FAngularRangeLimit
{
	struct FVector LimitMin; // 0x0000(0x000C) (Edit, IsPlainOldData)
	struct FVector LimitMax; // 0x000C(0x000C) (Edit, IsPlainOldData)
	struct FBoneReference Bone; // 0x0018(0x0018) (Edit)
};

// ScriptStruct Addons.AnimNode_CCDIK
// 0x00C8 (0x0140 - 0x0078)
struct FAnimNode_CCDIK : public FAnimNode_SkeletalControlBase
{
	struct FVector EffectorLocation; // 0x0078(0x000C) (Edit, IsPlainOldData)
	TEnumAsByte<enum EBoneControlSpace> EffectorLocationSpace; // 0x0084(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0xB]; // 0x0085(0x000B) MISSED OFFSET
	struct FBoneSocketTarget EffectorTarget; // 0x0090(0x0060) (Edit)
	struct FBoneReference TipBone; // 0x00F0(0x0018) (Edit)
	struct FBoneReference RootBone; // 0x0108(0x0018) (Edit)
	float Precision; // 0x0120(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int MaxIterations; // 0x0124(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool bStartFromTail; // 0x0128(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bEnableRotationLimit; // 0x0129(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x6]; // 0x012A(0x0006) MISSED OFFSET
	TArray<float> RotationLimitPerJoints; // 0x0130(0x0010) (Edit, EditFixedSize, ZeroConstructor)
};

// ScriptStruct Addons.CCDIKChainLink
// 0x0080
struct FCCDIKChainLink
{
	unsigned char UnknownData00[0x80]; // 0x0000(0x0080) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_CloseToWall
// 0x0060 (0x00D8 - 0x0078)
struct FAnimNode_CloseToWall : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference RootBone; // 0x0078(0x0018) (Edit)
	TArray<struct FBoneReference> TraceBones; // 0x0090(0x0010) (Edit, ZeroConstructor)
	TArray<TEnumAsByte<enum ECollisionChannel>> ObjectTypesToTrace; // 0x00A0(0x0010) (Edit, ZeroConstructor)
	float TraceSphereRadius; // 0x00B0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float TraceForwardOffset; // 0x00B4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float TraceBackwardOffset; // 0x00B8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector forwardDir; // 0x00BC(0x000C) (Edit, IsPlainOldData)
	float IntendedWallDis; // 0x00C8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float InterpSpeed; // 0x00CC(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool bDrawDebug; // 0x00D0(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x00D1(0x0007) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_CreepingFourLegIK
// 0x0188 (0x0200 - 0x0078)
struct FAnimNode_CreepingFourLegIK : public FAnimNode_SkeletalControlBase
{
	bool bEnableSlopeAdapt; // 0x0078(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bEnableLegAdapt; // 0x0079(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bEnableFootLock; // 0x007A(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData00[0x5]; // 0x007B(0x0005) MISSED OFFSET
	class UCurveFloat* SlopePitchCurve; // 0x0080(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UCurveFloat* SlopeRollCurve; // 0x0088(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UCurveFloat* SlopeHeightCurve; // 0x0090(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopeHeightAdditive; // 0x0098(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopePitchAdditive; // 0x009C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopeRollAdditive; // 0x00A0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopeMapInMin; // 0x00A4(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopeMapInMax; // 0x00A8(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopeProbeForwardOffset; // 0x00AC(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopeProbeBackwardOffset; // 0x00B0(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopeProbeLeftOffset; // 0x00B4(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopeProbeRightOffset; // 0x00B8(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float FootLockDelaySeconds; // 0x00BC(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float FootLockOutOfDistanceInterpSpeed; // 0x00C0(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bIgnoreFoliage; // 0x00C4(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x00C5(0x0003) MISSED OFFSET
	float TraceUpOffset; // 0x00C8(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float TraceDownOffset; // 0x00CC(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float TraceSphereRadius; // 0x00D0(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData02[0x4]; // 0x00D4(0x0004) MISSED OFFSET
	TArray<TEnumAsByte<enum ECollisionChannel>> ObjectTypesToTrace; // 0x00D8(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FName> TraceIgnoreActorTags; // 0x00E8(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	float SlopeTraceInterval; // 0x00F8(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float LimbTraceInterval; // 0x00FC(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float LimbOffsetClampMin; // 0x0100(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float LimbOffsetClampMax; // 0x0104(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float FootAdaptMaxPitch; // 0x0108(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float FootAdaptMaxRoll; // 0x010C(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float IKInterpSpeed; // 0x0110(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bSlopeAdaptUseAlpha; // 0x0114(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData03[0x3]; // 0x0115(0x0003) MISSED OFFSET
	float SlopeAdaptMinZ; // 0x0118(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopeAdaptMaxZ; // 0x011C(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopeAdaptMaxPitch; // 0x0120(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopeAdaptMaxRoll; // 0x0124(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bUseNeckAdapt; // 0x0128(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData04[0x3]; // 0x0129(0x0003) MISSED OFFSET
	float NeckAdaptMinPitch; // 0x012C(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float NeckAdaptMaxPitch; // 0x0130(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopeInterpSpeed; // 0x0134(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TArray<struct FLimb> LegLimbs; // 0x0138(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FBoneReference AdaptRootBone; // 0x0148(0x0018) (Edit, DisableEditOnInstance)
	struct FBoneReference NeckBone; // 0x0160(0x0018) (Edit, DisableEditOnInstance)
	float DebugSphereRadius; // 0x0178(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float DebugLineWidth; // 0x017C(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TWeakObjectPtr<class UWorld> WorldContext; // 0x0180(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char UnknownData05[0x78]; // 0x0188(0x0078) MISSED OFFSET
};

// ScriptStruct Addons.Limb
// 0x0380
struct FLimb
{
	struct FBoneReference TipBone; // 0x0000(0x0018) (Edit, BlueprintVisible, DisableEditOnInstance)
	struct FBoneReference IKBone; // 0x0018(0x0018) (Edit, BlueprintVisible, DisableEditOnInstance)
	struct FAnimNode_TwoBoneIK IKNode; // 0x0030(0x01C0) (Edit, BlueprintVisible, DisableEditOnInstance)
	struct FName LockCurveName; // 0x01F0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float MaxLockDistanceClockwise; // 0x01F8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float MaxLockDistanceCounterclockwise; // 0x01FC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bUseLimbClamp; // 0x0200(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0201(0x0003) MISSED OFFSET
	float LimbOffsetClampMin; // 0x0204(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float LimbOffsetClampMax; // 0x0208(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bIsLeft; // 0x020C(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bIsForward; // 0x020D(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData01[0x2]; // 0x020E(0x0002) MISSED OFFSET
	struct FName TraceSocketName; // 0x0210(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData02[0x168]; // 0x0218(0x0168) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_DistanceMatching
// 0x0100 (0x0170 - 0x0070)
struct FAnimNode_DistanceMatching : public FAnimNode_SequencePlayer
{
	struct FName SyncGroupName; // 0x0070(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float Distance; // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x007C(0x0004) MISSED OFFSET
	struct FName RootBoneName; // 0x0080(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float AcceptedDistanceError; // 0x0088(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bUseSuperUpdate; // 0x008C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x008D(0x0003) MISSED OFFSET
	struct FFloatCurve DistanceCurve; // 0x0090(0x0090)
	bool bHasValidDistanceCurve; // 0x0120(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x4F]; // 0x0121(0x004F) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_FootLock
// 0x0058 (0x00D0 - 0x0078)
struct FAnimNode_FootLock : public FAnimNode_SkeletalControlBase
{
	TArray<struct FFootLockLimb> Limbs; // 0x0078(0x0010) (Edit, ZeroConstructor)
	float MaxLockDistance; // 0x0088(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x44]; // 0x008C(0x0044) MISSED OFFSET
};

// ScriptStruct Addons.FootLockLimb
// 0x0210
struct FFootLockLimb
{
	struct FName CurveName; // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FBoneReference LockBone; // 0x0008(0x0018) (Edit, BlueprintVisible)
	struct FAnimNode_TwoBoneIK IKNode; // 0x0020(0x01C0) (Edit)
	unsigned char UnknownData00[0x30]; // 0x01E0(0x0030) MISSED OFFSET
};

// ScriptStruct Addons.BoneDeclare
// 0x0060
struct FBoneDeclare
{
	struct FBoneReference Bone; // 0x0000(0x0018) (Edit, DisableEditOnInstance)
	struct FVector ForwardAxis; // 0x0018(0x000C) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FVector RightAxis; // 0x0024(0x000C) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FVector UpAxis; // 0x0030(0x000C) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FRotator PitchAxis; // 0x003C(0x000C) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FRotator YawAxis; // 0x0048(0x000C) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FRotator RollAxis; // 0x0054(0x000C) (Edit, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct Addons.AnimNode_FourLeggedIK
// 0x0DD8 (0x0E50 - 0x0078)
struct FAnimNode_FourLeggedIK : public FAnimNode_SkeletalControlBase
{
	bool bEnableSlopeAdapt; // 0x0078(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bEnableLegAdapt; // 0x0079(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bEnableFootAdapt; // 0x007A(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bEnableNeckAdapt; // 0x007B(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bUseSocketTrace; // 0x007C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bEnableTraceOptimization; // 0x007D(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bTraceNotHitUseOriginPosition; // 0x007E(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bProcessLeftRightOverDistance; // 0x007F(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float MaxLeftRightSideDifference; // 0x0080(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bSendTraceResultsMessage; // 0x0084(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0085(0x0003) MISSED OFFSET
	class UCurveFloat* SlopeHeightAdaptedCurve; // 0x0088(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopeHeightAdditive; // 0x0090(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x0094(0x0004) MISSED OFFSET
	class UCurveFloat* SlopePitchAdaptedCurve; // 0x0098(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopePitchAdditive; // 0x00A0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData02[0x4]; // 0x00A4(0x0004) MISSED OFFSET
	TArray<TEnumAsByte<enum ECollisionChannel>> ObjectTypesToTrace; // 0x00A8(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	float TraceUpOffset; // 0x00B8(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float TraceDownOffset; // 0x00BC(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float TraceSphereRadius; // 0x00C0(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopeAdaptionMaxPitch; // 0x00C4(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopeAdaptionMaxZ; // 0x00C8(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float SlopeAdaptLerpSpeed; // 0x00CC(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float FootAdaptMaxRoll; // 0x00D0(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float FootAdaptMaxPitch; // 0x00D4(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float FootIKAdaptMaxZ; // 0x00D8(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float FootIKLerpSpeed; // 0x00DC(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FBoneDeclare AdaptBone; // 0x00E0(0x0060) (Edit, DisableEditOnInstance)
	struct FBoneDeclare NeckBone; // 0x0140(0x0060) (Edit, DisableEditOnInstance)
	struct FBoneDeclare LClavicleBone; // 0x01A0(0x0060) (Edit, DisableEditOnInstance)
	struct FBoneDeclare RClavicleBone; // 0x0200(0x0060) (Edit, DisableEditOnInstance)
	struct FBoneDeclare LThighBone; // 0x0260(0x0060) (Edit, DisableEditOnInstance)
	struct FBoneDeclare RThighBone; // 0x02C0(0x0060) (Edit, DisableEditOnInstance)
	struct FBoneDeclare LeftHandBone; // 0x0320(0x0060) (Edit, DisableEditOnInstance)
	struct FBoneDeclare RightHandBone; // 0x0380(0x0060) (Edit, DisableEditOnInstance)
	struct FBoneDeclare LeftFootBone; // 0x03E0(0x0060) (Edit, DisableEditOnInstance)
	struct FBoneDeclare RightFootBone; // 0x0440(0x0060) (Edit, DisableEditOnInstance)
	struct FBoneSocketTarget LeftHandTraceSocket; // 0x04A0(0x0060) (Edit, DisableEditOnInstance)
	struct FBoneSocketTarget RightHandTraceSocket; // 0x0500(0x0060) (Edit, DisableEditOnInstance)
	struct FBoneSocketTarget LeftFootTraceSocket; // 0x0560(0x0060) (Edit, DisableEditOnInstance)
	struct FBoneSocketTarget RightFootTraceSocket; // 0x05C0(0x0060) (Edit, DisableEditOnInstance)
	struct FAnimNode_TwoBoneIK LeftHandIK; // 0x0620(0x01C0) (Edit, DisableEditOnInstance)
	struct FAnimNode_TwoBoneIK RightHandIK; // 0x07E0(0x01C0) (Edit, DisableEditOnInstance)
	struct FAnimNode_TwoBoneIK LeftFootIK; // 0x09A0(0x01C0) (Edit, DisableEditOnInstance)
	struct FAnimNode_TwoBoneIK RightFootIK; // 0x0B60(0x01C0) (Edit, DisableEditOnInstance)
	float DebugSphereRadius; // 0x0D20(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float DebugLineWidth; // 0x0D24(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float DebugArrowSize; // 0x0D28(0x0004) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FColor DebugNegativeColor; // 0x0D2C(0x0004) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FColor DebugPositiveColor; // 0x0D30(0x0004) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FColor DebugInfoColor; // 0x0D34(0x0004) (Edit, DisableEditOnInstance, IsPlainOldData)
	struct FVector2D DebugTextSize; // 0x0D38(0x0008) (Edit, DisableEditOnInstance, IsPlainOldData)
	class APawn* OwnerPawn; // 0x0D40(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char UnknownData03[0x108]; // 0x0D48(0x0108) MISSED OFFSET
};

// ScriptStruct Addons.IKBodyInertia
// 0x0014
struct FIKBodyInertia
{
	bool ApplyInertiaToBody; // 0x0000(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
	float SmoothFactor; // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool UseSpring; // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x0009(0x0003) MISSED OFFSET
	float SpringStrength; // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float SpringDamping; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.FootIKCollision
// 0x0028
struct FFootIKCollision
{
	TEnumAsByte<enum ECollisionChannel> CollisionChannel; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool TraceComplex; // 0x0001(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x2]; // 0x0002(0x0002) MISSED OFFSET
	float RayCastUp; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float RayCastDown; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool EnableWallCollision; // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x000D(0x0003) MISSED OFFSET
	float WallOffset; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bEnableCheckIgnoreActorName; // 0x0014(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x3]; // 0x0015(0x0003) MISSED OFFSET
	TArray<struct FName> IgnoreHitTags; // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.AnimNode_GroundIK
// 0x02D0 (0x0348 - 0x0078)
struct FAnimNode_GroundIK : public FAnimNode_SkeletalControlBase
{
	struct FName Root; // 0x0078(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FIKBodyInertia BodyInertia; // 0x0080(0x0014) (Edit)
	unsigned char UnknownData00[0x4]; // 0x0094(0x0004) MISSED OFFSET
	TArray<struct FIKFoot> Feet; // 0x0098(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	float FeetDeltaSmoothSpeed; // 0x00A8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float RootRotationMultiplier; // 0x00AC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FFootIKCollision FootCollision; // 0x00B0(0x0028) (Edit, BlueprintVisible, DisableEditOnInstance)
	struct FFootIKSlope FootSlope; // 0x00D8(0x0098) (Edit, BlueprintVisible)
	TArray<struct FIKBoneBendDirection> BendDirections; // 0x0170(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FIKExcludedBone> ExcludedBones; // 0x0180(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	TArray<struct FIKBoneLimit> JointLimits; // 0x0190(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	unsigned char UnknownData01[0x10]; // 0x01A0(0x0010) MISSED OFFSET
	int MaxSquashIterations; // 0x01B0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int MaxStretchIterations; // 0x01B4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int MaxFinalIterations; // 0x01B8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool AllowBoneTranslation; // 0x01BC(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x3]; // 0x01BD(0x0003) MISSED OFFSET
	float SolverAlpha; // 0x01C0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float DebugDrawSize; // 0x01C4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool bShowDebug; // 0x01C8(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData03[0x7]; // 0x01C9(0x0007) MISSED OFFSET
	class UWorld* World; // 0x01D0(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData04[0x170]; // 0x01D8(0x0170) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_HumanoidLeggedIK
// 0x0488 (0x0500 - 0x0078)
struct FAnimNode_HumanoidLeggedIK : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference RootBone; // 0x0078(0x0018) (Edit)
	struct FBoneReference LeftFootBone; // 0x0090(0x0018) (Edit)
	struct FBoneReference RightFootBone; // 0x00A8(0x0018) (Edit)
	class UBoneParamDefineAsset* BoneParamDefine; // 0x00C0(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	bool bEnableRootAdaption; // 0x00C8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bEnableLegAdaption; // 0x00C9(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bEnableFootAdaption; // 0x00CA(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x5]; // 0x00CB(0x0005) MISSED OFFSET
	TArray<TEnumAsByte<enum ECollisionChannel>> ObjectTypesToTrace; // 0x00D0(0x0010) (Edit, ZeroConstructor)
	float FootTraceUpOffset; // 0x00E0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float FootTraceDownOffset; // 0x00E4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float FootTraceSphereRadius; // 0x00E8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool bIgnoreSelfType; // 0x00EC(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x00ED(0x0003) MISSED OFFSET
	float RootPositionInterpolateSpeed; // 0x00F0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float FootPositionInterpolateSpeed; // 0x00F4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float FootRotationInterpolateSpeed; // 0x00F8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float RootHeightOffsetScale; // 0x00FC(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float RootMaxHeightOffset; // 0x0100(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float FootMaxHeightOffset; // 0x0104(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float FootMaxPitchOffset; // 0x0108(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float FootMaxRollOffset; // 0x010C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FAnimNode_TwoBoneIK LeftFootIKNode; // 0x0110(0x01C0) (Edit, DisableEditOnInstance)
	struct FAnimNode_TwoBoneIK RightFootIKNode; // 0x02D0(0x01C0) (Edit, DisableEditOnInstance)
	unsigned char UnknownData02[0x70]; // 0x0490(0x0070) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_InertializationBlendListBase
// 0x0000 (0x00D0 - 0x00D0)
struct FAnimNode_InertializationBlendListBase : public FAnimNode_BlendListBase
{

};

// ScriptStruct Addons.AnimNode_InertializationBlendByBool
// 0x0000 (0x00D0 - 0x00D0)
struct FAnimNode_InertializationBlendByBool : public FAnimNode_InertializationBlendListBase
{
	bool bActiveValue; // 0x00C9(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x6]; // 0x00CA(0x0006) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_InertializationBlendByEnum
// 0x0018 (0x00E8 - 0x00D0)
struct FAnimNode_InertializationBlendByEnum : public FAnimNode_InertializationBlendListBase
{
	TArray<int> EnumToPoseIndex; // 0x00D0(0x0010) (ZeroConstructor)
	unsigned char ActiveEnumValue; // 0x00E0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x00E1(0x0007) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_InertializationBlendByInt
// 0x0000 (0x00D0 - 0x00D0)
struct FAnimNode_InertializationBlendByInt : public FAnimNode_InertializationBlendListBase
{
	int ActiveChildIndex; // 0x00CC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.AnimNode_LayeredBoneBlendWithoutExclusive
// 0x00D0 (0x0108 - 0x0038)
struct FAnimNode_LayeredBoneBlendWithoutExclusive : public FAnimNode_Base
{
	struct FPoseLink BasePose; // 0x0038(0x0018) (Edit, BlueprintVisible)
	TArray<struct FPoseLink> BlendPoses; // 0x0050(0x0010) (Edit, BlueprintVisible, EditFixedSize, ZeroConstructor)
	class USkeletalMesh* BaseSkeletalMesh; // 0x0060(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x18]; // 0x0068(0x0018) MISSED OFFSET
	TArray<float> BlendWeights; // 0x0080(0x0010) (Edit, BlueprintVisible, EditFixedSize, ZeroConstructor)
	bool bMeshSpaceRotationBlend; // 0x0090(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECurveBlendOption> CurveBlendOption; // 0x0091(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bBlendRootMotionBasedOnRootBone; // 0x0092(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bHasRelevantPoses; // 0x0093(0x0001) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x0094(0x0004) MISSED OFFSET
	TArray<struct FPerBoneBlendWeight> PerBoneBlendWeights; // 0x0098(0x0010) (ZeroConstructor)
	struct FGuid SkeletonGuid; // 0x00A8(0x0010) (IsPlainOldData)
	struct FGuid VirtualBoneGuid; // 0x00B8(0x0010) (IsPlainOldData)
	unsigned char UnknownData02[0x40]; // 0x00C8(0x0040) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_MirrorPose
// 0x0048 (0x0080 - 0x0038)
struct FAnimNode_MirrorPose : public FAnimNode_Base
{
	class UMirrorPoseProfile* MirrorPoseProfile; // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bMirror; // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0041(0x0007) MISSED OFFSET
	struct FPoseLink Source; // 0x0048(0x0018) (Edit)
	unsigned char UnknownData01[0x20]; // 0x0060(0x0020) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_OffsetRootBone
// 0x00E8 (0x0120 - 0x0038)
struct FAnimNode_OffsetRootBone : public FAnimNode_Base
{
	struct FPoseLink Source; // 0x0038(0x0018) (Edit, BlueprintVisible)
	float RotationHalfLife; // 0x0050(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float TranslationHalfLife; // 0x0054(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float MaxTransitionError; // 0x0058(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool bOnlySimulateYaw; // 0x005C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bUseAssetRootMotion; // 0x005D(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bIgnoreComponentScale; // 0x005E(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EOffsetRootBoneMode RotationMode; // 0x005F(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	EOffsetRootBoneMode TranslationMode; // 0x0060(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0xF]; // 0x0061(0x000F) MISSED OFFSET
	struct FQuat InputSimulatedRotation; // 0x0070(0x0010) (Edit, IsPlainOldData)
	unsigned char UnknownData01[0x90]; // 0x0080(0x0090) MISSED OFFSET
	class UWorld* CachedWorldContext; // 0x0110(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char UnknownData02[0x8]; // 0x0118(0x0008) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_PoseDelay
// 0x00C0 (0x00F8 - 0x0038)
struct FAnimNode_PoseDelay : public FAnimNode_Base
{
	struct FPoseLink Source; // 0x0038(0x0018) (Edit, BlueprintVisible)
	bool bEnable; // 0x0050(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0051(0x0007) MISSED OFFSET
	class UAnimSequence* DefaultSequence; // 0x0058(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float delayTime; // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x0064(0x0004) MISSED OFFSET
	struct FAnimNode_SequencePlayer SequencePlayerNode; // 0x0068(0x0070)
	unsigned char UnknownData02[0x20]; // 0x00D8(0x0020) MISSED OFFSET
};

// ScriptStruct Addons.PoseUnit
// 0x0090
struct FPoseUnit
{
	unsigned char UnknownData00[0x90]; // 0x0000(0x0090) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_PoseRecorder
// 0x0030 (0x0068 - 0x0038)
struct FAnimNode_PoseRecorder : public FAnimNode_Base
{
	class UAnimPoseRecorder* AnimPoseRecorder; // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<struct FBoneReference> RecordedBones; // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FPoseLink Source; // 0x0050(0x0018) (Edit, BlueprintVisible)
};

// ScriptStruct Addons.AnimNode_ProceduralWalk
// 0x0240 (0x02B8 - 0x0078)
struct FAnimNode_ProceduralWalk : public FAnimNode_SkeletalControlBase
{
	class UProceduralWalkData* ProceduralWalkData; // 0x0078(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FBoneReference BodyBone; // 0x0080(0x0018) (Edit)
	TArray<struct FProceduralLeg> ProceduralLegs; // 0x0098(0x0010) (Edit, ZeroConstructor)
	TArray<struct FProceduralLeg> Pincers; // 0x00A8(0x0010) (Edit, ZeroConstructor)
	bool bFalling; // 0x00B8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bHandleMovingPlatform; // 0x00B9(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bEvaluateLegWhileNotHitGround; // 0x00BA(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bShouldCanUpDownInterface; // 0x00BB(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x00BC(0x0004) MISSED OFFSET
	TArray<struct FLegGroup> LegGroups; // 0x00C0(0x0010) (Edit, ZeroConstructor)
	float ForwardStanceLength; // 0x00D0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float RightStanceLength; // 0x00D4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat* MinStepDurationCurve; // 0x00D8(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat* StancePercentageCurve; // 0x00E0(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat* StanceHeightCurve; // 0x00E8(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat* TraceYawRotationOffsetCurve; // 0x00F0(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat* SlopeBodyZOffsetCurve; // 0x00F8(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	bool bStartFromTail; // 0x0100(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x0101(0x0003) MISSED OFFSET
	float Precision; // 0x0104(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int MaxIterations; // 0x0108(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int InitSkipFramesNum; // 0x010C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool bConsiderTimeInterval; // 0x0110(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x3]; // 0x0111(0x0003) MISSED OFFSET
	int FootTraceSkipFrameCount; // 0x0114(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float FootTraceTimeInterval; // 0x0118(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int RootTraceSkipFrameCount; // 0x011C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int PincerTraceSkipFrameCount; // 0x0120(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float ForceRequestTraceTimeInterval; // 0x0124(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool bDuplicateCheckWeakPointer; // 0x0128(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bCacheReferenceObjectEveryFrame; // 0x0129(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bUseFABRIKSolve; // 0x012A(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData03[0x5]; // 0x012B(0x0005) MISSED OFFSET
	TArray<struct FAnimNode_Fabrik> FABRIK_Nodes; // 0x0130(0x0010) (Edit, ZeroConstructor)
	bool bCheckCCDIKValidation; // 0x0140(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData04[0x7]; // 0x0141(0x0007) MISSED OFFSET
	class APawn* OwnerPawn; // 0x0148(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	class USkeletalMeshComponent* SkeletalMeshComponent; // 0x0150(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	class UWorld* WorldContext; // 0x0158(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TWeakObjectPtr<class APawn> WeakOwnerPawn; // 0x0160(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TWeakObjectPtr<class USkeletalMeshComponent> WeakSkeletalMeshComponent; // 0x0168(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	TWeakObjectPtr<class UWorld> WeakWorldContext; // 0x0170(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TArray<struct FProceduralLegData> ProceduralLegsData; // 0x0178(0x0010) (ZeroConstructor)
	TArray<struct FProceduralLegData> PincersData; // 0x0188(0x0010) (ZeroConstructor)
	unsigned char UnknownData05[0x8]; // 0x0198(0x0008) MISSED OFFSET
	TArray<struct FLegGroupData> LegGroupsData; // 0x01A0(0x0010) (ZeroConstructor)
	unsigned char UnknownData06[0x108]; // 0x01B0(0x0108) MISSED OFFSET
};

// ScriptStruct Addons.LegGroupData
// 0x0008
struct FLegGroupData
{
	unsigned char UnknownData00[0x8]; // 0x0000(0x0008) MISSED OFFSET
};

// ScriptStruct Addons.ProceduralLegData
// 0x0130
struct FProceduralLegData
{
	unsigned char UnknownData00[0x40]; // 0x0000(0x0040) MISSED OFFSET
	class UPrimitiveComponent* MoveBaseComponent; // 0x0040(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	unsigned char UnknownData01[0xE8]; // 0x0048(0x00E8) MISSED OFFSET
};

// ScriptStruct Addons.LegGroup
// 0x0010
struct FLegGroup
{
	TArray<int> LegIndices; // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct Addons.ProceduralLeg
// 0x0050
struct FProceduralLeg
{
	struct FBoneReference RootBone; // 0x0000(0x0018) (Edit)
	struct FBoneReference TipBone; // 0x0018(0x0018) (Edit)
	struct FVector Offset; // 0x0030(0x000C) (Edit, IsPlainOldData)
	bool bEnableRotationLimits; // 0x003C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x003D(0x0003) MISSED OFFSET
	TArray<float> JointRotationLimit; // 0x0040(0x0010) (Edit, EditFixedSize, ZeroConstructor)
};

// ScriptStruct Addons.PW_CCDIKChainLink
// 0x0080
struct FPW_CCDIKChainLink
{
	unsigned char UnknownData00[0x80]; // 0x0000(0x0080) MISSED OFFSET
};

// ScriptStruct Addons.RotationLimitsPerJoint
// 0x0010
struct FRotationLimitsPerJoint
{
	TArray<float> RotationLimits; // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct Addons.AnimNode_ProceduralWalkSafety
// 0x0298 (0x0310 - 0x0078)
struct FAnimNode_ProceduralWalkSafety : public FAnimNode_SkeletalControlBase
{
	class UProceduralWalkData* ProceduralWalkData; // 0x0078(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FBoneReference BodyBone; // 0x0080(0x0018) (Edit)
	TArray<struct FProceduralLeg> ProceduralLegs; // 0x0098(0x0010) (Edit, ZeroConstructor)
	TArray<struct FProceduralLeg> Pincers; // 0x00A8(0x0010) (Edit, ZeroConstructor)
	bool bFalling; // 0x00B8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool bHandleMovingPlatform; // 0x00B9(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bEvaluateLegWhileNotHitGround; // 0x00BA(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bShouldCanUpDownInterface; // 0x00BB(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x00BC(0x0004) MISSED OFFSET
	TArray<struct FLegGroup> LegGroups; // 0x00C0(0x0010) (Edit, ZeroConstructor)
	float ForwardStanceLength; // 0x00D0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float RightStanceLength; // 0x00D4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat* MinStepDurationCurve; // 0x00D8(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat* StancePercentageCurve; // 0x00E0(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat* StanceHeightCurve; // 0x00E8(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat* TraceYawRotationOffsetCurve; // 0x00F0(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat* SlopeBodyZOffsetCurve; // 0x00F8(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	bool bStartFromTail; // 0x0100(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x0101(0x0003) MISSED OFFSET
	float Precision; // 0x0104(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int MaxIterations; // 0x0108(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int InitSkipFramesNum; // 0x010C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool bConsiderTimeInterval; // 0x0110(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x3]; // 0x0111(0x0003) MISSED OFFSET
	int FootTraceSkipFrameCount; // 0x0114(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float FootTraceTimeInterval; // 0x0118(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int RootTraceSkipFrameCount; // 0x011C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int PincerTraceSkipFrameCount; // 0x0120(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float ForceRequestTraceTimeInterval; // 0x0124(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool bDuplicateCheckWeakPointer; // 0x0128(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bCacheReferenceObjectEveryFrame; // 0x0129(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bUseFABRIKSolve; // 0x012A(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData03[0x5]; // 0x012B(0x0005) MISSED OFFSET
	TArray<struct FAnimNode_Fabrik> FABRIK_Nodes; // 0x0130(0x0010) (Edit, ZeroConstructor)
	bool bCheckCCDIKValidation; // 0x0140(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData04[0x3]; // 0x0141(0x0003) MISSED OFFSET
	struct FVector InPawnVelocity; // 0x0144(0x000C) (Edit, IsPlainOldData)
	struct FVector InPawnUpVector; // 0x0150(0x000C) (Edit, IsPlainOldData)
	struct FVector InPawnForwardVector; // 0x015C(0x000C) (Edit, IsPlainOldData)
	struct FVector InPawnRightwardVector; // 0x0168(0x000C) (Edit, IsPlainOldData)
	unsigned char UnknownData05[0x4]; // 0x0174(0x0004) MISSED OFFSET
	class USkeletalMeshComponent* SkeletalMeshComponent; // 0x0178(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	class UWorld* WorldContext; // 0x0180(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TWeakObjectPtr<class USkeletalMeshComponent> WeakSkeletalMeshComponent; // 0x0188(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	TWeakObjectPtr<class UWorld> WeakWorldContext; // 0x0190(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char UnknownData06[0x8]; // 0x0198(0x0008) MISSED OFFSET
	struct FTransform ActorTransform; // 0x01A0(0x0030) (IsPlainOldData)
	TArray<struct FProceduralLegData> ProceduralLegsData; // 0x01D0(0x0010) (ZeroConstructor)
	TArray<struct FProceduralLegData> PincersData; // 0x01E0(0x0010) (ZeroConstructor)
	unsigned char UnknownData07[0x8]; // 0x01F0(0x0008) MISSED OFFSET
	TArray<struct FLegGroupData> LegGroupsData; // 0x01F8(0x0010) (ZeroConstructor)
	unsigned char UnknownData08[0x108]; // 0x0208(0x0108) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_PUBGMLookAt
// 0x0058 (0x00D0 - 0x0078)
struct FAnimNode_PUBGMLookAt : public FAnimNode_SkeletalControlBase
{
	struct FVector LookAtLocation; // 0x0078(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0084(0x0004) MISSED OFFSET
	TArray<struct FBoneReference> BonesToModify; // 0x0088(0x0010) (Edit, ZeroConstructor)
	struct FVector BoneForwardAxis; // 0x0098(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRotator MaxRotation; // 0x00A4(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	float InterpSpeed; // 0x00B0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float ExitBuffer; // 0x00B4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x18]; // 0x00B8(0x0018) MISSED OFFSET
};

// ScriptStruct Addons.IKCenterOfGravity
// 0x0010
struct FIKCenterOfGravity
{
	float Alpha; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float HorizAmount; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float VertAmount; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float PullBodyAmount; // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.AnimNode_SimpleIKSolver
// 0x0130 (0x01A8 - 0x0078)
struct FAnimNode_SimpleIKSolver : public FAnimNode_SkeletalControlBase
{
	struct FName Root; // 0x0078(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float RootRotaionMultipier; // 0x0080(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FIKBodyInertia BodyInertia; // 0x0084(0x0014) (Edit, BlueprintVisible)
	TArray<struct FIKBoneBendDirection> BendDirections; // 0x0098(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FIKExcludedBone> ExcludeBones; // 0x00A8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FIKBoneLimit> JointLimits; // 0x00B8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FIKEffector> Effectors; // 0x00C8(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
	float SmoothingMaxSpeedMultiplier; // 0x00D8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float SmoothingMaxDistanceMultiplier; // 0x00DC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FIKCenterOfGravity CenterOfGravityConstraint; // 0x00E0(0x0010) (Edit, BlueprintVisible)
	int MaxSquashIterations; // 0x00F0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int MaxStretchIterations; // 0x00F4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int MaxFinalIterations; // 0x00F8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool AllowBoneTranslation; // 0x00FC(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x00FD(0x0003) MISSED OFFSET
	float SolverAlpha; // 0x0100(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float DebugDrawSize; // 0x0104(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	class UWorld* World; // 0x0108(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x98]; // 0x0110(0x0098) MISSED OFFSET
};

// ScriptStruct Addons.IKSmoothing
// 0x0018
struct FIKSmoothing
{
	bool SmoothPositionOverTime; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
	float MaxPositionSpeed; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxPositionDistance; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool SmoothRotationOverTime; // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x000D(0x0003) MISSED OFFSET
	float MaxDegreesSpeed; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxDegreesDistance; // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.IKPoleVector
// 0x0020
struct FIKPoleVector
{
	TEnumAsByte<enum EPoleVectorModeEnum> Mode; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
	struct FVector Position; // 0x0004(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	struct FName BoneName; // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x0018(0x0004) MISSED OFFSET
	float AngleOffset; // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct Addons.IKEffector
// 0x00E0
struct FIKEffector
{
	struct FName BoneName; // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FVector Position; // 0x0008(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	TEnumAsByte<enum EEffectorSpaceEnum> PositionSpace; // 0x0014(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0015(0x0003) MISSED OFFSET
	struct FRotator Rotation; // 0x0018(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	TEnumAsByte<enum EEffectorSpaceEnum> RotationSpace; // 0x0024(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x0025(0x0003) MISSED OFFSET
	float PullWeight; // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool NormalizePulling; // 0x002C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x3]; // 0x002D(0x0003) MISSED OFFSET
	struct FVector PositivePullFactor; // 0x0030(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector NegativePullFactor; // 0x003C(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	bool RotateBone; // 0x0048(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool RotateLimb; // 0x0049(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData03[0x2]; // 0x004A(0x0002) MISSED OFFSET
	float DeltaSmoothSpeed; // 0x004C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float AngularDeltaSmoothSpeed; // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FIKSmoothing Smoothing; // 0x0054(0x0018) (Edit, BlueprintVisible)
	unsigned char UnknownData04[0x4]; // 0x006C(0x0004) MISSED OFFSET
	struct FIKPoleVector PoleVector; // 0x0070(0x0020) (Edit, BlueprintVisible)
	bool AffectsCenterOfGravity; // 0x0090(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData05[0x3]; // 0x0091(0x0003) MISSED OFFSET
	float Alpha; // 0x0094(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData06[0x48]; // 0x0098(0x0048) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_SpineLean
// 0x0060 (0x00D8 - 0x0078)
struct FAnimNode_SpineLean : public FAnimNode_SkeletalControlBase
{
	TArray<struct FBoneReference> SpineBones; // 0x0078(0x0010) (Edit, ZeroConstructor)
	float MaxLeanAngle; // 0x0088(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x008C(0x0004) MISSED OFFSET
	TArray<float> SpineWeights; // 0x0090(0x0010) (Edit, ZeroConstructor)
	float InterpSpeed; // 0x00A0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float MaxAngularVelocity; // 0x00A4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float MaxAngleDelta; // 0x00A8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector MoveDirection; // 0x00AC(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector WallNormal; // 0x00B8(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	bool bDrawDebug; // 0x00C4(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x13]; // 0x00C5(0x0013) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_StretchBoneChain
// 0x0060 (0x00D8 - 0x0078)
struct FAnimNode_StretchBoneChain : public FAnimNode_SkeletalControlBase
{
	struct FVector TargetEffectorLocation; // 0x0078(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	bool bDrawDebug; // 0x0084(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0085(0x0003) MISSED OFFSET
	struct FBoneReference TipBone; // 0x0088(0x0018) (Edit)
	struct FBoneReference RootBone; // 0x00A0(0x0018) (Edit)
	float DefaultScaleStep; // 0x00B8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x00BC(0x0004) MISSED OFFSET
	class UCurveFloat* StretchScaleStepCurve; // 0x00C0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x10]; // 0x00C8(0x0010) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_StretchBoneChainSafety
// 0x0030 (0x00A8 - 0x0078)
struct FAnimNode_StretchBoneChainSafety : public FAnimNode_SkeletalControlBase
{
	struct FVector TargetEffectorLocation; // 0x0078(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	bool bDrawDebug; // 0x0084(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0085(0x0003) MISSED OFFSET
	TArray<struct FBoneReference> BoneChain; // 0x0088(0x0010) (Edit, ZeroConstructor)
	float DefaultScaleStep; // 0x0098(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x009C(0x0004) MISSED OFFSET
	class UCurveFloat* StretchScaleStepCurve; // 0x00A0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.AnimNode_SyncBlendSpacePlayer
// 0x0018 (0x0140 - 0x0128)
struct FAnimNode_SyncBlendSpacePlayer : public FAnimNode_BlendSpacePlayer
{
	class UAssetPlayerSyncNode* BlendSpaceSyncNode; // 0x0128(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName SyncGroupName; // 0x0130(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bIsLeader; // 0x0138(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0139(0x0007) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_SyncBlendSpacePlayerSafety
// 0x0040 (0x0168 - 0x0128)
struct FAnimNode_SyncBlendSpacePlayerSafety : public FAnimNode_BlendSpacePlayer
{
	struct FName SyncGroupName; // 0x0128(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bIsLeader; // 0x0130(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bUseExperimentalSync; // 0x0131(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x6]; // 0x0132(0x0006) MISSED OFFSET
	class UAnimInstance* LinkedAnimInstance; // 0x0138(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bUpdateLeaderNodeAnyThread; // 0x0140(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x7]; // 0x0141(0x0007) MISSED OFFSET
	class UAnimInstance* LinkedAnimInstanceLastFrame; // 0x0148(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TArray<class UProperty*> PropagatedProperties; // 0x0150(0x0010) (ZeroConstructor, Transient)
	unsigned char UnknownData02[0x8]; // 0x0160(0x0008) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_SyncSequencePlayer
// 0x0018 (0x0088 - 0x0070)
struct FAnimNode_SyncSequencePlayer : public FAnimNode_SequencePlayer
{
	class UAssetPlayerSyncNode* SyncNode; // 0x0070(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName SyncGroupName; // 0x0078(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bIsLeader; // 0x0080(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0081(0x0007) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_SyncSequencePlayerSafety
// 0x0010 (0x0080 - 0x0070)
struct FAnimNode_SyncSequencePlayerSafety : public FAnimNode_SequencePlayer
{
	struct FName SyncGroupName; // 0x0070(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bIsLeader; // 0x0078(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0079(0x0007) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_Turn
// 0x0020 (0x00A0 - 0x0080)
struct FAnimNode_Turn : public FAnimNode_SyncSequencePlayerSafety
{
	struct FRotator TargetRotator; // 0x007C(0x000C) (Edit, IsPlainOldData)
	float RootMotionThreshold; // 0x0088(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool bUseAssetRootMotion; // 0x008C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x13]; // 0x008D(0x0013) MISSED OFFSET
};

// ScriptStruct Addons.AnimNode_TwoLeggedIK
// 0x0628 (0x06A0 - 0x0078)
struct FAnimNode_TwoLeggedIK : public FAnimNode_SkeletalControlBase
{
	bool bEnableRootAdaption; // 0x0078(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0079(0x0007) MISSED OFFSET
	struct FBoneReference Root; // 0x0080(0x0018) (Edit)
	float RootTraceUpOffset; // 0x0098(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float RootTraceDownOffset; // 0x009C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float RootTraceSphereRadius; // 0x00A0(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float RootPositionLerpSpeed; // 0x00A4(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float RootMaxHeightOffset; // 0x00A8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x00AC(0x0004) MISSED OFFSET
	TArray<TEnumAsByte<enum ECollisionChannel>> SlopeAdaption_ObjectTypesToQuery; // 0x00B0(0x0010) (Edit, ZeroConstructor)
	bool bEnableSlopeAdaption; // 0x00C0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x7]; // 0x00C1(0x0007) MISSED OFFSET
	struct FBoneReference SpineRoot; // 0x00C8(0x0018) (Edit)
	struct FBoneReference TailRoot; // 0x00E0(0x0018) (Edit)
	float SlopeMaxPitchOffset; // 0x00F8(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float SlopeRotationLerpSpeed; // 0x00FC(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	TArray<TEnumAsByte<enum ECollisionChannel>> FootAdaption_ObjectTypesToQuery; // 0x0100(0x0010) (Edit, ZeroConstructor)
	bool bEnableFootPositionAdaption; // 0x0110(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bEnableFootRotationAdaption; // 0x0111(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData03[0x6]; // 0x0112(0x0006) MISSED OFFSET
	struct FBoneReference IKBone_L; // 0x0118(0x0018) (Edit)
	struct FBoneReference FootBone_L; // 0x0130(0x0018) (Edit)
	unsigned char UnknownData04[0x8]; // 0x0148(0x0008) MISSED OFFSET
	struct FBoneSocketTarget JointTarget_L; // 0x0150(0x0060) (Edit)
	struct FVector JointTargetLocation_L; // 0x01B0(0x000C) (Edit, IsPlainOldData)
	unsigned char UnknownData05[0x4]; // 0x01BC(0x0004) MISSED OFFSET
	struct FBoneReference IKBone_R; // 0x01C0(0x0018) (Edit)
	struct FBoneReference FootBone_R; // 0x01D8(0x0018) (Edit)
	struct FBoneSocketTarget JointTarget_R; // 0x01F0(0x0060) (Edit)
	struct FVector JointTargetLocation_R; // 0x0250(0x000C) (Edit, IsPlainOldData)
	float FootTraceUpOffset; // 0x025C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float FootTraceDownOffset; // 0x0260(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float FootTraceSphereRadius; // 0x0264(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float FootPositionLerpSpeed; // 0x0268(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float FootRotationLerpSpeed; // 0x026C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float FootMaxPitchOffset; // 0x0270(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float FootMaxRollOffset; // 0x0274(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float FootMaxHeightOffset; // 0x0278(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int SkipEvaluateTimes; // 0x027C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FAnimNode_TwoBoneIK LegAdapting_L; // 0x0280(0x01C0)
	struct FAnimNode_TwoBoneIK LegAdapting_R; // 0x0440(0x01C0)
	unsigned char UnknownData06[0xA0]; // 0x0600(0x00A0) MISSED OFFSET
};

// ScriptStruct Addons.RecordPoseData
// 0x00A8
struct FRecordPoseData
{
	unsigned char UnknownData00[0xA8]; // 0x0000(0x00A8) MISSED OFFSET
};

// ScriptStruct Addons.BakedSequenceData
// 0x0018
struct FBakedSequenceData
{
	bool bValid; // 0x0000(0x0001) (Edit, ZeroConstructor, EditConst, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0001(0x0007) MISSED OFFSET
	TArray<struct FBakedBoneData> BoneTransforms; // 0x0008(0x0010) (Edit, ZeroConstructor, EditConst)
};

// ScriptStruct Addons.BakedBoneData
// 0x0010
struct FBakedBoneData
{
	TArray<struct FTransform> Transforms; // 0x0000(0x0010) (Edit, ZeroConstructor, EditConst)
};

// ScriptStruct Addons.WaitSetParamTexture
// 0x0050
struct FWaitSetParamTexture
{
	TMap<struct FName, class UTexture2D*> TexMap; // 0x0000(0x0050) (ZeroConstructor, Transient)
};

// ScriptStruct Addons.AvatarMaterialGameThreadInfo
// 0x0058
struct FAvatarMaterialGameThreadInfo
{
	class UMaterial* BaseMaterial; // 0x0000(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TMap<struct FName, class UTexture*> ParamNameToTexture2DMap; // 0x0008(0x0050) (ZeroConstructor, Transient)
};

// ScriptStruct Addons.AvatarObjectAsyncInfo
// 0x0028
struct FAvatarObjectAsyncInfo
{
	TWeakObjectPtr<class UCharacterAvatarComponent2> AvatarComponent2; // 0x0000(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	TWeakObjectPtr<class USkeletalMeshComponent> MasterSkeletalMeshComponent; // 0x0008(0x0008) (ExportObject, ZeroConstructor, Transient, InstancedReference, IsPlainOldData)
	class UAvatarMerger* AvatarMerger; // 0x0010(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	unsigned char UnknownData00[0x10]; // 0x0018(0x0010) MISSED OFFSET
};

// ScriptStruct Addons.AvatarMergeAvatarConfigInfo
// 0x0010
struct FAvatarMergeAvatarConfigInfo
{
	TArray<int> ItemList; // 0x0000(0x0010) (ZeroConstructor)
};

// ScriptStruct Addons.BeamEmitterData
// 0x000C
struct FBeamEmitterData
{
	int BeamEmitterIndex; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int BeamEmitterSourceIndex; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int BeamEmitterTargetIndex; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.SmartBearerConfig
// 0x0008
struct FSmartBearerConfig
{
	float MaxBearerNum; // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	int NormalSkinShowNum; // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.DeviceSmartBearerOverrideConfig
// 0x0018
struct FDeviceSmartBearerOverrideConfig
{
	struct FString DeviceName; // 0x0000(0x0010) (ZeroConstructor)
	struct FSmartBearerConfig SmartBearerConfig; // 0x0010(0x0008)
};

// ScriptStruct Addons.ShadowOptConfig
// 0x0028
struct FShadowOptConfig
{
	bool Enable; // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char DeviceLevel; // 0x0001(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char BearerType; // 0x0002(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x1]; // 0x0003(0x0001) MISSED OFFSET
	float LOD0_ScreenSize; // 0x0004(0x0004) (ZeroConstructor, IsPlainOldData)
	int LOD0_MaxNum; // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x000C(0x0004) MISSED OFFSET
	float LOD1_ScreenSize; // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	int LOD1_MaxNum; // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x4]; // 0x0018(0x0004) MISSED OFFSET
	float LOD2_ScreenSize; // 0x001C(0x0004) (ZeroConstructor, IsPlainOldData)
	int LOD2_MaxNum; // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData03[0x4]; // 0x0024(0x0004) MISSED OFFSET
};

// ScriptStruct Addons.MinUROConfig
// 0x0018
struct FMinUROConfig
{
	struct FString PlatformLimit; // 0x0000(0x0010) (ZeroConstructor)
	int8_t FPSLimit; // 0x0010(0x0001) (ZeroConstructor, IsPlainOldData)
	int8_t RenderQualityLimit; // 0x0011(0x0001) (ZeroConstructor, IsPlainOldData)
	int8_t CharacterSimulatedMinURO; // 0x0012(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x5]; // 0x0013(0x0005) MISSED OFFSET
};

// ScriptStruct Addons.MeshOptConfig
// 0x0010
struct FMeshOptConfig
{
	int8_t DeviceLevel; // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	int8_t LODBias; // 0x0001(0x0001) (ZeroConstructor, IsPlainOldData)
	int8_t AvatarMergeStripTopLOD; // 0x0002(0x0001) (ZeroConstructor, IsPlainOldData)
	bool bScreenSizeForAIOnly; // 0x0003(0x0001) (ZeroConstructor, IsPlainOldData)
	bool bUseAvatarMerge; // 0x0004(0x0001) (ZeroConstructor, IsPlainOldData)
	bool bLODBiasForAISkelOnly; // 0x0005(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x2]; // 0x0006(0x0002) MISSED OFFSET
	float StaticMeshOverrideScreenSize; // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
	float SkeletMeshOverrideScreenSize; // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.TextureLODBiasOverrideInfo
// 0x0028
struct FTextureLODBiasOverrideInfo
{
	TEnumAsByte<enum ETextureGroup> Group; // 0x0000(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0001(0x0007) MISSED OFFSET
	TArray<int> OverrideLODBias; // 0x0008(0x0010) (ZeroConstructor)
	unsigned char UnknownData01[0x10]; // 0x0018(0x0010) MISSED OFFSET
};

// ScriptStruct Addons.CopyPropertyData
// 0x0010
struct FCopyPropertyData
{
	TArray<class UProperty*> Properties; // 0x0000(0x0010) (ZeroConstructor, Transient)
};

// ScriptStruct Addons.FollowTargetMoveRecord
// 0x001C
struct FFollowTargetMoveRecord
{
	float TimeStamp; // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FVector Velocity; // 0x0004(0x000C) (IsPlainOldData)
	struct FVector Location; // 0x0010(0x000C) (IsPlainOldData)
};

// ScriptStruct Addons.EffectTimeline
// 0x0078
struct FEffectTimeline
{
	float Time; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0004(0x0004) MISSED OFFSET
	unsigned char UnknownData01[0x28]; // 0x0004(0x0028) UNKNOWN PROPERTY: SoftObjectProperty Addons.EffectTimeline.AssetParticle
	unsigned char Attached : 1; // 0x0030(0x0001) (Edit, BlueprintVisible, DisableEditOnInstance)
	unsigned char UnknownData02[0x7]; // 0x0031(0x0007) MISSED OFFSET
	struct FName SocketName; // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FVector Loc; // 0x0040(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	struct FRotator Rot; // 0x004C(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	struct FVector Scale3D; // 0x0058(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	float Duration; // 0x0064(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData03[0x10]; // 0x0068(0x0010) MISSED OFFSET
};

// ScriptStruct Addons.BioVehicleStateDisable
// 0x0002
struct FBioVehicleStateDisable
{
	EBioVehicleState PawnState; // 0x0000(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	int8_t Disabled; // 0x0001(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct Addons.PendingAnchorSpawn
// 0x0050
struct FPendingAnchorSpawn
{
	unsigned char UnknownData00[0x50]; // 0x0000(0x0050) MISSED OFFSET
};

// ScriptStruct Addons.CollectedEventKeysValues
// 0x0020
struct FCollectedEventKeysValues
{
	TArray<struct FString> Keys; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FString> Values; // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.CollectedEventData
// 0x0050
struct FCollectedEventData
{
	TMap<struct FString, struct FString> KeyValueMap; // 0x0000(0x0050) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.DynamicSplineDebugInfo
// 0x0028
struct FDynamicSplineDebugInfo
{
	struct FVector StartPoint; // 0x0000(0x000C) (IsPlainOldData)
	struct FVector EndPoint; // 0x000C(0x000C) (IsPlainOldData)
	bool bHide; // 0x0018(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0019(0x0007) MISSED OFFSET
	class AActor* OverlapActor; // 0x0020(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.CurvedUpdateParam
// 0x0050
struct FCurvedUpdateParam
{
	class ASTExtraBaseCharacter* UpdatedPlayer; // 0x0000(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UHorsePlayerCurvedUpdateComponent* OwnerComponent; // 0x0008(0x0008) (BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	class ABioVehicleBase* BioOwner; // 0x0010(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCurveVector* UsedLocationUpdateCurve; // 0x0018(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UCurveVector* UsedRotationUpdateCurve; // 0x0020(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector RealExitLocation; // 0x0028(0x000C) (BlueprintVisible, IsPlainOldData)
	float Rate; // 0x0034(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float CameraLerpStartTime; // 0x0038(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float CameraLerpDuration; // 0x003C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bActived; // 0x0040(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bValid; // 0x0041(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x2]; // 0x0042(0x0002) MISSED OFFSET
	float TimeAccumulator; // 0x0044(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float ZScale; // 0x0048(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxCurveTime; // 0x004C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.ReplicatedHoverSimData
// 0x0028
struct FReplicatedHoverSimData
{
	float HoverDelta; // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FVector_NetQuantize100 SimForce; // 0x0004(0x000C)
	struct FVector_NetQuantize100 TraceHitLocation; // 0x0010(0x000C)
	struct FVector_NetQuantize100 HoverSpotRelativeLoc; // 0x001C(0x000C)
};

// ScriptStruct Addons.IKCore
// 0x0090
struct FIKCore
{
	unsigned char UnknownData00[0x90]; // 0x0000(0x0090) MISSED OFFSET
};

// ScriptStruct Addons.IKBoneData
// 0x0050
struct FIKBoneData
{
	unsigned char UnknownData00[0x50]; // 0x0000(0x0050) MISSED OFFSET
};

// ScriptStruct Addons.IKRootData
// 0x0010
struct FIKRootData
{
	unsigned char UnknownData00[0x10]; // 0x0000(0x0010) MISSED OFFSET
};

// ScriptStruct Addons.IKEffectorData
// 0x0018
struct FIKEffectorData
{
	unsigned char UnknownData00[0x18]; // 0x0000(0x0018) MISSED OFFSET
};

// ScriptStruct Addons.MechaStateSet
// 0x0050
struct FMechaStateSet
{
	unsigned char UnknownData00[0x50]; // 0x0000(0x0050) UNKNOWN PROPERTY: SetProperty Addons.MechaStateSet.States
};

// ScriptStruct Addons.MaterialMergeResult
// 0x00F8
struct FMaterialMergeResult
{
	TMap<int, class UMaterialInstanceDynamic*> MergedMaterial; // 0x0000(0x0050) (ZeroConstructor, Transient)
	unsigned char UnknownData00[0xA8]; // 0x0050(0x00A8) MISSED OFFSET
};

// ScriptStruct Addons.MaterialMergeInfo
// 0x0068
struct FMaterialMergeInfo
{
	class UMaterialInterface* Material; // 0x0000(0x0008) (ZeroConstructor, Transient, IsPlainOldData)
	TMap<struct FName, struct FMaterialTextureMergeInfo> ParamName2TextureInfoMap; // 0x0008(0x0050) (ZeroConstructor, Transient)
	unsigned char UnknownData00[0x10]; // 0x0058(0x0010) MISSED OFFSET
};

// ScriptStruct Addons.TextureMergeExtInfo
// 0x0014
struct FTextureMergeExtInfo
{
	TWeakObjectPtr<class UTexture2D> Texture2D; // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0xC]; // 0x0008(0x000C) MISSED OFFSET
};

// ScriptStruct Addons.Tex2DMergeChunk
// 0x002C
struct FTex2DMergeChunk
{
	struct FTextureMergeExtInfo OriginTextureExtInfo; // 0x0000(0x0014)
	unsigned char UnknownData00[0x18]; // 0x0014(0x0018) MISSED OFFSET
};

// ScriptStruct Addons.MaterialTextureMergeInfo
// 0x0058
struct FMaterialTextureMergeInfo
{
	class UTexture2D* Texture; // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	class UMaterialInterface* OwnerMaterial; // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FTex2DMergeChunk MergeChunk; // 0x0010(0x002C)
	unsigned char UnknownData00[0x1C]; // 0x003C(0x001C) MISSED OFFSET
};

// ScriptStruct Addons.BoneMirrorPair
// 0x0010
struct FBoneMirrorPair
{
	struct FName BoneName; // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FName MirrorBoneName; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.MirrorFindReplaceExpression
// 0x0018
struct FMirrorFindReplaceExpression
{
	struct FName FindExpression; // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	struct FName ReplaceExpression; // 0x0008(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EMirrorFindReplaceMethod> FindReplaceMethod; // 0x0010(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct Addons.LinkMoveData
// 0x001C
struct FLinkMoveData
{
	int Frame; // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FVector PreLinkLoc; // 0x0004(0x000C) (IsPlainOldData)
	struct FVector PreLinkMoveDelta; // 0x0010(0x000C) (IsPlainOldData)
};

// ScriptStruct Addons.TeamShape
// 0x0010
struct FTeamShape
{
	TArray<struct FVector> TeamShape; // 0x0000(0x0010) (Edit, BlueprintVisible, EditFixedSize, ZeroConstructor)
};

// ScriptStruct Addons.TeamPosition
// 0x0018
struct FTeamPosition
{
	struct FVector Position; // 0x0000(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	unsigned char UnknownData00[0xC]; // 0x000C(0x000C) MISSED OFFSET
};

// ScriptStruct Addons.PoseSearchData
// 0x0010
struct FPoseSearchData
{
	class UAnimSequence* Sequence; // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector2D SampleRange; // 0x0008(0x0008) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct Addons.StopPoseData
// 0x0010
struct FStopPoseData
{
	TArray<struct FPoseSearchData> StopSequences; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.NTFoxDynamicNetSmoothConfig
// 0x0014
struct FNTFoxDynamicNetSmoothConfig
{
	bool bEnable; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
	float BaseMaxSmoothDistance; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float BaseSmoothLocationTime; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MinSmoothLocationTime; // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxSpeedRatio; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.TeamData
// 0x0010
struct FTeamData
{
	TArray<struct FHeadItem> TeamHeadItems; // 0x0000(0x0010) (BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.ModOBActorPathConfig
// 0x0020
struct FModOBActorPathConfig
{
	struct FString ModName; // 0x0000(0x0010) (ZeroConstructor)
	struct FString BPPath; // 0x0010(0x0010) (ZeroConstructor)
};

// ScriptStruct Addons.ODMGearSpeedCurve
// 0x0010
struct FODMGearSpeedCurve
{
	float Distance; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0004(0x0004) MISSED OFFSET
	class UCurveFloat* SpeedCurve; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.MonsterLeisureInfo
// 0x0010
struct FMonsterLeisureInfo
{
	TArray<struct FMonsterLeisureItem> LeisureArrs; // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct Addons.MonsterLeisureItem
// 0x0018
struct FMonsterLeisureItem
{
	struct FName Key; // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	float Duration; // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x000C(0x0004) MISSED OFFSET
	class UAnimationAsset* AnimSeq; // 0x0010(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.EmoteInteractItem
// 0x0010
struct FEmoteInteractItem
{
	TArray<struct FEmoteInteractAsset> EmoteInteractArrs; // 0x0000(0x0010) (Edit, ZeroConstructor)
};

// ScriptStruct Addons.EmoteInteractAsset
// 0x0020
struct FEmoteInteractAsset
{
	class UAnimationAsset* TriggerEmote; // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UAnimationAsset* VehicleEmote; // 0x0008(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UAnimationAsset* DriverEmote; // 0x0010(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UAnimationAsset* PassengerEmote; // 0x0018(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.TraceImpactPoint
// 0x0018
struct FTraceImpactPoint
{
	struct FVector ImpactLocation; // 0x0000(0x000C) (IsPlainOldData)
	struct FVector ImpactNormal; // 0x000C(0x000C) (IsPlainOldData)
};

// ScriptStruct Addons.GroundParticle
// 0x0038
struct FGroundParticle
{
	class UParticleSystem* GroundFlyingParticle; // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector LeftFootAttachPositionOffset; // 0x0008(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRotator LeftFootAttachRotationOffset; // 0x0014(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector RightFootAttachPositionOffset; // 0x0020(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRotator RightFootAttachRotationOffset; // 0x002C(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
};

// ScriptStruct Addons.PterosaurUpdateDistanceToLandConfig
// 0x000C
struct FPterosaurUpdateDistanceToLandConfig
{
	float Height; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float Interval; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bUseSweep; // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0009(0x0003) MISSED OFFSET
};

// ScriptStruct Addons.PterosaurLandingConfig
// 0x0018
struct FPterosaurLandingConfig
{
	float MaxAllowedFlyingSpeed; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float MaxLandingTime; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float LandingToGroundTime; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bForceToGroundInFixedTime; // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x000D(0x0003) MISSED OFFSET
	class UCurveVector* LandingCurve; // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.RecordData
// 0x0010
struct FRecordData
{
	float RecordDeltaTime; // 0x0000(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector RecordLocation; // 0x0004(0x000C) (BlueprintVisible, IsPlainOldData)
};

// ScriptStruct Addons.LingeringRope
// 0x0028
struct FLingeringRope
{
	class UCableComponent* CableComponent; // 0x0000(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	class USceneComponent* EndAnchor; // 0x0008(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	class UMaterialInstanceDynamic* DynamicMaterial; // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
	class UParticleSystemComponent* EndEffectComponent; // 0x0018(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	unsigned char UnknownData00[0x8]; // 0x0020(0x0008) MISSED OFFSET
};

// ScriptStruct Addons.ActorMarkData
// 0x0018
struct FActorMarkData
{
	class UClass* MarkActorClass; // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int TypeId; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EAddMarkFlag MapAdded; // 0x000C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bLocalData; // 0x000D(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x2]; // 0x000E(0x0002) MISSED OFFSET
	float DistanceToMark; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bUpdateRotation; // 0x0014(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x0015(0x0003) MISSED OFFSET
};

// ScriptStruct Addons.BuffAttachmentItem
// 0x0068
struct FBuffAttachmentItem
{
	class USceneComponent* Component; // 0x0000(0x0008) (Edit, BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	unsigned char UnknownData00[0x28]; // 0x0008(0x0028) UNKNOWN PROPERTY: SoftObjectProperty Addons.BuffAttachmentItem.ParticleSystem
	bool bCapsuleTop; // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bOnlyLocalControl; // 0x0031(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bDestroyOnEnd; // 0x0032(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x5]; // 0x0033(0x0005) MISSED OFFSET
	struct FName SocketName; // 0x0038(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EAttachRelativeLocation NonSocketAttachLocation; // 0x0040(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x3]; // 0x0041(0x0003) MISSED OFFSET
	struct FVector LocationOffset; // 0x0044(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRotator RotationOffset; // 0x0050(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	float Scale; // 0x005C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBuffTargetType TargetType; // 0x0060(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData03[0x7]; // 0x0061(0x0007) MISSED OFFSET
};

// ScriptStruct Addons.PropSkillPosionParam
// 0x0014
struct FPropSkillPosionParam
{
	float GenProbility; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int PropSkillLevel; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float CheckPeriod; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int HumanBuffID; // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int ZombieBuffID; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.BuffAttrModifierItem
// 0x0018
struct FBuffAttrModifierItem
{
	struct FString AttrName; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float ModifyValue; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EAttrModifyRefType AttrRefValueType; // 0x0014(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0015(0x0003) MISSED OFFSET
};

// ScriptStruct Addons.JumpStepInfo
// 0x0004
struct FJumpStepInfo
{
	float JumpZVelocity; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.PostEventParams
// 0x0080
struct FPostEventParams
{
	struct FString EventType; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString EventID; // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TMap<struct FString, struct FString> ActionParams; // 0x0020(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	TArray<struct FUAEBlackboardKeySelector> BBKeySelectors; // 0x0070(0x0010) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
};

// ScriptStruct Addons.PostEventWithCauserParams
// 0x0020
struct FPostEventWithCauserParams
{
	struct FString EventType; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString EventID; // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.ReplaceAvatarMaterialParams
// 0x0010
struct FReplaceAvatarMaterialParams
{
	struct FName ParameterName; // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat* ParameterValueCurve; // 0x0008(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.BuffSpawnActorInstanceItem
// 0x0014
struct FBuffSpawnActorInstanceItem
{
	unsigned char UnknownData00[0x14]; // 0x0000(0x0014) MISSED OFFSET
};

// ScriptStruct Addons.BuffSpawnActorItem
// 0x0078
struct FBuffSpawnActorItem
{
	unsigned char UnknownData00[0x28]; // 0x0000(0x0028) UNKNOWN PROPERTY: SoftClassProperty Addons.BuffSpawnActorItem.ActorClass
	bool bLoadAsync; // 0x0028(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x7]; // 0x0029(0x0007) MISSED OFFSET
	struct FName SocketName; // 0x0030(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	EBuffTargetSocketType TargetType; // 0x0038(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bUseSharedTarget; // 0x0039(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x2]; // 0x003A(0x0002) MISSED OFFSET
	struct FVector RelLocation; // 0x003C(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	bool bUseGroundNormal; // 0x0048(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData03[0x3]; // 0x0049(0x0003) MISSED OFFSET
	struct FVector GroundOffset; // 0x004C(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRotator Rotator; // 0x0058(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	EBuffEnabledRole EnableRole; // 0x0064(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool IsDestroyOnBuffEnd; // 0x0065(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData04[0x2]; // 0x0066(0x0002) MISSED OFFSET
	float LifeTime; // 0x0068(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float NotEndDestroyLifeTime; // 0x006C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bAttachMesh; // 0x0070(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bDSUpdateMesh; // 0x0071(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bRecordCauser; // 0x0072(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData05[0x5]; // 0x0073(0x0005) MISSED OFFSET
};

// ScriptStruct Addons.DestructionConfig
// 0x0014
struct FDestructionConfig
{
	float DestructionRadius; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float DestructionRadiusScale; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float DestructionDamage; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float DestructionDamageScale; // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float DestructionVelocity; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct Addons.DecorationCircleMatParams
// 0x0028
struct FDecorationCircleMatParams
{
	struct FVector2D HPRange; // 0x0000(0x0008) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	struct FName ColorParamName; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FName LightColorParamName; // 0x0010(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FLinearColor Color; // 0x0018(0x0010) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct Addons.TitanCurveMovingData
// 0x0010
struct FTitanCurveMovingData
{
	struct FName CurveMovingTag; // 0x0000(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UCurveVector* CurveAsset; // 0x0008(0x0008) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct Addons.TFPoseData
// 0x0020
struct FTFPoseData
{
	float StartTime; // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0004(0x0004) MISSED OFFSET
	class UAnimSequence* InSequence; // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	TArray<struct FVector> BoneLocations; // 0x0010(0x0010) (ZeroConstructor)
};

// ScriptStruct Addons.AudioConfigWithTips
// 0x0038
struct FAudioConfigWithTips
{
	unsigned char UnknownData00[0x28]; // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty Addons.AudioConfigWithTips.AssetAudioEvent
	int TextIDForTips; // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float TextDurationForTips; // 0x002C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	ESTExtraVehicleType ForceVehicleType; // 0x0030(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData01[0x7]; // 0x0031(0x0007) MISSED OFFSET
};

// ScriptStruct Addons.TransformerStateSet
// 0x0050
struct FTransformerStateSet
{
	unsigned char UnknownData00[0x50]; // 0x0000(0x0050) UNKNOWN PROPERTY: SetProperty Addons.TransformerStateSet.States
};

// ScriptStruct Addons.TransformLevelToolConfig
// 0x0020
struct FTransformLevelToolConfig
{
	struct FVector SourceLevelOffset; // 0x0000(0x000C) (Edit, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x000C(0x0004) MISSED OFFSET
	TArray<struct FTransformLevelTargetConfig> TargetConfigs; // 0x0010(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct Addons.TransformLevelTargetConfig
// 0x0060
struct FTransformLevelTargetConfig
{
	struct FString Level; // 0x0000(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	struct FString Comment; // 0x0010(0x0010) (Edit, ZeroConstructor, DisableEditOnInstance)
	bool IsEnabled; // 0x0020(0x0001) (Edit, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData00[0xF]; // 0x0021(0x000F) MISSED OFFSET
	struct FTransform Transform; // 0x0030(0x0030) (Edit, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct Addons.TweenAnimTask
// 0x00C0
struct FTweenAnimTask
{
	unsigned char UnknownData00[0xC0]; // 0x0000(0x00C0) MISSED OFFSET
};

// ScriptStruct Addons.BunchAction
// 0x0010
struct FBunchAction
{
	class UUTSkillAction* Effect; // 0x0000(0x0008) (Edit, BlueprintVisible, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
	bool bExeReset; // 0x0008(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool bExeUndo; // 0x0009(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x6]; // 0x000A(0x0006) MISSED OFFSET
};

// ScriptStruct Addons.ViewInfoCurve
// 0x05D0
struct FViewInfoCurve
{
	float DistanceThreshold; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0xC]; // 0x0004(0x000C) MISSED OFFSET
	struct FMinimalViewInfo AdditiveCameraViewInfo; // 0x0010(0x05B0) (Edit, BlueprintVisible)
	class UCurveFloat* FovCurve; // 0x05C0(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x8]; // 0x05C8(0x0008) MISSED OFFSET
};

// ScriptStruct Addons.AddCameraViewInfoStruct
// 0x0020
struct FAddCameraViewInfoStruct
{
	unsigned char UnknownData00[0x10]; // 0x0000(0x0010) MISSED OFFSET
	class UCurveFloat* CurFOVCurve; // 0x0010(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x8]; // 0x0018(0x0008) MISSED OFFSET
};

// ScriptStruct Addons.AddMapMarkInstanceStruct
// 0x0004
struct FAddMapMarkInstanceStruct
{
	int InstanceID; // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.RandomBuffItem
// 0x0020
struct FRandomBuffItem
{
	int Probability; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0004(0x0004) MISSED OFFSET
	struct FName BuffName; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int BuffID; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int SkillID; // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int AddLayerCount; // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x001C(0x0004) MISSED OFFSET
};

// ScriptStruct Addons.SkillActionMemory_AddRemoveBuff
// 0x000C
struct FSkillActionMemory_AddRemoveBuff
{
	int ActionID; // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	TWeakObjectPtr<class AActor> Target; // 0x0004(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.SAAllowPawnStateInstanceStruct
// 0x0008
struct FSAAllowPawnStateInstanceStruct
{
	TWeakObjectPtr<class ASTExtraCharacter> TargetCharacter; // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.VehicleWeaponBoardDataConfigItem
// 0x0018
struct FVehicleWeaponBoardDataConfigItem
{
	int SeatID; // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int WeaponListID; // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	EVehicleWeaponBoardDataType DataType; // 0x0008(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0009(0x0007) MISSED OFFSET
	struct FUAEBlackboardKeySelector BlackBoardKey; // 0x0010(0x0008) (Edit)
};

// ScriptStruct Addons.SAttachedActorPlayMontageInstanceStruct
// 0x0008
struct FSAttachedActorPlayMontageInstanceStruct
{
	TWeakObjectPtr<class USkeletalMeshComponent> CachedComp; // 0x0000(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// ScriptStruct Addons.SAAttachPawnPlayMontageInstanceStruct
// 0x0010
struct FSAAttachPawnPlayMontageInstanceStruct
{
	TWeakObjectPtr<class UAnimMontage> AnimMontageCurrent; // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	TWeakObjectPtr<class ASTExtraBaseCharacter> CachedCharacter; // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.SABindDelegateInstanceStruct
// 0x000C
struct FSABindDelegateInstanceStruct
{
	TWeakObjectPtr<class UObject> TargetObject; // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	int LuaEventHandle; // 0x0008(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.AKRTPCParam
// 0x0028
struct FAKRTPCParam
{
	struct FString RTPC; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	float Value; // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0014(0x0004) MISSED OFFSET
	class UCurveFloat* ValueCurve; // 0x0018(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int InterpolationTimeMs; // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool NeedTick; // 0x0024(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x3]; // 0x0025(0x0003) MISSED OFFSET
};

// ScriptStruct Addons.AKSwitchParam
// 0x0020
struct FAKSwitchParam
{
	struct FString SwitchGroup; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString SwitchState; // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.ChangeAkRT
// 0x0010
struct FChangeAkRT
{
	unsigned char UnknownData00[0x8]; // 0x0000(0x0008) MISSED OFFSET
	class UAkComponent* CachedAK; // 0x0008(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// ScriptStruct Addons.SACircleMove
// 0x0040
struct FSACircleMove
{
	unsigned char UnknownData00[0x40]; // 0x0000(0x0040) MISSED OFFSET
};

// ScriptStruct Addons.SkillActionMemory_ControlCharacterSearch
// 0x0018
struct FSkillActionMemory_ControlCharacterSearch
{
	struct FSearchControlRuntimeState Runtime; // 0x0000(0x0010)
	bool bAlreadyReverted; // 0x0010(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0011(0x0007) MISSED OFFSET
};

// ScriptStruct Addons.DisableBioVehicleStateInfo
// 0x0003
struct FDisableBioVehicleStateInfo
{
	EBioVehicleState State; // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bNewDisable; // 0x0001(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bResetOnEnable; // 0x0002(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.DisablePawnStateInfo
// 0x0003
struct FDisablePawnStateInfo
{
	EPawnState State; // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bNewDisable; // 0x0001(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bResetOnEnable; // 0x0002(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.SkillAction_DropItemData
// 0x0008
struct FSkillAction_DropItemData
{
	int ItemId; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int Num; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.SAFollowerPawnPlayMontageInstanceStruct
// 0x0010
struct FSAFollowerPawnPlayMontageInstanceStruct
{
	TWeakObjectPtr<class UAnimMontage> AnimMontageCurrent; // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	TWeakObjectPtr<class ASTExtraBaseCharacter> CachedCharacter; // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.FollowMovePitchLimit
// 0x0008
struct FFollowMovePitchLimit
{
	float RelativeRotMin; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float RelativeRotMax; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.UAESkillActionMemory_GNAction
// 0x0004
struct FUAESkillActionMemory_GNAction
{
	int ActionID; // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.IngoreSkillArray
// 0x0010
struct FIngoreSkillArray
{
	TArray<int> SkillList; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct Addons.CollisionChannelResModify
// 0x0002
struct FCollisionChannelResModify
{
	TEnumAsByte<enum ECollisionChannel> CollisionChannel; // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECollisionResponse> ModifyResponse; // 0x0001(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.MoveSpeedCurve
// 0x0010
struct FMoveSpeedCurve
{
	float DistanceThreshold; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0004(0x0004) MISSED OFFSET
	class UCurveFloat* LaunchSpeedCurve; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.SALaunchMove
// 0x0040
struct FSALaunchMove
{
	unsigned char UnknownData00[0x38]; // 0x0000(0x0038) MISSED OFFSET
	class UCurveFloat* SpeedCurve; // 0x0038(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.LockCameraViewTypeData
// 0x0008
struct FLockCameraViewTypeData
{
	unsigned char UnknownData00[0x8]; // 0x0000(0x0008) MISSED OFFSET
};

// ScriptStruct Addons.SAPlayMontageInstanceStruct
// 0x000C
struct FSAPlayMontageInstanceStruct
{
	int ActionID; // 0x0000(0x0004) (ZeroConstructor, IsPlainOldData)
	TWeakObjectPtr<class UAnimMontage> AnimMontageCurrent; // 0x0004(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.SAPlayMontageWeaponStateInstanceStruct
// 0x0008
struct FSAPlayMontageWeaponStateInstanceStruct
{
	TWeakObjectPtr<class UAnimMontage> AnimMontageCurrent; // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.AvatarSlotAnimData
// 0x0040
struct FAvatarSlotAnimData
{
	unsigned char UnknownData00[0x28]; // 0x0000(0x0028) UNKNOWN PROPERTY: SoftObjectProperty Addons.AvatarSlotAnimData.PropAnim
	float PlayRate; // 0x0028(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float StartingPosition; // 0x002C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FName StartingSection; // 0x0030(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	bool ShowSlotMesh; // 0x0038(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x7]; // 0x0039(0x0007) MISSED OFFSET
};

// ScriptStruct Addons.SAPlayWeaponMontageInstanceStruct
// 0x0018
struct FSAPlayWeaponMontageInstanceStruct
{
	unsigned char UnknownData00[0x18]; // 0x0000(0x0018) MISSED OFFSET
};

// ScriptStruct Addons.SACacheSoftObjectList
// 0x0020
struct FSACacheSoftObjectList
{
	TArray<class UObject*> Objects; // 0x0000(0x0010) (ZeroConstructor)
	unsigned char UnknownData00[0x10]; // 0x0010(0x0010) MISSED OFFSET
};

// ScriptStruct Addons.RandomActionGroup
// 0x0010
struct FRandomActionGroup
{
	TArray<class UUTSkillAction*> Actions; // 0x0000(0x0010) (Edit, ExportObject, ZeroConstructor)
};

// ScriptStruct Addons.RandomActionByWeightCandidate
// 0x0010
struct FRandomActionByWeightCandidate
{
	int Weight; // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0004(0x0004) MISSED OFFSET
	class UUTSkillAction* Action; // 0x0008(0x0008) (Edit, ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// ScriptStruct Addons.SlotMaterialParameterValue
// 0x0018
struct FSlotMaterialParameterValue
{
	struct FName SlotParameterName; // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	class UCurveFloat* SlotParameterValueCurve; // 0x0008(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	float SlotParameterValue; // 0x0010(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0014(0x0004) MISSED OFFSET
};

// ScriptStruct Addons.SetMeshNeedUpdateEveryFrameData
// 0x0002
struct FSetMeshNeedUpdateEveryFrameData
{
	unsigned char UnknownData00[0x2]; // 0x0000(0x0002) MISSED OFFSET
};

// ScriptStruct Addons.SubAnimInstanceParam
// 0x0048
struct FSubAnimInstanceParam
{
	struct FName PropertyName; // 0x0000(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	ESubAnimInsParamType Type; // 0x0008(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool BoolValue; // 0x0009(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x2]; // 0x000A(0x0002) MISSED OFFSET
	int IntValue; // 0x000C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float FloatValue; // 0x0010(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x0014(0x0004) MISSED OFFSET
	struct FName NameValue; // 0x0018(0x0008) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData02[0x28]; // 0x0020(0x0028) UNKNOWN PROPERTY: SoftObjectProperty Addons.SubAnimInstanceParam.ObjectValue
};

// ScriptStruct Addons.SpawnMonsterConfig
// 0x0090
struct FSpawnMonsterConfig
{
	int MonsterID; // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	struct FVector Pos; // 0x0004(0x000C) (Edit, IsPlainOldData)
	bool bIsRelativePos; // 0x0010(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	bool bNeedOverlapCheck; // 0x0011(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x2]; // 0x0012(0x0002) MISSED OFFSET
	float LineTraceHeight; // 0x0014(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float CapsuleCheckRadius; // 0x0018(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float CapsuleCheckHalfHeight; // 0x001C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	TArray<TEnumAsByte<enum EObjectTypeQuery>> ObjectTypes; // 0x0020(0x0010) (Edit, ZeroConstructor)
	float NineGridSearchRadius; // 0x0030(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int NineGridSearchFloor; // 0x0034(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool bSearchRandom; // 0x0038(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData01[0x57]; // 0x0039(0x0057) MISSED OFFSET
};

// ScriptStruct Addons.UAESkillCheckItemInfo
// 0x0010
struct FUAESkillCheckItemInfo
{
	TEnumAsByte<enum EOperatorType> OperatorType; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x3]; // 0x0001(0x0003) MISSED OFFSET
	int NeedItemNum; // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int ItemId; // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int Type; // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.CharPoseSwitch
// 0x0002
struct FCharPoseSwitch
{
	TEnumAsByte<enum ECharacterPoseType> From; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum ECharacterPoseType> To; // 0x0001(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.CurPlayingAKEvent
// 0x0004
struct FCurPlayingAKEvent
{
	unsigned char UnknownData00[0x4]; // 0x0000(0x0004) MISSED OFFSET
};

// ScriptStruct Addons.LODLimitNum
// 0x0010
struct FLODLimitNum
{
	int AutonomousMinLOD; // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int SimulatedMinLOD; // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int AutonomousMinURO; // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int SimulatedMinURO; // 0x000C(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.VehicleLODLimit
// 0x0030
struct FVehicleLODLimit
{
	struct FLODLimitNum HighDevice; // 0x0000(0x0010) (Edit)
	struct FLODLimitNum MediumDevice; // 0x0010(0x0010) (Edit)
	struct FLODLimitNum LowDevice; // 0x0020(0x0010) (Edit)
};

// ScriptStruct Addons.ForceLODInfo
// 0x000C
struct FForceLODInfo
{
	int InitForceLOD; // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int EnterForceLOD; // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	int LeaveForceLOD; // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
};

// ScriptStruct Addons.SeatMountMontageSetting
// 0x00A0
struct FSeatMountMontageSetting
{
	TMap<TEnumAsByte<enum EMountFromDirection>, struct FMountMontagePair> MountMontageParis; // 0x0000(0x0050) (Edit, ZeroConstructor, DisableEditOnInstance)
	TMap<TEnumAsByte<enum EMountFromDirection>, struct FMountMontagePair> DisMountMontageParis; // 0x0050(0x0050) (Edit, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct Addons.NitroVisualConfig
// 0x0010
struct FNitroVisualConfig
{
	TArray<struct FAttachedMeshConfig> MeshTransforms; // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance)
};

// ScriptStruct Addons.AttachedMeshConfig
// 0x0038
struct FAttachedMeshConfig
{
	bool bEnable; // 0x0000(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0001(0x0007) MISSED OFFSET
	struct FName SocketName; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	struct FVector RelativeLoc; // 0x0010(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	struct FRotator RelativeRot; // 0x001C(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	struct FVector RelativeScale; // 0x0028(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData01[0x4]; // 0x0034(0x0004) MISSED OFFSET
};

// ScriptStruct Addons.NitroBioConfig
// 0x0010
struct FNitroBioConfig
{
	float NitroMaxWalkSpeed; // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char UnknownData00[0x4]; // 0x0004(0x0004) MISSED OFFSET
	class UCurveFloat* NitroAccelCurve; // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
};

// ScriptStruct Addons.CustomVehicleTypeSetup
// 0x0010
struct FCustomVehicleTypeSetup
{
	ESTExtraVehicleType VehicleType; // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0001(0x0007) MISSED OFFSET
	struct FName DisplayName; // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, IsPlainOldData)
};

// ScriptStruct Addons.CustomVehicleShapeTypeSetup
// 0x0010
struct FCustomVehicleShapeTypeSetup
{
	ESTExtraVehicleShapeType ShapeType; // 0x0000(0x0001) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, IsPlainOldData)
	unsigned char UnknownData00[0x7]; // 0x0001(0x0007) MISSED OFFSET
	struct FName DisplayName; // 0x0008(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Config, IsPlainOldData)
};

// ScriptStruct Addons.BTDebugNodeItem
// 0x003C (0x0048 - 0x000C)
struct FBTDebugNodeItem : public FFastArraySerializerItem
{
	int ExecutionIndex; // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char TreeDepth; // 0x0010(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char Flags; // 0x0011(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char UnknownData00[0x6]; // 0x0012(0x0006) MISSED OFFSET
	struct FString NodeName; // 0x0018(0x0010) (ZeroConstructor)
	struct FString TypeShort; // 0x0028(0x0010) (ZeroConstructor)
	struct FString Runtime; // 0x0038(0x0010) (ZeroConstructor)
};

// ScriptStruct Addons.WindowBarrierData
// 0x0040
struct FWindowBarrierData
{
	struct FTransform Transform; // 0x0000(0x0030) (Edit, BlueprintVisible, IsPlainOldData)
	TArray<int> BreakWindowIds; // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

